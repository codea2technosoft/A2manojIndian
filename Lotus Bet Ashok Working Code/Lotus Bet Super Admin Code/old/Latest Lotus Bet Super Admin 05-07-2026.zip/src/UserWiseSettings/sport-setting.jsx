import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { useParams } from "react-router-dom";
import Loader from "../Common/Loader";

function SportSetting() {
  const [validated, setValidated] = useState(false);
  const navigate = useNavigate();
  const [adminData, setAdminData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isFormValid, setIsFormValid] = useState(false);
  const token = localStorage.getItem("token");
  const [AdminData, setAdminDataNEW] = useState({});
  const { id } = useParams();

  const initialSettings = {
    Football: { status: true },
    Tennis: { status: true },
    Cricket: { status: true },
    "Horse Racing": { status: true },
    "Greyhound Racing": { status: true },
    Kabaddi: { status: true },
    "I Casino": { status: true },
    Casino: { status: true },
    Politics: { status: true },
  };

  const [settings, setSettings] = useState(initialSettings);

  useEffect(() => {
    getUserSetting();
  }, []);

  const getUserSetting = async () => {
    try {
      setLoading(true);
      setTimeout(() => {
        setSettings(initialSettings);
        setLoading(false);
      }, 1000);
    } catch (error) {
      console.log(error);
      toast.error("Failed to load settings");
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="card">
        <div className="card-body text-center">
          <Loader />
        </div>
      </div>
    );
  }

  return (
    <>
      <ToastContainer
        position="top-right"
        autoClose={500}
        hideProgressBar={false}
        newestOnTop
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="colored"
      />

      <div className="card sport_setting">
        <div className="card-header bgHeader bg-primary-yellow d-flex justify-content-between align-items-center">
          <h3 className="card-title mb-0">Sport Setting</h3>
        </div>
        <div className="card-body">
          <div className="row mb-4">
            {Object.keys(settings).map((sport) => (
              <div className="col-lg-6 col-md-6" key={sport}>
                <div className="py-2 d-flex justify-content-between align-items-center w-50">
                  <div className="sport_name">{sport.replaceAll("_", " ")}: </div>

                  <div className="form-check form-switch m-0">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      checked={settings[sport].status}
                      onChange={() =>
                        setSettings({
                          ...settings,
                          [sport]: {
                            ...settings[sport],
                            status: !settings[sport].status,
                          },
                        })
                      }
                    />
                  </div>
                </div>
              </div>
            ))}
            <div className="d-flex gap-2 justify-content-start mt-2">
              <button className="btn btn-primary text-dark py-2">Submit</button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default SportSetting;
