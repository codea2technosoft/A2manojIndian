import React from 'react'

function Settlement() {
  return (
    <div className='allcommon'>
      <section className="main-inner-outer py-4">
  <div className="container-fluid">
    <div className="find-member-sec search_banking_detail">
      <div className="db-sec">
        <h2 className="common-heading page-title">Settlement List</h2>
      </div>
      <div className="inner-wrapper">
        <div
          className="common-container"
          style={{
            display: "flex",
            width: "100%",
            justifyContent: "space-between"
          }}
        >
          <div className="table-responsive" style={{ width: "48%" }}>
            <div
             className='headinggreen'
            >
              Creditors Account (dena hai)
            </div>
            <table className="banking_detail_table table-color table">
              <thead>
                <tr>
                  <th scope="col" style={{ background: "lightgrey" }}>
                    Account
                  </th>
                  <th
                    scope="col"
                    style={{ textAlign: "right", background: "lightgrey" }}
                  >
                    Client (P/L)
                  </th>
                  <th
                    scope="col"
                    style={{ textAlign: "right", background: "lightgrey" }}
                  >
                    Short Balance
                  </th>
                  <th
                    scope="col"
                    style={{ textAlign: "right", background: "lightgrey" }}
                  >
                    Settle Amount
                  </th>
                  <th
                    scope="col"
                    style={{ textAlign: "right", background: "lightgrey" }}
                  >
                    Remark
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>agvip</td>
                  <td style={{ color: "green", textAlign: "right" }}>
                    33202.74
                  </td>
                  <td style={{ textAlign: "right", color: "black" }}>0</td>
                  <td style={{ textAlign: "right" }}>
                    <div>
                      <input
                        type="number"
                        placeholder="Amount"
                        defaultValue=""
                      />
                      <button
                       className='fullsettle'
                      >
                        Full Settle
                      </button>
                    </div>
                  </td>
                  <td style={{ textAlign: "right" }}>
                    <div>
                      <input
                        type="text"
                        placeholder="Remarks"
                        defaultValue=""
                      />
                    </div>
                  </td>
                </tr>
              
              </tbody>
            </table>
          </div>
          <div className="table-responsive" style={{ width: "48%" }}>
            
            <div
              className='headingred'
            >
              Debtors Account (lena hai)
            </div>
            <table className="banking_detail_table table-color table">
              <thead>
                <tr>
                  <th scope="col" style={{ background: "lightgrey" }}>
                    Account
                  </th>
                  <th
                    scope="col"
                    style={{ textAlign: "right", background: "lightgrey" }}
                  >
                    Client (P/L)
                  </th>
                  <th
                    scope="col"
                    style={{ textAlign: "right", background: "lightgrey" }}
                  >
                    Settle Amount
                  </th>
                  <th
                    scope="col"
                    style={{ textAlign: "right", background: "lightgrey" }}
                  >
                    Remark
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>amith gowda</td>
                  <td style={{ color: "red", textAlign: "right" }}>82.80</td>
                  <td style={{ textAlign: "right" }}>
                    <div>
                      <input
                        type="number"
                        placeholder="Amount"
                        defaultValue=""
                      />
                      <button
                       className='fullsettlered'
                      >
                        Full Settle
                      </button>
                    </div>
                  </td>
                  <td style={{ textAlign: "right" }}>
                    <div>
                      <input
                        type="text"
                        placeholder="Remarks"
                        defaultValue=""
                      />
                    </div>
                  </td>
                </tr>
                
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <div
        className="paymoney d-flex justify-content-center align-items-center"
        style={{ paddingTop: 0 }}
      >
        <form className="paymoney_form justify-content-center">
          <input
            placeholder="Password"
            name="password"
            type="password"
            className="form-control"
          />
          <button
            type="submit"
            className="btn green-btn"
            style={{ color: "black", marginRight: 5 }}
          >
            Submit Payment
          </button>
          <button className="clear_btn btn" type="button">
            Clear All
          </button>
        </form>
      </div>
      <div />
    </div>
  </div>
</section>

    </div>
  )
}

export default Settlement
