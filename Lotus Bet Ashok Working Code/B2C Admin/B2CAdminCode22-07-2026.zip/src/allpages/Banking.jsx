import React, { useState } from 'react';

const Banking = () => {
  // State for search and filters
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  
  // State for expanded rows - track which rows are expanded
  const [expandedRows, setExpandedRows] = useState({});
  
  // State for deposit/withdraw values
  const [dwValues, setDwValues] = useState({});
  
  // State for remark values
  const [remarks, setRemarks] = useState({});
  
  // State for credit reference edits
  const [creditRefs, setCreditRefs] = useState({});
  const [editingCreditRef, setEditingCreditRef] = useState(null);
  const [tempCreditRef, setTempCreditRef] = useState({});
  
  // State for payment form
  const [password, setPassword] = useState('');
  const [selectedPayments, setSelectedPayments] = useState([]);

  // Mock data - all members with their data
  const [members] = useState([
    {
      id: '686b99e23b16954f6d69eccc',
      name: 'abhishek gandhi',
      balance: 50137.22,
      availableDW: 50000.00,
      exposure: 0.00,
      creditReference: 50137.22,
      referencePL: 0.00,
      isExpanded: false,
      gameBalances: { SABA: 0, 'Sky Trader': 0, 'Royal Gaming': 0, BPoker: 0, Casino: 0 }
    },
    {
      id: '6a47beeb38a6d18c7136a217',
      name: 'agent001',
      balance: 0.00,
      availableDW: 0.00,
      exposure: 0.00,
      creditReference: 0.00,
      referencePL: 0,
      isExpanded: false,
      gameBalances: { SABA: 0, 'Sky Trader': 0, 'Royal Gaming': 0, BPoker: 0, Casino: 0 }
    },
    {
      id: '67d54134b431a39a37ae995b',
      name: 'agvip',
      balance: 738202.74,
      availableDW: 657939.93,
      exposure: 10794.20,
      creditReference: 700000.00,
      referencePL: 38202.74,
      isExpanded: false,
      gameBalances: { SABA: 0, 'Sky Trader': 0, 'Royal Gaming': 0, BPoker: 0, Casino: 0 }
    },
    {
      id: '68615d6924307bd4f5c8ee4d',
      name: 'ambu010',
      balance: 941864.09,
      availableDW: 907750.55,
      exposure: 2910.00,
      creditReference: 930400.00,
      referencePL: 11464.09,
      isExpanded: false,
      gameBalances: { SABA: 0, 'Sky Trader': 0, 'Royal Gaming': 0, BPoker: 0, Casino: 0 }
    },
    {
      id: '68e7c39cb1e4aa4a399e8fa1',
      name: 'amith gowda',
      balance: 49917.20,
      availableDW: 49140.08,
      exposure: 0.00,
      creditReference: 50000.00,
      referencePL: -82.80,
      isExpanded: false,
      gameBalances: { SABA: 0, 'Sky Trader': 0, 'Royal Gaming': 0, BPoker: 0, Casino: 0 }
    },
    {
      id: '6878e1807dccafb820985c7f',
      name: 'anji1444',
      balance: 20000.00,
      availableDW: 19999.44,
      exposure: 0.00,
      creditReference: 20000.00,
      referencePL: 0.00,
      isExpanded: false,
      gameBalances: { SABA: 0, 'Sky Trader': 0, 'Royal Gaming': 0, BPoker: 0, Casino: 0 }
    },
    // Add all other members here...
  ]);

  // Calculate totals
  const totals = members.reduce((acc, member) => ({
    balance: acc.balance + member.balance,
    availableDW: acc.availableDW + member.availableDW,
    exposure: acc.exposure + member.exposure,
    creditReference: acc.creditReference + member.creditReference,
    referencePL: acc.referencePL + member.referencePL
  }), { balance: 0, availableDW: 0, exposure: 0, creditReference: 0, referencePL: 0 });

  // Toggle row expansion - using ID to track
  const toggleRow = (id) => {
    setExpandedRows(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  // Handle deposit/withdraw toggle
  const handleDWToggle = (id, type) => {
    console.log(`DW ${type} for ${id}`);
  };

  // Handle DW value change
  const handleDWValueChange = (id, value) => {
    setDwValues(prev => ({
      ...prev,
      [id]: value
    }));
  };

  // Handle Full button click
  const handleFullClick = (id) => {
    const member = members.find(m => m.id === id);
    if (member) {
      setDwValues(prev => ({
        ...prev,
        [id]: member.balance
      }));
    }
  };

  // Handle remark change
  const handleRemarkChange = (id, value) => {
    setRemarks(prev => ({
      ...prev,
      [id]: value
    }));
  };

  // Handle credit reference edit
  const handleCreditRefEdit = (id) => {
    const member = members.find(m => m.id === id);
    setTempCreditRef(prev => ({
      ...prev,
      [id]: member ? member.creditReference : 0
    }));
    setCreditRefs(prev => ({
      ...prev,
      [id]: member ? member.creditReference : 0
    }));
    setEditingCreditRef(id);
  };

  const handleCreditRefChange = (id, value) => {
    setCreditRefs(prev => ({
      ...prev,
      [id]: value
    }));
  };

  const handleCreditRefSave = (id) => {
    // Here you would save to API
    console.log(`Saved credit reference for ${id}: ${creditRefs[id]}`);
    setEditingCreditRef(null);
  };

  const handleCreditRefCancel = (id) => {
    setCreditRefs(prev => ({
      ...prev,
      [id]: tempCreditRef[id] || 0
    }));
    setEditingCreditRef(null);
  };

  // Handle search
  const handleSearch = () => {
    console.log('Searching for:', searchTerm);
  };

  // Handle status filter
  const handleStatusChange = (e) => {
    setStatusFilter(e.target.value);
  };

  // Handle reset
  const handleReset = () => {
    setSearchTerm('');
    setStatusFilter('');
  };

  // Handle clear all
  const handleClearAll = () => {
    setSelectedPayments([]);
  };

  // Handle payment submit
  const handlePaymentSubmit = (e) => {
    e.preventDefault();
    console.log('Processing payments:', selectedPayments);
  };

  // Handle log click
  const handleLogClick = (id) => {
    console.log('View logs for:', id);
  };

  // Handle recall
  const handleRecall = (id, game) => {
    console.log(`Recall ${game} for ${id}`);
  };

  const handleRecallAll = (id) => {
    console.log(`Recall all games for ${id}`);
  };

  return (
    <div className="allcommon">
      <section className="main-inner-outer">
        <div className="container-fluid">
          <div className="find-member-sec search_banking_detail">
            <div className="db-sec">
              <h2 className="common-heading page-title">Banking</h2>
            </div>
            
            {/* Search Form */}
            <form id="searchForm" className="">
              <div className="position-relative">
                <input
                  placeholder="Find member..."
                  type="text"
                  className="form-control"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <i className="fas fa-search" />
                <button 
                  type="button" 
                  className="search-btn btn btn-primary"
                  onClick={handleSearch}
                >
                  Search
                </button>
              </div>
              <div className="d-flex align-items-center ps-3 mb-3 mb-sm-0">
                <label className="pe-3 mb-0 form-label">Status</label>
                <select 
                  aria-label="Default select example" 
                  className="form-select"
                  value={statusFilter}
                  onChange={handleStatusChange}
                >
                  <option value="active">Active</option>
                  <option value="suspend">Suspend</option>
                  <option value="locked">Locked</option>
                  <option value="">All</option>
                </select>
              </div>
              <button className="btn" type="button" onClick={handleReset}>
                <i className="fas fa-redo-alt" />
              </button>
            </form>

            <div className="inner-wrapper">
              <div className="common-container">
                {/* Balance Display */}
                <div className="bet_status bank_balance_detail d-sm-flex align-items-center my-1 my-sm-3">
                  <h6 className="mb-0">Your Balance</h6>
                  <strong>
                    <small>INR</small>10,385,474.21
                  </strong>
                </div>

                {/* Table */}
                <div className="account-table batting-table banking-table">
                  <div className="responsive">
                    <table className="banking_detail_table table-color table">
                      <thead>
                        <tr>
                          <th scope="col">UID</th>
                          <th scope="col" style={{ textAlign: 'right' }}>Balance</th>
                          <th scope="col" style={{ textAlign: 'right' }}>Available D/W</th>
                          <th scope="col" style={{ textAlign: 'right' }}>Exposure</th>
                          <th scope="col" style={{ textAlign: 'center' }}>Deposit / Withdraw</th>
                          <th scope="col" style={{ textAlign: 'right' }}>Credit Reference</th>
                          <th scope="col" style={{ textAlign: 'right', width: 180 }}>Reference P/L</th>
                          <th scope="col" style={{ textAlign: 'right', width: '5%' }}>Remark</th>
                          <th scope="col" style={{ textAlign: 'right', width: 110 }}>
                            <button
                              className="btn green-btn"
                              style={{ padding: '3px 10px' }}
                            >
                              Logs
                            </button>
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {members.map((member) => (
                          <React.Fragment key={member.id}>
                            {/* Main Row */}
                            <tr>
                              <td>
                                <span className="list_number" />
                                {member.name}
                              </td>
                              <td>
                                {member.balance.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                <i
                                  id={`icon_${member.id}`}
                                  className={`fas ${expandedRows[member.id] ? 'fa-minus-square' : 'fa-plus-square'} pe-2`}
                                  onClick={() => toggleRow(member.id)}
                                  style={{ cursor: 'pointer' }}
                                />
                              </td>
                              <td>{member.availableDW.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                              <td>{member.exposure.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                              <td className="check_date" />
                              <td className="border-x" width={320}>
                                <div className="deposite-withdraw medium_width">
                                  <div className="dw-toggle">
                                    <div className="tgl_btn">
                                      <input
                                        type="radio"
                                        name={`DW_${member.id}`}
                                        defaultChecked={false}
                                        onChange={() => handleDWToggle(member.id, 'deposit')}
                                      />
                                      <label className="bg-green">D</label>
                                    </div>
                                    <div className="tgl_btn">
                                      <input
                                        type="radio"
                                        name={`DW_${member.id}`}
                                        defaultChecked={true}
                                        onChange={() => handleDWToggle(member.id, 'withdraw')}
                                      />
                                      <label className="bg-red">W</label>
                                    </div>
                                  </div>
                                  <div className="dw-value_text_box">
                                    <input
                                      type="number"
                                      min={1}
                                      className="text-end form-control"
                                      id={`user_${member.id}`}
                                      value={dwValues[member.id] || ''}
                                      onChange={(e) => handleDWValueChange(member.id, e.target.value)}
                                    />
                                    <span className={`dw-graph-position ${dwValues[member.id] ? 'text-success' : 'text-danger'}`}>
                                      {dwValues[member.id] ? '+' : '-'}
                                    </span>
                                  </div>
                                  <button
                                    className={`btn ${dwValues[member.id] ? 'theme_light_btn' : 'disabled theme_light_btn'}`}
                                    onClick={() => handleFullClick(member.id)}
                                  >
                                    Full
                                  </button>
                                </div>
                                {member.id === '686b99e23b16954f6d69eccc' && (
                                  <span style={{ fontSize: 12, color: 'red' }}>
                                    Amount should be greater then 0
                                  </span>
                                )}
                              </td>
                              <td>
                                <span style={{ marginRight: 10 }}>
                                  {member.creditReference.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                </span>
                                {editingCreditRef === member.id ? (
                                  <div style={{ display: 'flex', gap: '5px', alignItems: 'center' }}>
                                    <input
                                      type="number"
                                      style={{ width: '100px' }}
                                      value={creditRefs[member.id] || member.creditReference}
                                      onChange={(e) => handleCreditRefChange(member.id, e.target.value)}
                                      autoFocus
                                    />
                                    <button 
                                      className="btn btn-success btn-sm"
                                      onClick={() => handleCreditRefSave(member.id)}
                                      style={{ padding: '2px 8px', fontSize: '12px' }}
                                    >
                                      Save
                                    </button>
                                    <button 
                                      className="btn btn-danger btn-sm"
                                      onClick={() => handleCreditRefCancel(member.id)}
                                      style={{ padding: '2px 8px', fontSize: '12px' }}
                                    >
                                      Cancel
                                    </button>
                                  </div>
                                ) : (
                                  <button 
                                    className="btn theme_light_btn"
                                    onClick={() => handleCreditRefEdit(member.id)}
                                  >
                                    Edit
                                  </button>
                                )}
                              </td>
                              <td className="border-x">
                                <span style={{ color: member.referencePL >= 0 ? 'green' : 'red' }}>
                                  {member.referencePL.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                </span>
                              </td>
                              <td>
                                <form className="">
                                  <input
                                    placeholder="Remark"
                                    type="text"
                                    className="form-control"
                                    value={remarks[member.id] || ''}
                                    onChange={(e) => handleRemarkChange(member.id, e.target.value)}
                                  />
                                </form>
                              </td>
                              <td>
                                <button 
                                  type="button" 
                                  className="btn theme_light_btn"
                                  onClick={() => handleLogClick(member.id)}
                                >
                                  Log
                                </button>
                              </td>
                            </tr>

                            {/* Expanded Row - Game Balances */}
                            <tr
                              id={member.id}
                              className="expand-balance light_blue"
                              style={{ display: expandedRows[member.id] ? 'contents' : 'none' }}
                            >
                              <td></td>
                              <td colSpan="10" className="p-0 large_table_data">
                                <table className="inner_table">
                                  <tbody>
                                    <tr>
                                      <th style={{ width: '9%' }}>Game</th>
                                      <th style={{ width: '11%' }}>Balance</th>
                                      <th style={{ width: '7%' }}>
                                        <a 
                                          href="#" 
                                          onClick={(e) => { 
                                            e.preventDefault(); 
                                            handleRecallAll(member.id); 
                                          }}
                                        >
                                          Recall All
                                        </a>
                                      </th>
                                      <th></th>
                                    </tr>
                                    {Object.entries(member.gameBalances).map(([game, balance]) => (
                                      <tr key={game}>
                                        <td>{game}</td>
                                        <td>{balance}</td>
                                        <td>
                                          <a 
                                            href="#" 
                                            onClick={(e) => { 
                                              e.preventDefault(); 
                                              handleRecall(member.id, game); 
                                            }}
                                          >
                                            Recall
                                          </a>
                                        </td>
                                        <td></td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </td>
                            </tr>
                          </React.Fragment>
                        ))}

                        {/* Total Row */}
                        <tr style={{ fontWeight: 500 }}>
                          <td>Total</td>
                          <td>{totals.balance.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                          <td>{totals.availableDW.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                          <td>{totals.exposure.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                          <td></td>
                          <td>{totals.creditReference.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                          <td>{totals.referencePL.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                          <td></td>
                          <td></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>

                  {/* Pagination */}
                  <div className="bottom-pagination">
                    <ul role="navigation" aria-label="Pagination">
                      <li className="previous disabled">
                        <a
                          className=""
                          tabIndex={-1}
                          role="button"
                          aria-disabled="true"
                          aria-label="Previous page"
                          rel="prev"
                        >
                          &lt;
                        </a>
                      </li>
                      <li className="p-0">
                        <a
                          rel="canonical"
                          role="button"
                          className="pagintion-li"
                          tabIndex={-1}
                          aria-label="Page 1 is your current page"
                          aria-current="page"
                        >
                          1
                        </a>
                      </li>
                      <li className="next disabled">
                        <a
                          className=""
                          tabIndex={-1}
                          role="button"
                          aria-disabled="true"
                          aria-label="Next page"
                          rel="next"
                        >
                          &gt;
                        </a>
                      </li>
                    </ul>
                  </div>

                  {/* Payment Form */}
                  <div className="paymoney d-flex justify-content-center align-items-center">
                    <form className="paymoney_form justify-content-center" onSubmit={handlePaymentSubmit}>
                      <button className="clear_btn btn" type="button" onClick={handleClearAll}>
                        Clear All
                      </button>
                      <input
                        placeholder="Password"
                        name="password"
                        type="password"
                        className="form-control"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                      />
                      <button type="submit" className="btn green-btn">
                        Submit <span className="payment_count">{selectedPayments.length}</span> Payment
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Banking; 