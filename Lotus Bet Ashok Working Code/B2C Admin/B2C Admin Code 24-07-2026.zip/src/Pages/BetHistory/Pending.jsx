import React, { useEffect, useState } from "react";
import { MdFilterListAlt } from "react-icons/md";

function Pending() {
  const [allBets, setAllBets] = useState([]);
  const [AllMarketList, setAllMarketList] = useState([]);
  const [GameRateList, setGameRateList] = useState([]);
  const [bets, setBets] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [limit] = useState(10);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(false);
  const [inputFilters, setInputFilters] = useState({
    user_name: "",
    mobile: "",
    market_type: "",
    game_type: "",
    market_id: "",
  });
  const [searchTriggered, setSearchTriggered] = useState(false);
  const token = localStorage.getItem("token");

  useEffect(() => {
    fetchPendingBets(currentPage);
    // fetchMarketlist();
  }, [currentPage]);
  const handleInputChange = (e) => {
    setInputFilters({
      ...inputFilters,
      [e.target.name]: e.target.value,
    });
  };

  const handleReset = () => {
    setInputFilters({
      user_name: "",
      mobile: "",
      market_type: "",
      game_type: "",
      market_id: "",
    });
    setCurrentPage(1);
    setBets(allBets);
    setTotalPages(Math.ceil(allBets.length / limit));
    setSearchTriggered(false);
  };
  const handlePrev = () => {
    if (currentPage > 1) setCurrentPage(currentPage - 1);
  };
  const handleNext = () => {
    if (currentPage < totalPages) setCurrentPage(currentPage + 1);
  };
  const toSentenceCase = (text) => {
    if (!text) return "";
    return text
      .split("_")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(" ");
  };
  const paginatedBets = bets.slice(
    (currentPage - 1) * limit,
    currentPage * limit
  );
  const [fillter, setFillter] = useState(false);

  const fillterdata = () => {
    setFillter((prev) => !prev);
  };
  const [FilterUsername, setFilterUsername] = useState("");
  const [FilterMarkettype, setfilterMarkettype] = useState("");
  const [FilterMarketname, setFilterMarketname] = useState("");
  const [FilterGameType, setFilterGameType] = useState("");
  const [FilterSession, setFilterSession] = useState("");
  const [selectedStartDate, setselectedStartDate] = useState("");
  const [selectedEndDate, setselectedEndDate] = useState("");
  // Search handler

  const handleSearchChangeusername = (e) => {
    const value = e.target.value.toLowerCase();
    setFilterUsername(value);
  };

  const handleChangeMarketName = (e) => {
    const value = e.target.value;
    // alert(value);
    setFilterMarketname(value);
  };
  const handleChangeGameType = (e) => {
    const value = e.target.value.toLowerCase();
    setFilterGameType(value);
  };
  const handleChangeSession = (e) => {
    const value = e.target.value.toLowerCase();
    setFilterSession(value);
  };
  const setSelectedStartDate = (e) => {
    const value = e;
    setselectedStartDate(value);
  };
  const setSelectedEndDate = (e) => {
    const value = e;
    setselectedEndDate(value);
  };
  const handleChangeMarkettype = (e) => {
    const value = e.target.value.toLowerCase();
    // alert(value);
    setfilterMarkettype(value);
    fetchMarketlist(value);
    fetchGametype(value);
  };
  const handleFilter = (e) => {
    fetchPendingBets();
  };
  const fetchPendingBets = async (page = 1) => {
    setLoading(true);
    try {
      const res = await fetch(
        `${
          process.env.REACT_APP_API_URL
        }/gameloadbet-list?page=${page.toString()}&limit=${limit.toString()}&username=${FilterUsername}&markettype=${FilterMarkettype}&marketname=${FilterMarketname}&gametype=${FilterGameType}&session=${FilterSession}&startdate=${selectedStartDate}&enddate=${selectedEndDate}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );
      const data = await res.json();
      if (res.ok) {
        const betsData = data.data || [];
        setAllBets(betsData);
        setBets(betsData);
        setTotalPages(Number(data.totalNumberPage) || 1);
      } else {
        setAllBets([]);
        setBets([]);
      }
    } catch (error) {
      setAllBets([]);
      setBets([]);
    } finally {
      setLoading(false);
    }
  };
  const fetchGametype = async (value) => {
    setLoading(true);
    try {
      const res = await fetch(
        `${process.env.REACT_APP_API_URL}/game-list-all?market_type=${value}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );
      const data = await res.json();
      if (res.ok) {
        const betsData = data.data || [];
        setGameRateList(betsData);
      } else {
      }
    } catch (error) {
    } finally {
      setLoading(false);
    }
  };
  const fetchMarketlist = async (value) => {
    setLoading(true);
    try {
      const res = await fetch(
        `${process.env.REACT_APP_API_URL}/market-list-all?market_type=${value}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );
      const data = await res.json();
      if (res.ok) {
        const betsData = data.data || [];
        setAllMarketList(betsData);
      } else {
      }
    } catch (error) {
    } finally {
      setLoading(false);
    }
  };
  return (
    <div className="betlists">
      <div className="card">
        <div className="card-header">
          <div className="d-flex align-items-center justify-content-between">
            <h3 className="card-title text-white">Bet Pending List</h3>
            <div className="buttonlist">
              <div className="btn btn-light" onClick={fillterdata}>
                <MdFilterListAlt /> Filter
              </div>
            </div>
          </div>
        </div>

        {fillter && (
          <div className="card-body">
            <div className="row">
              <div className="col-md-12">
                <div className="form-design-fillter gap-2 d-flex justify-content-between align-items-end">
                  <div className="form_latest_design w-100">
                    <div className="label">
                      <label htmlFor="">User Name</label>
                    </div>
                    <input
                      type="text"
                      name="user_name"
                      className="form-control"
                      value={FilterUsername}
                      onChange={handleSearchChangeusername}
                    />
                  </div>
                  <div className="form_latest_design w-100">
                    <div className="label">
                      <label htmlFor="">Market Type</label>
                    </div>
                    <select
                      name="user_name"
                      className="form-control"
                      value={FilterMarkettype}
                      onChange={handleChangeMarkettype}
                    >
                      <option value="">Market Type</option>
                      <option value="mainmarket">Main Market</option>
                      <option value="kingstarline">King Starline</option>
                      <option value="kingjackport">King JackPot</option>
                    </select>
                  </div>
                  <div className="form_latest_design w-100">
                    <div className="label">
                      <label htmlFor="">Market Name</label>
                    </div>
                    <select
                      name="user_name"
                      className="form-control"
                      value={FilterMarketname}
                      onChange={handleChangeMarketName}
                    >
                      <option value="">Market</option>
                      {AllMarketList.map((user, index) => (
                        <option key={index} value={user.market_id}>
                          {user.market_name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="form_latest_design w-100">
                    <div className="label">
                      <label htmlFor="">Game Type</label>
                    </div>
                    <select
                      name="user_name"
                      className="form-control"
                      value={FilterGameType}
                      onChange={handleChangeGameType}
                    >
                      <option value="">Market Type</option>
                      {GameRateList.map((user, index) => (
                        <option key={index} value={user.name_slug}>
                          {user.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="form_latest_design w-100">
                    <div className="label">
                      <label htmlFor="">Session Type</label>
                    </div>
                    <select
                      name="user_name"
                      className="form-control"
                      value={FilterSession}
                      onChange={handleChangeSession}
                    >
                      <option value="">Session Type</option>
                      <option value="open">Open</option>
                      <option value="close">Close</option>
                    </select>
                  </div>
                  <div className="form_latest_design w-100">
                    <div className="label">
                      <label htmlFor="">Start Date</label>
                    </div>
                    <input
                      type="date"
                      className="form-control"
                      value={selectedStartDate}
                      onChange={(e) => setSelectedStartDate(e.target.value)}
                    />
                  </div>
                  <div className="form_latest_design w-100">
                    <div className="label">
                      <label htmlFor="">End Date</label>
                    </div>
                    <input
                      type="date"
                      className="form-control"
                      value={selectedEndDate}
                      onChange={(e) => setSelectedEndDate(e.target.value)}
                    />
                  </div>
                  <div className="form_latest_design w-100">
                    <button
                      className="btn btn-primary"
                      onClick={handleFilter}
                    >
                      Filter
                    </button>
                  </div>
                  {/* <di className="form_latest_design w-100"v>
                  <button className="btn btn-secondary">helo</button>
                </di> */}
                </div>
              </div>
            </div>
          </div>
        )}
        {/* <div className="card-header">
          <div className="d-flex align-items-center justify-content-between">
            <h3 className="card-title text-white">Pending Bets</h3>
          </div>
        </div> */}
        <div className="card-body">
          {/* <div className="row mb-2">
            <div className="col-md-2 col-6">
              <div className="form-design-fillter d-flex justify-content-end">
                <input
                  type="text"
                  name="user_name"
                  className="form-control"
                  placeholder=" User Name"
                  value={inputFilters.user_name}
                  onChange={handleInputChange}
                />
              </div>
            </div>
            <div className="col-md-2 col-6">
              <input
                type="text"
                name="mobile"
                className="form-control"
                placeholder=" Mobile"
                value={inputFilters.mobile}
                onChange={handleInputChange}
              />
            </div>
            <div className="col-md-2 col-6">
              <input
                type="text"
                name="market_type"
                className="form-control"
                placeholder=" Market Type"
                value={inputFilters.market_type}
                onChange={handleInputChange}
              />
            </div>
            <div className="col-md-2 col-6">
              <input
                type="text"
                name="game_type"
                className="form-control"
                placeholder=" Game Type"
                value={inputFilters.game_type}
                onChange={handleInputChange}
              />
            </div>

            <div className="col-md-2 col-6">
              <input
                type="text"
                name="market_id"
                className="form-control"
                placeholder=" Market ID"
                value={inputFilters.market_id}
                onChange={handleInputChange}
              />
            </div>
            <div className="col-md-2 col-6">
              <div className="d-flex align-items-center gap-2">
                <button className="btn btn-success me-2" onClick={handleSearch}>
                  Search
                </button>
                <button className="btn btn-secondary" onClick={handleReset}>
                  Reset
                </button>
              </div>
            </div>
          </div> */}

          {loading && <p>Loading pending bets...</p>}

          <div className="table-responsive">
            <table className="table table-bordered">
              <thead>
                <tr>
                  <th>Sr.</th>
                  <th>User Name</th>
                  {/* <th>Mobile</th> */}
                  <th>Market Type</th>
                  <th>Game Type</th>
                  <th>Market ID</th>
                  <th>Bet Key</th>
                  <th>Bet Amount</th>
                  <th>Session</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                {!loading && allBets.length === 0 ? (
                  <tr>
                    <td
                      colSpan="10"
                      className="text-center text-danger fw-bold"
                    >
                      Sorry, no data found.
                    </td>
                  </tr>
                ) : (
                  allBets.map((bet, index) => (
                    <tr key={index}>
                      <td>{(currentPage - 1) * limit + index + 1}</td>
                      <td>
                        {bet.user_name
                          ? bet.user_name.charAt(0).toUpperCase() +
                            bet.user_name.slice(1).toLowerCase()
                          : ""}
                      </td>
                      {/* <td>{bet.mobile}</td> */}
                      <td>{toSentenceCase(bet.market_type)}</td>
                      <td>{toSentenceCase(bet.game_type_name)}</td>
                      <td>{bet.market_id}</td>
                      <td>
                        {[
                          "choice_sp_dp_tp",
                          "triple_pana",
                          "penal_group",
                        ].includes(bet.game_type_name) && bet.bet_key == 0
                          ? "000"
                          : bet.bet_key}
                      </td>
                      <td>Rs {bet.bet_amount}</td>
                      <td>
                        <span
                          className={`badge ${
                            bet.session === "open"
                              ? "bg-success"
                              : bet.session === "close"
                              ? "bg-danger"
                              : "bg-secondary"
                          }`}
                        >
                          {toSentenceCase(bet.session)}
                        </span>
                      </td>
                      {/* <td>{bet.date_time}</td> */}
                      <td>
                        {new Date(bet.date_time)
                          .toLocaleString("en-IN", {
                            day: "2-digit",
                            month: "2-digit",
                            year: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                            hour12: true,
                          })
                          .replaceAll("/", "-")
                          .toUpperCase()}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {bets.length > 0 && (
            <div className="d-flex justify-content-between align-items-center mt-3">
              <button
                className="paginationbutton"
                onClick={handlePrev}
                disabled={currentPage === 1}
              >
                Previous
              </button>

              <span className="alllistnumber">
                Page {currentPage} of {totalPages}
              </span>

              <button
                className="paginationbutton"
                onClick={handleNext}
                disabled={currentPage === totalPages}
              >
                Next
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default Pending;
