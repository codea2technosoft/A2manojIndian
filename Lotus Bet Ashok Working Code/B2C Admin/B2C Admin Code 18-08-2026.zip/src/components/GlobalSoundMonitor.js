import React, { useEffect, useRef } from "react";

const GlobalSoundMonitor = () => {
  const prevIds = useRef([]);
  const isFirstRun = useRef(true);

  const audioRef = useRef(null);
  const isSoundEnabled = useRef(false);

  // ==========================================
  // CREATE AUDIO
  // ==========================================
  const createAudio = () => {
    if (audioRef.current) {
      return audioRef.current;
    }

    const audio = new Audio();

    // Important
    audio.preload = "auto";

    // Volume
    audio.volume = 1;

    audioRef.current = audio;

    return audio;
  };

  // ==========================================
  // ENABLE SOUND - FIRST TIME CLICK
  // ==========================================
 const enableSound = async () => {
  try {
    const AudioContext =
      window.AudioContext || window.webkitAudioContext;

    if (!AudioContext) {
      console.log("❌ AudioContext not supported");
      return;
    }

    let ctx = audioCtxRef.current;

    if (!ctx) {
      ctx = new AudioContext();
      audioCtxRef.current = ctx;
    }

    // User click ke time resume hoga
    if (ctx.state === "suspended") {
      await ctx.resume();
    }

    // Test beep
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.type = "sine";
    osc.frequency.value = 800;

    gain.gain.setValueAtTime(0.3, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(
      0.01,
      ctx.currentTime + 0.3
    );

    osc.start();
    osc.stop(ctx.currentTime + 0.3);

    isSoundEnabled.current = true;

    // Save
    localStorage.setItem("sound_enabled", "true");

    console.log("✅ SOUND ENABLED");
    console.log("Audio state:", ctx.state);

    const btn =
      document.getElementById("enable-sound-btn");

    if (btn) {
      btn.remove();
    }

  } catch (error) {
    console.log(
      "❌ Enable sound error:",
      error
    );
  }
};

  // ==========================================
  // INITIALIZE AFTER REFRESH
  // ==========================================
 const initializeAudio = async () => {
  try {
    const savedSound =
      localStorage.getItem("sound_enabled");

    if (savedSound !== "true") {
      return;
    }

    const AudioContext =
      window.AudioContext ||
      window.webkitAudioContext;

    if (!AudioContext) {
      return;
    }

    const ctx = new AudioContext();

    audioCtxRef.current = ctx;

    console.log(
      "🔊 Audio created after refresh"
    );

    console.log(
      "🔊 Audio state:",
      ctx.state
    );

    isSoundEnabled.current = true;

    // Try resume
    if (ctx.state === "suspended") {
      try {
        await ctx.resume();

        console.log(
          "🔊 Audio resumed:",
          ctx.state
        );
      } catch (error) {
        console.log(
          "⚠️ Browser blocked resume:",
          error
        );
      }
    }

  } catch (error) {
    console.log(
      "❌ initializeAudio error:",
      error
    );
  }
};

  // ==========================================
  // PLAY SOUND
  // ==========================================
 const playSound = async () => {

  console.log("🔔 New Deposit Detected!");

  let ctx = audioCtxRef.current;

  if (!ctx) {
    console.log(
      "⚠️ AudioContext missing, creating..."
    );

    const AudioContext =
      window.AudioContext ||
      window.webkitAudioContext;

    if (!AudioContext) {
      return;
    }

    ctx = new AudioContext();

    audioCtxRef.current = ctx;
  }

  // IMPORTANT
  if (ctx.state === "suspended") {
    try {
      await ctx.resume();

      console.log(
        "🔊 Resumed audio:",
        ctx.state
      );
    } catch (error) {
      console.log(
        "❌ Resume failed:",
        error
      );
    }
  }

  console.log(
    "🔊 FINAL AUDIO STATE:",
    ctx.state
  );

  if (ctx.state !== "running") {
    console.log(
      "❌ AudioContext is not running"
    );
    return;
  }

  // ==================================
  // YOUR EXISTING SOUND CODE
  // ==================================

  try {

    const osc1 =
      ctx.createOscillator();

    const gain1 =
      ctx.createGain();

    osc1.connect(gain1);
    gain1.connect(ctx.destination);

    osc1.frequency.value = 880;
    osc1.type = "sine";

    gain1.gain.setValueAtTime(
      0.3,
      ctx.currentTime
    );

    gain1.gain.exponentialRampToValueAtTime(
      0.01,
      ctx.currentTime + 0.3
    );

    osc1.start();

    osc1.stop(
      ctx.currentTime + 0.3
    );

    setTimeout(() => {

      try {

        const osc2 =
          ctx.createOscillator();

        const gain2 =
          ctx.createGain();

        osc2.connect(gain2);
        gain2.connect(
          ctx.destination
        );

        osc2.frequency.value = 1100;
        osc2.type = "sine";

        gain2.gain.setValueAtTime(
          0.3,
          ctx.currentTime
        );

        gain2.gain.exponentialRampToValueAtTime(
          0.01,
          ctx.currentTime + 0.2
        );

        osc2.start();

        osc2.stop(
          ctx.currentTime + 0.2
        );

      } catch (e) {
        console.log(
          "Sound 2 error:",
          e
        );
      }

    }, 200);

    setTimeout(() => {

      try {

        const osc3 =
          ctx.createOscillator();

        const gain3 =
          ctx.createGain();

        osc3.connect(gain3);
        gain3.connect(
          ctx.destination
        );

        osc3.frequency.value = 1320;
        osc3.type = "sine";

        gain3.gain.setValueAtTime(
          0.3,
          ctx.currentTime
        );

        gain3.gain.exponentialRampToValueAtTime(
          0.01,
          ctx.currentTime + 0.25
        );

        osc3.start();

        osc3.stop(
          ctx.currentTime + 0.25
        );

      } catch (e) {
        console.log(
          "Sound 3 error:",
          e
        );
      }

    }, 400);

    console.log("✅ SOUND PLAYED");

  } catch (error) {

    console.log(
      "❌ Sound error:",
      error
    );

  }
};

  // ==========================================
  // ENABLE BUTTON
  // ==========================================
  const showEnableSoundButton = () => {
    if (
      document.getElementById(
        "enable-sound-btn"
      )
    ) {
      return;
    }

    const btn =
      document.createElement(
        "button"
      );

    btn.id =
      "enable-sound-btn";

    btn.innerHTML =
      "🔊 Click to Enable Sound";

    btn.style.cssText = `
      position: fixed;
      bottom: 20px;
      left: 50%;
      transform: translateX(-50%);

      background:
        linear-gradient(
          135deg,
          #667eea 0%,
          #764ba2 100%
        );

      color: white;
      border: none;

      padding: 14px 28px;

      border-radius: 50px;

      font-size: 16px;
      font-weight: bold;

      z-index: 999999;

      box-shadow:
        0 8px 30px
        rgba(0,0,0,0.3);

      cursor: pointer;

      animation:
        pulse 1.5s
        ease-in-out
        infinite;
    `;

    const style =
      document.createElement(
        "style"
      );

    style.textContent = `
      @keyframes pulse {

        0%, 100% {
          transform:
            translateX(-50%)
            scale(1);
        }

        50% {
          transform:
            translateX(-50%)
            scale(1.05);
        }

      }
    `;

    document.head.appendChild(
      style
    );

    btn.onclick = () => {
      enableSound();
    };

    document.body.appendChild(
      btn
    );
  };

  // ==========================================
  // CHECK DEPOSITS
  // ==========================================
  const checkDeposits = async () => {
    try {
      const token =
        localStorage.getItem(
          "token"
        );

      const response =
        await fetch(
          `${process.env.REACT_APP_API_URL}/all_deposit_request?page=1&limit=50&status=pending`,
          {
            method: "GET",

            headers: {
              "Content-Type":
                "application/json",

              Authorization:
                `Bearer ${token}`,
            },
          }
        );

      const text =
        await response.text();

      let data;

      try {
        data =
          JSON.parse(text);
      } catch (e) {
        console.log(
          "⚠️ Response is not JSON:",
          text.substring(
            0,
            100
          )
        );

        return;
      }

      if (data?.success) {
        const deposits =
          data.data || [];

        const newIds =
          deposits.map(
            (d) => d._id
          );

        // ====================================
        // AFTER FIRST API CALL
        // ====================================

        if (
          !isFirstRun.current
        ) {
          const currentIds =
            prevIds.current;

          const addedIds =
            newIds.filter(
              (id) =>
                !currentIds.includes(
                  id
                )
            );

          if (
            addedIds.length > 0
          ) {
            console.log(
              "🔔 NEW DEPOSIT FOUND!",
              addedIds
            );

            playSound();
          }

        } else {
          isFirstRun.current =
            false;

          console.log(
            "🟢 Global Monitor Started:",
            newIds.length,
            "deposits"
          );
        }

        prevIds.current =
          newIds;
      }

    } catch (error) {
      console.error(
        "❌ Global Monitor Error:",
        error
      );
    }
  };

  // ==========================================
  // USE EFFECT
  // ==========================================
  useEffect(() => {

  if (
    "Notification" in window &&
    Notification.permission === "default"
  ) {
    Notification.requestPermission();
  }

  const soundEnabled =
    localStorage.getItem(
      "sound_enabled"
    );

  if (soundEnabled === "true") {

    console.log(
      "🔊 Saved sound permission found"
    );

    initializeAudio();

  } else {

    setTimeout(() => {
      showEnableSoundButton();
    }, 1000);

  }

  checkDeposits();

  const interval =
    setInterval(
      checkDeposits,
      5000
    );

  return () => {
    clearInterval(interval);

    const btn =
      document.getElementById(
        "enable-sound-btn"
      );

    if (btn) {
      btn.remove();
    }
  };

}, []);

  return null;
};

export default GlobalSoundMonitor;