import { useEffect, useState, useRef } from "react";
import {
  FaUserCircle,
  FaEye,
  FaSignOutAlt,
  FaLockOpen,
  FaLock,
  FaTv,
  FaPlayCircle,
  FaWallet,
  FaArrowUp,
  FaArrowDown,
  FaSyncAlt,
  FaRegPlayCircle,
} from "react-icons/fa";
import { getDashboardClientList, getAllEvents } from "../Server/api";
import { useNavigate, Link, useLocation } from "react-router-dom";
import { IoClose } from "react-icons/io5";
import Loader from "../Common/Loader";
import {
  FaUserTie,
  FaGamepad,
  FaCheckCircle,
  FaChartLine,
  FaBook,
  FaMoneyBillWave,
  FaCogs,
  FaUser,
  FaTrophy,
  FaUsers,
  FaChartBar,
  FaInfoCircle,
} from "react-icons/fa";
import Swal from "sweetalert2";
import {
  MdKeyboardDoubleArrowLeft,
  MdKeyboardDoubleArrowRight,
  MdOutlineKeyboardArrowRight,
} from "react-icons/md";
import { MdOutlineKeyboardArrowLeft } from "react-icons/md";
import cricket from "../asset/image/cricket.png";
import football from "../asset/image/football.png";
import tennis from "../asset/image/tennis.png";
import Competition from "../asset/image/competition.svg";
import Inplay from "../asset/image/inplay.svg";
import Datewise from "../asset/image/date.svg";
import axios from "axios";
import { FaCircleArrowDown, FaCircleArrowUp } from "react-icons/fa6";

/* ---------- Helper ---------- */
function getValue(obj, key) {
  return obj?.[key] ?? 0;
}

const admin_id = localStorage.getItem("admin_id");
console.log("adminid", admin_id);

// Sport mapping - ONLY THESE 3 SPORTS
const SPORT_NAMES = {
  1: "Football",
  2: "Tennis",
  4: "Cricket",
};

const SPORT_COLORS = {
  1: "#45b7d1",
  2: "#4ecdc4",
  4: "#ff6b6b",
};

const SPORT_ICONS = {
  1: football,
  2: tennis,
  4: cricket,
};

const SPORT_ORDER = ["4", "1", "2"];

const TABS = [
  { id: "inplay", label: "Inplay", icon: Inplay },
  { id: "competition", label: "Competition Wise", icon: Competition },
  { id: "date", label: "Date Wise", icon: Datewise },
];

// ✅ Helper function to get values safely
const getSafeValue = (key, defaultValue = 0) => {
  try {
    const value = localStorage.getItem(key);
    if (value === null || value === undefined || value === "") {
      return defaultValue;
    }
    const parsed = parseFloat(value);
    return isNaN(parsed) ? defaultValue : parsed;
  } catch (error) {
    console.error(`Error reading ${key}:`, error);
    return defaultValue;
  }
};

const formatMatchDate = (date) => {
  if (!date) return "N/A";

  // Example: 31/03/2025, 06:30:00 pm
  const [datePart, timePart] = date.split(", ");

  if (!datePart || !timePart) return "N/A";

  const [day, month, year] = datePart.split("/").map(Number);

  let [time, meridian] = timePart.split(" ");
  let [hours, minutes] = time.split(":").map(Number);

  if (meridian.toLowerCase() === "pm" && hours !== 12) {
    hours += 12;
  }
  if (meridian.toLowerCase() === "am" && hours === 12) {
    hours = 0;
  }

  const d = new Date(year, month - 1, day, hours, minutes);

  const formattedDay = d.toLocaleString("en-GB", { day: "2-digit" });
  const formattedMonth = d.toLocaleString("en-GB", { month: "short" });
  const formattedTime = d.toLocaleString("en-GB", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });

  return `${formattedDay} ${formattedMonth} ${formattedTime}`;
};

const getCardConfig = (plData) => {
  const coins = getSafeValue("coins", 0);
  const runningPl = getSafeValue("running_pl", 0);
  const uplinePl = getSafeValue("upline_pl", 0);
  const lifetimePl = getSafeValue("lifetime_pl", 0);

  return [
    {
      label: "BALANCE",
      value: coins,
      valueIcon: "",
      icon: <FaSyncAlt />,
      bg: "#6394c9",
    },
    // {
    //   label: "UPLINE PL",
    //   value: uplinePl,
    //   valueIcon: uplinePl >= 0 ? <FaCircleArrowUp /> : <FaCircleArrowDown />,
    //   icon: <FaSyncAlt />,
    //   bg: uplinePl >= 0 ? "#28a745" : "#fa0e0e",
    // },
    // {
    //   label: "RUNNING PL",
    //   value: plData?.running_pl,
    //   valueIcon: runningPl >= 0 ? <FaCircleArrowUp /> : <FaCircleArrowDown />,
    //   icon: <FaSyncAlt />,
    //   bg: plData.running_pl >= 0 ? "#28a745" : "#fa0e0e",
    // },

    // {
    //   label: "RUNNING PL",
    //   value: plData?.running_pl || 0,
    //   valueIcon:
    //     (plData?.running_pl || 0) >= 0 ? (
    //       <FaCircleArrowUp />
    //     ) : (
    //       <FaCircleArrowDown />
    //     ),
    //   icon: <FaSyncAlt />,
    //   bg: (plData?.running_pl || 0) >= 0 ? "#28a745" : "#fa0e0e",
    // },
    {
      label: "RUNNING PL",
      value: Number(plData?.running_pl || 0).toFixed(2),
      valueIcon:
        Number(plData?.running_pl || 0) >= 0 ? (
          <FaCircleArrowUp />
        ) : (
          <FaCircleArrowDown />
        ),
      icon: <FaSyncAlt />,
      bg: Number(plData?.running_pl || 0) >= 0 ? "#28a745" : "#fa0e0e",
    },

    // {
    //   label: "LIFETIME PL",
    //   value: plData.lifetime_pl,
    //   valueIcon: plData.lifetime_pl >= 0 ? <FaCircleArrowUp /> : <FaCircleArrowDown />,
    //   icon: <FaSyncAlt />,
    //   bg: "#6b00ff",
    // },

    // {
    //   label: "LIFETIME PL",
    //   value: plData?.lifetime_pl || 0,
    //   valueIcon:
    //     (plData?.lifetime_pl || 0) >= 0 ? (
    //       <FaCircleArrowUp />
    //     ) : (
    //       <FaCircleArrowDown />
    //     ),
    //   icon: <FaSyncAlt />,
    //   bg: "#6b00ff",
    // },

    {
  label: "LIFETIME PL",
  value: Number(plData?.lifetime_pl || 0).toFixed(2),
  valueIcon:
    Number(plData?.lifetime_pl || 0) >= 0 ? (
      <FaCircleArrowUp />
    ) : (
      <FaCircleArrowDown />
    ),
  icon: <FaSyncAlt />,
  bg: "#6b00ff",
},

  ];
};

/* ---------- Global Modal ---------- */
const GlobalModal = ({ open, title, links, counts, onClose, showCount }) => {
  if (!open) return null;

  return (
    <div className="global-modal-overlay">
      <div className="global-modal">
        <div className="d-flex justify-content-between align-items-center modeldesignallfor">
          <h5 className="modal-title">{title}</h5>
          <div className="closebtn" onClick={onClose}>
            <IoClose />
          </div>
        </div>

        <div className="modal-links">
          {links.map((item, index) => (
            <div
              key={index}
              className="d-flex align-items-center justify-content-between linksall_new"
            >
              <div className="d-flex align-items-center gap-2">
                <span className="text-white">{item.icon}</span>
                <Link to={item.route} onClick={onClose}>
                  {item.label}
                </Link>
              </div>

              {showCount && (
                <span className="badge bg-light text-dark">
                  {counts?.[item.key] ?? 0}
                </span>
              )}
            </div>
          ))}
        </div>

        <div className="p-2 d-flex justify-content-end">
          <button className="modal-close-btn" onClick={onClose}>
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

// ✅ Sport Section Component
const SportSection = ({
  sportId,
  sportName,
  games,
  color,
  icon,
  onToggleStatus,
  viewType = "inplay",
}) => {
  const navigate = useNavigate();
  const [oddsDataMap, setOddsDataMap] = useState({});
  const [updating, setUpdating] = useState(null);
  const oddsIntervalRef = useRef(null);
  const isOddsFetchingRef = useRef(false);

  // ✅ Odds fetch with polling (10 seconds)
  useEffect(() => {
    if (games && games.length > 0) {
      fetchOddsData();

      // oddsIntervalRef.current = setInterval(() => {
        fetchOddsData();
      // }, 10000);

      return () => {
        // if (oddsIntervalRef.current) {
        //   clearInterval(oddsIntervalRef.current);
        //   oddsIntervalRef.current = null;
        // }
      };
    }
  }, [games, sportId]);

  const fetchOddsData = async () => {
    if (isOddsFetchingRef.current) {
      console.log("⏳ Odds fetch already in progress, skipping...");
      return;
    }

    try {
      isOddsFetchingRef.current = true;

      let marketIds = [];

      if (viewType === "inplay") {
        marketIds = games
          .filter((game) => game.market_id)
          .map((game) => game.market_id)
          .join(",");
      } else if (viewType === "competition") {
        games.forEach((competition) => {
          competition.events?.forEach((event) => {
            if (event.market_id) {
              marketIds.push(event.market_id);
            }
          });
        });
        marketIds = marketIds.join(",");
      } else if (viewType === "date") {
        games.forEach((dateGroup) => {
          dateGroup.events?.forEach((event) => {
            if (event.market_id) {
              marketIds.push(event.market_id);
            }
          });
        });
        marketIds = marketIds.join(",");
      }

      if (!marketIds) return;

      const oddsUrl = `https://cricketfancylive.shyammatka.co.in/get-match-odds-list?id=${marketIds}&sport_id=${sportId}`;
      console.log("Fetching odds from:", oddsUrl);

      const response = await axios.get(oddsUrl);

      if (response.data && Array.isArray(response.data)) {
        const oddsMap = {};
        response.data.forEach((market) => {
          if (market.marketId && market.runners && market.runners.length > 0) {
            const runners = market.runners;
            const oddsData = [];

            runners.forEach((runner, index) => {
              if (runner.ex) {
                const backPrice =
                  runner.ex.availableToBack &&
                    runner.ex.availableToBack.length > 0
                    ? runner.ex.availableToBack[0].price
                    : null;
                const layPrice =
                  runner.ex.availableToLay &&
                    runner.ex.availableToLay.length > 0
                    ? runner.ex.availableToLay[0].price
                    : null;

                oddsData.push({
                  back: backPrice,
                  lay: layPrice,
                });
              }
            });

            oddsMap[market.marketId] = oddsData;
          }
        });
        setOddsDataMap(oddsMap);
      }
    } catch (error) {
      console.error("Error fetching odds data:", error);
    } finally {
      isOddsFetchingRef.current = false;
    }
  };

  if (!games || games.length === 0) return null;

  const handleMatchClick = (eventId, seriesId, e) => {
    e.preventDefault();
    // /alert(sportId);
    const eventParam = eventId || "null";
    const seriesParam = seriesId || "null";
    localStorage.setItem("event_id", eventId);
    navigate(
      `/viewmatch-fancy/series_idd/${seriesParam}/event_id/${eventParam}/sport_id/${sportId}`,
    );
  };

  const handleToggleStatus = async (eventId, currentStatus, e) => {
    e.stopPropagation();

    const action = currentStatus === 0 ? "lock" : "unlock";
    const confirmMessage =
      currentStatus === 0
        ? "This Event Will Be Locked For Down-Line!"
        : "This Event Will Be Unlocked For Down-Line!";

    const result = await Swal.fire({
      title: "Are you sure?",
      text: confirmMessage,
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#28a745", // ✅ GREEN COLOR
      cancelButtonColor: "#d33",
      confirmButtonText: "Submit",
      cancelButtonText: "Cancel",
    });

    if (!result.isConfirmed) {
      return;
    }

    try {
      setUpdating(eventId);

      const url = `${process.env.REACT_APP_API_URL}/events/${eventId}/toggle-status`;

      const response = await axios.patch(
        url,
        { eventId: eventId },
        {
          headers: { "Content-Type": "application/json" },
          withCredentials: false,
        },
      );

      if (response.data && response.data.success) {
        await Swal.fire({
          icon: "success",
          title: "Success!",
          text: `Event ${action}ed successfully!`,
          timer: 2000,
          showConfirmButton: false,
        });
        // if (onToggleStatus) {
        //   onToggleStatus();
        // }
      } else {
        const errorMsg = response.data?.message || `Failed to ${action} event`;
        await Swal.fire({
          icon: "error",
          title: "Error!",
          text: errorMsg,
        });
      }
    } catch (err) {
      console.error("Error toggling game status:", err);
      const errorMsg =
        err.response?.data?.message || err.message || "Failed to toggle status";
      await Swal.fire({
        icon: "error",
        title: "Error!",
        text: errorMsg,
      });
    } finally {
      setUpdating(null);
    }
  };

  // ✅ Render single event row
  const renderEventRow = (game, index) => {
    const eventOdds = oddsDataMap[game.market_id] || [];
    const oddsDisplay = [];

    if (eventOdds.length > 0 && eventOdds[0].back !== null) {
      oddsDisplay.push(eventOdds[0].back);
    } else {
      oddsDisplay.push(null);
    }

    if (eventOdds.length > 0 && eventOdds[0].lay !== null) {
      oddsDisplay.push(eventOdds[0].lay);
    } else {
      oddsDisplay.push(null);
    }

    oddsDisplay.push(null);
    oddsDisplay.push(null);

    if (eventOdds.length > 1 && eventOdds[1].back !== null) {
      oddsDisplay.push(eventOdds[1].back);
    } else {
      oddsDisplay.push(null);
    }

    if (eventOdds.length > 1 && eventOdds[1].lay !== null) {
      oddsDisplay.push(eventOdds[1].lay);
    } else {
      oddsDisplay.push(null);
    }

    const isLocked = game.status === 0;
    const eventId = game.event_id || game.id;
    // const seriesId = game.series_id || null;
    const seriesId = game.market_id || null;

    return (
      <tr
        key={game._id || index}
        style={{ cursor: "pointer" }}
        onClick={(e) => handleMatchClick(eventId, seriesId, e)}
      >
        <td className="event_id w-100">
          <div className="row">
            <div className="col-md-5">
              <div className="d-flex justify-content-start align-items-center gap-1">
                <div
                  className="ms-1"
                  onClick={(e) =>
                    handleToggleStatus(game._id, game.status || 0, e)
                  }
                  style={{ cursor: "pointer" }}
                  title={isLocked ? "Click to unlock" : "Click to lock"}
                >
                  {updating === game._id ? (
                    <span
                      className="spinner-border spinner-border-sm text-primary"
                      role="status"
                    >
                      <span className="visually-hidden">Loading...</span>
                    </span>
                  ) : isLocked ? (
                    <FaLock
                      className="lockIcon locked"
                      style={{ color: "#ff3b3b" }}
                    />
                  ) : (
                    <FaLockOpen
                      className="lockIcon unlocked"
                      style={{ color: "#6fd96f" }}
                    />
                  )}
                </div>
                <div className="matchName">
                  <div className="event_name">
                    <div className="game_name_main">
                      <FaRegPlayCircle className="play_btn" />
                      {game.name}
                    </div>
                    <span className="d-block time">
                      ({formatMatchDate(game.date_time || "-")})
                    </span>
                  </div>

                  {Number(game.total_exposure) !== 0 && (
                    <span
                      className="d-block time"
                      style={{
                        color:
                          Number(game.total_exposure) > 0 ? "green" : "red",
                        fontWeight: "600",
                      }}
                    >
                      {Number(game.total_exposure) > 0
                        ? `+${game.total_exposure}`
                        : game.total_exposure}
                    </span>
                  )}
                </div>
              </div>
            </div>
            <div className="col-md-2">
              <div className="other_option">
                <span className="my_badge bm_badge">BM</span>
                {sportId === "4" && (
                  <span className="my_badge fancy_badge">FANCY</span>
                )}
                <FaTv className="my_badge tv" />
              </div>
            </div>

            <div className="col-md-5">
              <div className="odds_btns_div">
                <div className="odds_btn">
                  {oddsDisplay.map((value, idx) => (
                    <button
                      key={idx}
                      className={`${idx % 2 === 0 ? "back" : "lay"}`}
                    >
                      {value !== null ? value : "-"}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </td>
        {/* <td className="w-100 py-0 box_padding px-0" style={{ padding: "2px" }}>
         
        </td> */}
      </tr>
    );
  };

  // ✅ Render based on view type
  if (viewType === "inplay") {
    return (
      <div className="sport-section">
        <div className="sport-header">
          <div className="sport sport-icon-wrapper">
            <img className="sportIcon" src={icon} alt={sportName} />
          </div>
          <h3 className="sport-title">{sportName}</h3>
        </div>
        <div className="table-responsive">
          <table className="table table-bordered table-hover mb-0">
            <tbody>
              {games.map((game, index) => renderEventRow(game, index))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }

  if (viewType === "competition") {
    return (
      <div className="sport-section">
        <div className="sport-header">
          <div className="sport sport-icon-wrapper">
            <img className="sportIcon" src={icon} alt={sportName} />
          </div>
          <h3 className="sport-title">{sportName}</h3>
        </div>
        {games.map((competition, compIndex) => (
          <div key={compIndex} className="competition-group">
            <h5 className="competition-title">
              {competition.series_name || "Unknown Competition"}
            </h5>
            <div className="table-responsive">
              <table className="table table-bordered table-hover mb-0">
                <tbody>
                  {competition.events?.map((event, idx) =>
                    renderEventRow(event, idx),
                  )}
                </tbody>
              </table>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (viewType === "date") {
    return (
      <div className="sport-section">
        <div className="sport-header">
          <div className="sport sport-icon-wrapper">
            <img className="sportIcon" src={icon} alt={sportName} />
          </div>
          <h3 className="sport-title">{sportName}</h3>
        </div>
        {games.map((dateGroup, dateIndex) => (
          <div key={dateIndex} className="date-group">
            {/* <h5>📅 {dateGroup.date || "Unknown Date"}</h5> */}
            <div className="table-responsive">
              <table className="table table-bordered table-hover mb-0">
                <tbody>
                  {dateGroup.events?.map((event, idx) =>
                    renderEventRow(event, idx),
                  )}
                </tbody>
              </table>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return null;
};

export default function Dashboard() {
  // ✅ ALL HOOKS AT TOP LEVEL
  const [dashboardData, setDashboardData] = useState({});
  const [adminProfile, setAdminProfile] = useState(null);
  const [role2Count, setRole2Count] = useState(0);
  const [loading, setLoading] = useState(true);
  const [openModal, setOpenModal] = useState(false);
  const [modalLinks, setModalLinks] = useState([]);
  const [selectedGame, setSelectedGame] = useState(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [gamesLoading, setGamesLoading] = useState(false);
  const [counts, setCounts] = useState({});
  const [showModalCount, setShowModalCount] = useState(true);
  const [modalTitle, setModalTitle] = useState("");
  const [games, setGames] = useState([]);
  const [error, setError] = useState("");

  const [plData, setPlData] = useState({
    running_pl: 0,
    lifetime_pl: 0,
    upline_pl: 0,
  });

  const [pagination, setPagination] = useState({
    currentPage: 1,
    itemsPerPage: 100,
    totalItems: 0,
    totalPages: 1,
  });
  const [pullLoading, setPullLoading] = useState(false);
  const [filters, setFilters] = useState({
    search: "",
    is_completed: "",
    is_inplay: "",
  });
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const sportId = searchParams.get("sportId");
  const seriesId = searchParams.get("seriesId");
  const navigate = useNavigate();

  // ✅ Refs for preventing duplicate calls
  const isFetchingRef = useRef(false);
  const isMountedRef = useRef(true);
  const pollingIntervalRef = useRef(null);
  const isInitialLoadDone = useRef(false);
  const [open, setOpen] = useState(true);

  // ✅ Main tabs state - only 3 tabs
  const [activeTab, setActiveTab] = useState("inplay");

  // ✅ State for API data
  const [apiData, setApiData] = useState({
    inplay: [],
    competition_wise: [],
    date_wise: [],
  });

  const [, setCardValues] = useState({
    balance: 0,
    running_pl: 0,
    upline_pl: 0,
    lifetime_pl: 0,
  });

  // ✅ Function to update card values
  const updateCardValues = () => {
    const coins = getSafeValue("coins", 0);
    const runningPl = getSafeValue("running_pl", 0);
    const uplinePl = getSafeValue("upline_pl", 0);
    const lifetimePl = getSafeValue("lifetime_pl", 0);

    setCardValues({
      balance: coins,
      running_pl: runningPl,
      upline_pl: uplinePl,
      lifetime_pl: lifetimePl,
    });
  };

  // ✅ 1. Storage change listener
  useEffect(() => {
    updateCardValues();
    const handleStorageChange = () => updateCardValues();
    window.addEventListener("storage", handleStorageChange);
    return () => window.removeEventListener("storage", handleStorageChange);
  }, []);

  // ✅ 2. Initial load + Polling (combined)
  useEffect(() => {
    isMountedRef.current = true;

    // ✅ Function to load data (with duplicate prevention)
    const loadAllData = async () => {
      if (isFetchingRef.current) {
        console.log("⏳ Load already in progress, skipping...");
        return;
      }

      try {
        isFetchingRef.current = true;

        console.log("📡 Loading data...", {
          sportId,
          seriesId,
          activeTab,
          isInitial: !isInitialLoadDone.current,
          timestamp: new Date().toISOString(),
        });

        const [dashboardRes, eventsRes] = await Promise.all([
          getDashboardClientList(admin_id),

          getAllEvents(sportId, seriesId, {
            page: pagination.currentPage,
            limit: pagination.itemsPerPage,
            search: filters.search,
            status: 1,
            is_completed: filters.is_completed,
            is_inplay: filters.is_inplay,
          }),
        ]);

        if (!isMountedRef.current) return;

        // ✅ Process dashboard data
        if (dashboardRes?.data?.success) {
          const adminDetails = dashboardRes.data.data.admin_details || {};
          const plData = dashboardRes.data.data.pl_data || {};

          const coins = adminDetails.coins || 0;
          const runningPl = adminDetails.running_pl || 0;
          const uplinePl = adminDetails.upline_pl || 0;
          const lifetimePl = adminDetails.lifetime_pl || 0;

          localStorage.setItem("coins", coins.toString());
          localStorage.setItem("running_pl", runningPl.toString());
          localStorage.setItem("upline_pl", uplinePl.toString());
          localStorage.setItem("lifetime_pl", lifetimePl.toString());

          setAdminProfile(adminDetails);
          setPlData(plData);
          setRole2Count(dashboardRes.data.data.role_2_count || 0);
          setCounts(dashboardRes.data.data.counts || {});
          updateCardValues();

          console.log("✅ Dashboard Data Loaded:", {
            coins,
            runningPl,
            uplinePl,
            lifetimePl,
            admin_id: adminDetails.admin_id,
          });
        }

        if (eventsRes?.data?.success) {
          const data = eventsRes.data.data;

          setApiData({
            inplay: data.inplay || [],
            competition_wise: data.competition_wise || [],
            date_wise: data.date_wise || [],
          });

          if (eventsRes.data.pagination) {
            setPagination((prev) => ({
              ...prev,
              currentPage: eventsRes.data.pagination.page || 1,
              itemsPerPage: eventsRes.data.pagination.limit || 10,
              totalItems: eventsRes.data.pagination.total || 0,
              totalPages: eventsRes.data.pagination.totalPages || 1,
            }));
          }

          setError("");
        }

        isInitialLoadDone.current = true;
        console.log("✅ Data loaded successfully", {
          timestamp: new Date().toISOString(),
        });
      } catch (err) {
        console.error("Error loading data:", err);
        setError(err.message || "Failed to load data");
      } finally {
        if (isMountedRef.current) {
          isFetchingRef.current = false;
          setLoading(false);
          setGamesLoading(false);
        }
      }
    };

    if (!isInitialLoadDone.current) {
      loadAllData();
    }

    // pollingIntervalRef.current = setInterval(() => {
      if (!isFetchingRef.current && isInitialLoadDone.current) {
        console.log("🔄 Polling API every 10 seconds...");
        loadAllData();
      } else if (isFetchingRef.current) {
        console.log("⏳ Skipping poll - API call already in progress");
      }
    // }, 10000);

    return () => {
      isMountedRef.current = false;
      // if (pollingIntervalRef.current) {
      //   clearInterval(pollingIntervalRef.current);
      //   pollingIntervalRef.current = null;
      // }
    };
  }, [sportId, seriesId, activeTab]);

  // ✅ 3. Pull to refresh
  useEffect(() => {
    let startY = 0;

    const handleTouchStart = (e) => {
      if (window.scrollY === 0) {
        startY = e.touches[0].clientY;
      }
    };

    const handleTouchMove = (e) => {
      const currentY = e.touches[0].clientY;
      if (window.scrollY === 0 && currentY - startY > 80) {
        triggerPullRefresh();
      }
    };

    window.addEventListener("touchstart", handleTouchStart);
    window.addEventListener("touchmove", handleTouchMove);

    return () => {
      window.removeEventListener("touchstart", handleTouchStart);
      window.removeEventListener("touchmove", handleTouchMove);
    };
  }, []);

  // ✅ Function to manually refresh data
  const refreshData = async () => {
    if (isFetchingRef.current) return;

    isInitialLoadDone.current = false;
    setLoading(true);

    const loadAllData = async () => {
      try {
        isFetchingRef.current = true;

        const [dashboardRes, eventsRes] = await Promise.all([
          getDashboardClientList(admin_id),
          getAllEvents(sportId, seriesId, {
            page: pagination.currentPage,
            limit: pagination.itemsPerPage,
            search: filters.search,
            status: 1,
            is_completed: filters.is_completed,
            is_inplay: filters.is_inplay,
          }),
        ]);

        if (!isMountedRef.current) return;

        if (dashboardRes?.data?.success) {
          const adminDetails = dashboardRes.data.data.admin_details || {};

          const coins = adminDetails.coins || 0;
          const runningPl = adminDetails.running_pl || 0;
          const uplinePl = adminDetails.upline_pl || 0;
          const lifetimePl = adminDetails.lifetime_pl || 0;

          localStorage.setItem("coins", coins.toString());
          localStorage.setItem("running_pl", runningPl.toString());
          localStorage.setItem("upline_pl", uplinePl.toString());
          localStorage.setItem("lifetime_pl", lifetimePl.toString());

          setAdminProfile(adminDetails);
          setRole2Count(dashboardRes.data.data.role_2_count || 0);
          setCounts(dashboardRes.data.data.counts || {});
          updateCardValues();
        }

        if (eventsRes?.data?.success) {
          const data = eventsRes.data.data;
          setApiData({
            inplay: data.inplay || [],
            competition_wise: data.competition_wise || [],
            date_wise: data.date_wise || [],
          });
        }

        isInitialLoadDone.current = true;
      } catch (err) {
        console.error("Error refreshing data:", err);
      } finally {
        if (isMountedRef.current) {
          isFetchingRef.current = false;
          setLoading(false);
          setGamesLoading(false);
        }
      }
    };

    await loadAllData();
  };

  // ✅ Modified fetchEvents
  const fetchEvents = async (page = 1, limit = pagination.itemsPerPage) => {
    setPagination((prev) => ({ ...prev, currentPage: page }));
    await refreshData();
  };

  // ✅ Modified triggerPullRefresh
  const triggerPullRefresh = async () => {
    if (pullLoading || isFetchingRef.current) return;
    setPullLoading(true);
    try {
      await refreshData();
    } finally {
      setTimeout(() => {
        setPullLoading(false);
      }, 800);
    }
  };

  // ✅ Admin Cards Config
  const adminCards = [
    {
      label: "Admin",
      key: "superMaster",
      showModalCount: true,
      icon: <FaUserCircle size={36} />,
      modalLinks: [
        {
          label: "Master",
          key: "total_master",
          route: "/masters_list",
          icon: <FaUserTie size={16} />,
        },
        {
          label: "Super Agent",
          key: "total_super_agent",
          route: "/agent_lists",
          icon: <FaUserTie size={16} />,
        },
        {
          label: "Agent User",
          key: "total_agent",
          route: "/AgentMasternew",
          icon: <FaUsers size={16} />,
        },
        {
          label: "User",
          key: "total_user",
          route: "/Mastermyuser",
          icon: <FaUsers size={16} />,
        },
      ],
    },
    {
      label: "Sport's Details",
      key: "sportsDetails",
      showCount: false,
      icon: <FaGamepad size={36} />,
      modalLinks: [
        {
          label: "Active Games",
          route: "/inplay_game",
          icon: <FaGamepad size={16} />,
        },
        {
          label: "Complete Games",
          route: "/completed_game",
          icon: <FaCheckCircle size={16} />,
        },
      ],
    },
    {
      label: "Ledger",
      key: "ledger",
      showCount: false,
      icon: <FaBook size={36} />,
      modalLinks: [
        {
          label: "Profit / Loss",
          route: "/profitloss",
          icon: <FaChartLine size={16} />,
        },
        { label: "My Ledger", route: "/my-ledger", icon: <FaBook size={16} /> },
        {
          label: "Master",
          route: "/Master-ledger",
          icon: <FaUserTie size={16} />,
        },
        {
          label: "Super Agent",
          route: "/settlement",
          icon: <FaUsers size={16} />,
        },
        {
          label: "Agent",
          route: "/settlement/agent-ledger",
          icon: <FaUserTie size={16} />,
        },
        { label: "User", route: "/settlement/agent-ledger", icon: <FaUsers size={16} /> },
      ],
    },
    {
      label: "Cash Transaction",
      key: "cashTransaction",
      showCount: false,
      icon: <FaMoneyBillWave size={36} />,
      modalLinks: [
        {
          label: "Master",
          route: "/agent_master-transaction",
          icon: <FaUserTie size={16} />,
        },
        {
          label: "Super Agent ",
          route: "/Superagenttransaction",
          icon: <FaUsers size={16} />,
        },
        {
          label: "Agent ",
          route: "/Agenttransaction",
          icon: <FaUserTie size={16} />,
        },
      ],
    },
  ];

  const infoCards = adminProfile
    ? [
      {
        title: adminProfile.admin_id || "Admin",
        subtitle: `You are ${adminProfile.user_type || "Admin"}`,
        icon: <FaUser />,
      },
      {
        title: adminProfile.coins || 0,
        subtitle: "Coins",
        icon: <FaTrophy />,
      },
      {
        title: role2Count || 0,
        subtitle: "Members",
        icon: <FaUsers />,
      },
      {
        title: `${adminProfile.match_share || 0}%`,
        subtitle: "My Share",
        icon: <FaChartBar />,
      },
      {
        title: `${adminProfile.company_share || 0}%`,
        subtitle: "Company Share",
        icon: <FaChartBar />,
      },
      {
        title: `${adminProfile.match_comm || 0}%`,
        subtitle: "Match Commission",
      },
      {
        title: `${adminProfile.session_comm || 0}%`,
        subtitle: "Session Commission",
      },
      {
        title: "Rules",
        subtitle: "Rules",
        icon: <FaInfoCircle />,
        route: "/app/rules",
        isLink: true,
      },
    ]
    : [];

  const formatDate = (date) => {
    if (!date) return "-";
    return new Date(date).toLocaleString("en-IN", {
      dateStyle: "medium",
      timeStyle: "short",
    });
  };

  const handleNextPage = () => {
    if (pagination.currentPage < pagination.totalPages) {
      const nextPage = pagination.currentPage + 1;
      fetchEvents(nextPage, pagination.itemsPerPage);
    }
  };

  const handlePrevPage = () => {
    if (pagination.currentPage > 1) {
      const prevPage = pagination.currentPage - 1;
      fetchEvents(prevPage, pagination.itemsPerPage);
    }
  };

  const handlePageClick = (page) => {
    if (page >= 1 && page <= pagination.totalPages) {
      fetchEvents(page, pagination.itemsPerPage);
    }
  };

  const getPageNumbers = () => {
    const pageNumbers = [];
    const maxVisiblePages = 2;
    if (pagination.totalPages <= maxVisiblePages) {
      for (let i = 1; i <= pagination.totalPages; i++) {
        pageNumbers.push(i);
      }
    } else {
      let start = Math.max(
        1,
        pagination.currentPage - Math.floor(maxVisiblePages / 2),
      );
      let end = Math.min(pagination.totalPages, start + maxVisiblePages - 1);

      if (end - start + 1 < maxVisiblePages) {
        start = Math.max(1, end - maxVisiblePages + 1);
      }

      for (let i = start; i <= end; i++) {
        pageNumbers.push(i);
      }
    }
    return pageNumbers;
  };

  const getStatus = (game) => {
    const now = new Date();
    const openDateObj = new Date(game.openDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    if (game.status === 0) return "INACTIVE";
    if (game.is_inplay === 1) return "INPLAY";

    const gameDate = new Date(game.openDate);
    gameDate.setHours(0, 0, 0, 0);
    if (gameDate.getTime() === today.getTime()) {
      return "INPLAY";
    }

    if (now < openDateObj) return "UPCOMING";
    if (now >= openDateObj) return "INPLAY";

    return "UPCOMING";
  };

  const GameDetailsModal = ({ game, onClose }) => {
    if (!game) return null;

    return (
      <div className="global-modal-overlay">
        <div className="global-modal">
          <div className="d-flex justify-content-between align-items-center modeldesignallfor">
            <h5 className="modal-title">{game.name}</h5>
            <div className="closebtn" onClick={onClose}>
              <IoClose />
            </div>
          </div>
          <div className="modal-links">
            <p>
              <b>Competition:</b> {game.series_name}
            </p>
            <p>
              <b>Open Date:</b> {formatDate(game.openDate)}
            </p>
            <p>
              <b>Status:</b> {getStatus(game)}
            </p>
          </div>

          <div className="p-2 d-flex justify-content-end">
            <button className="modal-close-btn" onClick={onClose}>
              Close{" "}
            </button>
          </div>
        </div>
      </div>
    );
  };

  const cardConfig = getCardConfig(plData);

  const getCurrentViewData = () => {
    if (activeTab === "inplay") {
      return {
        type: "inplay",
        data: apiData.inplay || [],
      };
    } else if (activeTab === "competition") {
      return {
        type: "competition",
        data: apiData.competition_wise || [],
      };
    } else if (activeTab === "date") {
      return {
        type: "date",
        data: apiData.date_wise || [],
      };
    }
    return { type: "inplay", data: [] };
  };

  const currentView = getCurrentViewData();

  // ✅ Group data by sport for current view
  const getGroupedDataForView = () => {
    const data = currentView.data;
    const type = currentView.type;

    if (type === "inplay") {
      const grouped = {};
      data.forEach((event) => {
        const sportId = event.sport_id?.toString() || "unknown";
        if (!grouped[sportId]) grouped[sportId] = [];
        grouped[sportId].push(event);
      });
      return grouped;
    } else if (type === "competition") {
      const grouped = {};
      data.forEach((sport) => {
        const sportId = sport.sport_id?.toString() || "unknown";
        if (!grouped[sportId]) grouped[sportId] = [];
        sport.competitions?.forEach((comp) => {
          grouped[sportId].push({
            ...comp,
            sport_id: sportId,
            sport_name: sport.sport_name,
          });
        });
      });
      return grouped;
    } else if (type === "date") {
      const grouped = {};
      data.forEach((sport) => {
        const sportId = sport.sport_id?.toString() || "unknown";
        if (!grouped[sportId]) grouped[sportId] = [];
        sport.dates?.forEach((dateGroup) => {
          grouped[sportId].push({
            ...dateGroup,
            sport_id: sportId,
            sport_name: sport.sport_name,
          });
        });
      });
      return grouped;
    }
    return {};
  };

  const groupedData = getGroupedDataForView();

  const allSportIds = Object.keys(groupedData).filter(
    (id) => groupedData[id] && groupedData[id].length > 0,
  );

  const sortedSportIds = SPORT_ORDER.filter((id) => allSportIds.includes(id));

  // ✅ If loading, show loader
  // if (loading) {
  //   return (
  //     <div className="text-center mt-5">
  //       <h5>Loading dashboard data...</h5>
  //       <Loader />
  //     </div>
  //   );
  // }

  return (
    <>
      {pullLoading && (
        <div className="pull-loader">
          <span className="spinner"></span>
          <small>Refreshing...</small>
        </div>
      )}

      <button onClick={() => setOpen(!open)} className="btn btn_collpse w-100">
        {open ? <FaArrowDown /> : <FaArrowUp />}
      </button>

      <div className={`content  ${open ? "open" : ""}`}>
        <div className="row g-2 mt-0">
          {cardConfig.map((item, index) => (
            <div key={index} className="col-6 col-sm-6 col-md-4">
              <div
                className="card_dashboard shadow-sm"
                style={{
                  background: item.bg,
                }}
                onClick={() => {
                  if (item.route) {
                    navigate(item.route);
                  }
                }}
              >
                <div className="card-body d-flex justify-content-between">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <div className="d-flex align-items-center gap-3 mb-2">
                        <h5>{item.value}</h5>
                        <h6>
                          {item.valueIcon && (
                            <span className="d-flex">{item.valueIcon}</span>
                          )}
                        </h6>
                      </div>
                      <h6>{item.label}</h6>
                    </div>
                  </div>
                  <div className="card-icon">
                    <span>{item.icon}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* ✅ Admin Cards Row */}
      {/* <div className="row g-3 mb-3">
        {adminCards.map((item, index) => (
          <div key={index} className="col-md-3 col-6">
            <div
              className="card_dashboard shadow-sm"
              style={{ cursor: "pointer" }}
              onClick={() => {
                if (item.modalLinks) {
                  setModalLinks(item.modalLinks);
                  setShowModalCount(item.showCount !== false);
                  setModalTitle(item.label);
                  setOpenModal(true);
                }
              }}
            >
              <div className="card-body d-flex align-items-center justify-content-between">
                <div>
                  <h6 className="mb-1">{item.label}</h6>
                </div>
                <div className="card-icon">{item.icon}</div>
              </div>
            </div>
          </div>
        ))}
      </div> */}

      {/* ✅ Info Cards */}
      <div className="row g-3 mt-3">
        {infoCards.map((item, index) => {
          const CardWrapper = item.isLink ? Link : "div";
          return (
            <></>
            // <div key={index} className="col-12 col-lg-3">
            //   <CardWrapper
            //     to={item.route}
            //     className="text-decoration-none card shadow-sm primarycolor"
            //   >
            //     <div className="card-body d-flex align-items-center justify-content-between">
            //       <div>
            //         <h6 className="mb-1">
            //           {item.subtitle && <small>{item.subtitle}</small>}
            //         </h6>
            //         <h4>{item.title}</h4>
            //       </div>
            //       {item.icon && <div className="card-icon">{item.icon}</div>}
            //     </div>
            //   </CardWrapper>
            // </div>
          );
        })}
      </div>

      <GlobalModal
        open={openModal}
        showCount={showModalCount}
        title={modalTitle}
        links={modalLinks}
        counts={counts}
        onClose={() => setOpenModal(false)}
      />

      <div className="card mb-2">
        <div className="card-body p-2">
          <div className="sports-tabs">
            <ul className="nav nav-tabs">
              {TABS.map((tab) => (
                <li className="nav-item" key={tab.id}>
                  <button
                    className={`nav-link ${activeTab === tab.id ? "active" : ""}`}
                    onClick={() => setActiveTab(tab.id)}
                  >
                    <img
                      src={tab.icon}
                      alt={tab.label}
                      width={18}
                      height={18}
                      className="me-1"
                    />
                    {tab.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>
          <div className="all_matches">
            {loading ? (
              <div className="table_loader text-center py-5">
                <Loader />
              </div>
            ) : gamesLoading ? (
              <div className="text-center table_loader p-4">
                <Loader />
                <p className="mt-2">Loading matches...</p>
              </div>
            ) : sortedSportIds.length === 0 ? (
              <div className="text-center p-4">
                <p>No matches found</p>
              </div>
            ) : (
              sortedSportIds.map((sportId) => {
                const sportName = SPORT_NAMES[sportId];
                const color = SPORT_COLORS[sportId] || "#6c757d";
                const sportGames = groupedData[sportId] || [];

                return (
                  <SportSection
                    key={sportId}
                    sportId={sportId}
                    sportName={sportName}
                    games={sportGames}
                    color={color}
                    icon={SPORT_ICONS[sportId]}
                    viewType={currentView.type}
                    // onToggleStatus={() =>
                    //   fetchEvents(
                    //     pagination.currentPage,
                    //     pagination.itemsPerPage,
                    //   )
                    // }
                    onToggleStatus={() => { }}
                  />
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Pagination */}
      {pagination.totalPages > 1 && (
        <div className="d-flex justify-content-center align-items-center mt-4">
          {/* <div className="sohwingallentries">
            Showing {(pagination.currentPage - 1) * pagination.itemsPerPage + 1}{" "}
            to{" "}
            {Math.min(
              pagination.currentPage * pagination.itemsPerPage,
              pagination.totalItems,
            )}
          </div> */}

          <div className="paginationall d-flex align-items-center gap-1">
            <button
              disabled={pagination.currentPage === 1}
              onClick={handlePrevPage}
              className=""
              title="Previous Page"
            >
              <MdKeyboardDoubleArrowLeft /> Previous
            </button>

            <div className="d-flex gap-1">
              {getPageNumbers().map((page) => (
                <div
                  key={page}
                  className={`paginationnumber ${pagination.currentPage === page ? "active" : ""}`}
                  onClick={() => handlePageClick(page)}
                >
                  {page}
                </div>
              ))}
            </div>

            <button
              disabled={pagination.currentPage === pagination.totalPages}
              onClick={handleNextPage}
              className=""
              title="Next Page"
            >
              Next <MdKeyboardDoubleArrowRight />
            </button>
          </div>
        </div>
      )}

      <GameDetailsModal
        game={detailsOpen ? selectedGame : null}
        onClose={() => setDetailsOpen(false)}
      />
    </>
  );
}
