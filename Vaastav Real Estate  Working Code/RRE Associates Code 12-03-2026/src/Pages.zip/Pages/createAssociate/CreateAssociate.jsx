import React, { useState, useEffect } from "react";
import { Form, Button, Container, Row, Col, Card } from "react-bootstrap";
import Swal from "sweetalert2";

const API_URL = process.env.REACT_APP_API_URL;

function CreateAssociate() {
  
  const [formData, setFormData] = useState({
    status: "active",
    username: "",
    mobile: "",
    password: "",
    address: "",
    state: "", 
    city: "", 
    area: "",
    pincode: "",
    whatsapp_number: "",
    email: "",
    dob: "",
    marriage_anniversary_date: "", 
    pan_number: "", 
    rera_number: "", 
    parent_id: "",
  });

  
  const [errors, setErrors] = useState({});
 
  const [loading, setLoading] = useState(false);
 
  const [states, setStates] = useState([]);
 
  const [cities, setCities] = useState([]);

  
  const [showMessageModal, setShowMessageModal] = useState(false);
  const [messageModalContent, setMessageModalContent] = useState({
    title: "",
    text: "",
    type: "",
    confirmAction: null,
  });

  
  const showCustomMessageModal = (title, text, type, confirmAction = null) => {
    setMessageModalContent({ title, text, type, confirmAction });
    setShowMessageModal(true);
  };

  const closeCustomMessageModal = () => {
    setShowMessageModal(false);
    setMessageModalContent({ title: "", text: "", type: "", confirmAction: null });
  };

  
  const getAuthToken = () => {
    return localStorage.getItem("token"); 
  };

  
  useEffect(() => {
    const fetchStates = async () => {
      try {
        const token = getAuthToken();
        if (!token) {
          showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
          return;
        }

        const response = await fetch(`${API_URL}/state-list`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        });

        if (!response.ok) {
          const errorData = await response.json();
          showCustomMessageModal("Error", errorData.message || "Failed to fetch states.", "error");
          return;
        }

        const data = await response.json();
        setStates(data.data || []); 
      } catch (err) {
        console.error("Fetch states error:", err);
        showCustomMessageModal("Error", err.message || "An unexpected error occurred while fetching states.", "error");
      }
    };

    fetchStates();
  }, []); 


  useEffect(() => {
    const fetchCities = async () => {
      if (formData.state) { 
        try {
          const token = getAuthToken();
          if (!token) {
            showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
            return;
          }

          const response = await fetch(`${API_URL}/city-list`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({ state_id: formData.state }),
          });

          if (!response.ok) {
            const errorData = await response.json();
            showCustomMessageModal("Error", errorData.message || "Failed to fetch cities.", "error");
            setCities([]); 
            return;
          }

          const data = await response.json();

          setCities(data.data || []);
        } catch (err) {
          console.error("Fetch cities error:", err);
          showCustomMessageModal("Error", err.message || "An unexpected error occurred while fetching cities.", "error");
          setCities([]); 
        }
      } else {
        setCities([]); 
        setFormData(prev => ({ ...prev, city: "" }));
      }
    };

    fetchCities();
  }, [formData.state]); 

  
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  
    if (errors[name]) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        [name]: null,
      }));
    }
  };


  const validateForm = () => {
    let newErrors = {};
    let isValid = true;


    const requiredFields = [
      "username", "mobile", "password", "address", "state", "city",
      "area", "pincode", "whatsapp_number", "email", "dob", "status"
    ];
    requiredFields.forEach(field => {
      if (!formData[field].trim()) {
        newErrors[field] = `${field.replace(/_/g, ' ').replace(/\b\w/g, char => char.toUpperCase())} is required.`;
        isValid = false;
      }
    });

   
    if (formData.email && !/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Email address is invalid.";
      isValid = false;
    }

   
    if (formData.mobile && !/^\d{10}$/.test(formData.mobile)) {
      newErrors.mobile = "Mobile number must be 10 digits.";
      isValid = false;
    }

   
    if (formData.whatsapp_number && !/^\d{10}$/.test(formData.whatsapp_number)) {
      newErrors.whatsapp_number = "WhatsApp number must be 10 digits.";
      isValid = false;
    }

  
    if (formData.password && formData.password.length < 6) {
      newErrors.password = "Password must be at least 6 characters long.";
      isValid = false;
    }

  
    if (formData.pincode && !/^\d{6}$/.test(formData.pincode)) {
      newErrors.pincode = "Pincode must be 6 digits.";
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

 
  const handleSubmit = async (e) => {
    e.preventDefault(); 

    
    if (!validateForm()) {
      showCustomMessageModal("Validation Error", "Please correct the errors in the form.", "error");
      return; 
    }

    setLoading(true); 

    try {
      const token = getAuthToken();
      if (!token) {
        showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
        return;
      }

      const payload = {
        status: formData.status,
        username: formData.username,
        mobile: formData.mobile,
        password: formData.password,
        address: formData.address,
        state: formData.state,
        city: formData.city,
        area: formData.area,
        pincode: formData.pincode,
        whatsapp_number: formData.whatsapp_number,
        email: formData.email,
        dob: formData.dob,
        parent_id:formData.parent_id,
        pan_number:formData.pan_number,
        rera_number:formData.rera_number,
      };

      
      if (formData.marriage_anniversary_date) {
        payload.marriage_anniversary_date = formData.marriage_anniversary_date;
      }
      if (formData.pan_number) {
        payload.pan_number = formData.pan_number;
      }
      if (formData.rera_number) {
        payload.rera_number = formData.rera_number;
      }
      if (formData.parent_id) {
        payload.parent_id = formData.parent_id;
      }

      const response = await fetch(`${API_URL}/Associate-create`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`, 
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
       
        const errorData = await response.json();
        showCustomMessageModal("Error", errorData.message || "Failed to create associate.", "error");
        return;
      }

      
      const result = await response.json();
      showCustomMessageModal("Success", result.message || "Associate created successfully!", "success");

      
      setFormData({
        status: "active",
        username: "",
        mobile: "",
        password: "",
        address: "",
        state: "",
        city: "",
        area: "",
        pincode: "",
        whatsapp_number: "",
        email: "",
        dob: "",
        marriage_anniversary_date: "",
        pan_number: "",
        rera_number: "",
        parent_id: "",
      });
      setErrors({}); 

    } catch (err) {
      console.error("Error creating associate:", err);
      showCustomMessageModal("Error", err.message || "An unexpected error occurred.", "error");
    } finally {
      setLoading(false); 
    }
  };

  return (
    <Container className="mt-5">
      <Row className="justify-content-center">
        <Col md={10} lg={8}>
          <Card className="shadow-lg rounded-3">
            <Card.Header className="bg-primary text-white text-center py-3 rounded-top-3">
              <h2 className="mb-0">Create New Associate</h2>
            </Card.Header>
            <Card.Body className="p-4">
              <Form onSubmit={handleSubmit}>
                <Row>
                 
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formStatus">
                      <Form.Label>Status <span className="text-danger">*</span></Form.Label>
                      <Form.Select
                        name="status"
                        value={formData.status}
                        onChange={handleChange}
                        isInvalid={!!errors.status}
                      >
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.status}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>

                  
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formUsername">
                      <Form.Label>Username <span className="text-danger">*</span></Form.Label>
                      <Form.Control
                        type="text"
                        name="username"
                        placeholder="Enter username"
                        value={formData.username}
                        onChange={handleChange}
                        isInvalid={!!errors.username}
                      />
                      <Form.Control.Feedback type="invalid">
                        {errors.username}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>

                <Row>
                  
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formMobile">
                      <Form.Label>Mobile Number <span className="text-danger">*</span></Form.Label>
                      <Form.Control
                        type="tel"
                        name="mobile"
                        placeholder="Enter mobile number (10 digits)"
                        value={formData.mobile}
                        onChange={handleChange}
                        isInvalid={!!errors.mobile}
                        maxLength="10"
                      />
                      <Form.Control.Feedback type="invalid">
                        {errors.mobile}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>

                  
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formPassword">
                      <Form.Label>Password <span className="text-danger">*</span></Form.Label>
                      <Form.Control
                        type="password"
                        name="password"
                        placeholder="Enter password (min 6 characters)"
                        value={formData.password}
                        onChange={handleChange}
                        isInvalid={!!errors.password}
                      />
                      <Form.Control.Feedback type="invalid">
                        {errors.password}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>

                <Row>
                  
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formEmail">
                      <Form.Label>Email <span className="text-danger">*</span></Form.Label>
                      <Form.Control
                        type="email"
                        name="email"
                        placeholder="Enter email"
                        value={formData.email}
                        onChange={handleChange}
                        isInvalid={!!errors.email}
                      />
                      <Form.Control.Feedback type="invalid">
                        {errors.email}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>

                  
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formWhatsappNumber">
                      <Form.Label>WhatsApp Number <span className="text-danger">*</span></Form.Label>
                      <Form.Control
                        type="tel"
                        name="whatsapp_number"
                        placeholder="Enter WhatsApp number (10 digits)"
                        value={formData.whatsapp_number}
                        onChange={handleChange}
                        isInvalid={!!errors.whatsapp_number}
                        maxLength="10"
                      />
                      <Form.Control.Feedback type="invalid">
                        {errors.whatsapp_number}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>

                <Row>
                 
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formDob">
                      <Form.Label>Date of Birth <span className="text-danger">*</span></Form.Label>
                      <Form.Control
                        type="date"
                        name="dob"
                        value={formData.dob}
                        onChange={handleChange}
                        isInvalid={!!errors.dob}
                      />
                      <Form.Control.Feedback type="invalid">
                        {errors.dob}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>

                 
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formMarriageAnniversaryDate">
                      <Form.Label>Marriage Anniversary Date (Optional)</Form.Label>
                      <Form.Control
                        type="date"
                        name="marriage_anniversary_date"
                        value={formData.marriage_anniversary_date}
                        onChange={handleChange}
                      />
                    </Form.Group>
                  </Col>
                </Row>

                <Row>
                  
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formState">
                      <Form.Label>State <span className="text-danger">*</span></Form.Label>
                      <Form.Select
                        name="state"
                        value={formData.state}
                        onChange={handleChange}
                        isInvalid={!!errors.state}
                      >
                        <option value="">Select State</option>
                        {states.map((state) => (
                          <option key={state.id} value={state.id}>
                            {state.name}
                          </option>
                        ))}
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.state}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>

                  
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formCity">
                      <Form.Label>City <span className="text-danger">*</span></Form.Label>
                      <Form.Select
                        name="city"
                        value={formData.city}
                        onChange={handleChange}
                        isInvalid={!!errors.city}
                        disabled={!formData.state || cities.length === 0} 
                      >
                        <option value="">Select City</option>
                        {cities.map((city) => (
                          <option key={city.id} value={city.id}>
                            {city.name}
                          </option>
                        ))}
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.city}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>

                <Row>
                  
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formArea">
                      <Form.Label>Area <span className="text-danger">*</span></Form.Label>
                      <Form.Control
                        type="text"
                        name="area"
                        placeholder="Enter area"
                        value={formData.area}
                        onChange={handleChange}
                        isInvalid={!!errors.area}
                      />
                      <Form.Control.Feedback type="invalid">
                        {errors.area}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>

                 
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formPincode">
                      <Form.Label>Pincode <span className="text-danger">*</span></Form.Label>
                      <Form.Control
                        type="text"
                        name="pincode"
                        placeholder="Enter pincode (6 digits)"
                        value={formData.pincode}
                        onChange={handleChange}
                        isInvalid={!!errors.pincode}
                        maxLength="6"
                      />
                      <Form.Control.Feedback type="invalid">
                        {errors.pincode}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>

                
                <Form.Group className="mb-3" controlId="formAddress">
                  <Form.Label>Address <span className="text-danger">*</span></Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={3}
                    name="address"
                    placeholder="Enter full address"
                    value={formData.address}
                    onChange={handleChange}
                    isInvalid={!!errors.address}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.address}
                  </Form.Control.Feedback>
                </Form.Group>

                <Row>
                  
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formPanNumber">
                      <Form.Label>PAN Number (Optional)</Form.Label>
                      <Form.Control
                        type="text"
                        name="pan_number"
                        placeholder="Enter PAN number"
                        value={formData.pan_number}
                        onChange={handleChange}
                      />
                    </Form.Group>
                  </Col>

                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formReraNumber">
                      <Form.Label>RERA Number (Optional)</Form.Label>
                      <Form.Control
                        type="text"
                        name="rera_number"
                        placeholder="Enter RERA number"
                        value={formData.rera_number}
                        onChange={handleChange}
                      />
                    </Form.Group>
                  </Col>
                </Row>

                <Form.Group className="mb-4" controlId="formParentId">
                  <Form.Label>Parent ID (Optional)</Form.Label>
                  <Form.Control
                    type="text"
                    name="parent_id"
                    placeholder="Enter parent ID"
                    value={formData.parent_id}
                    onChange={handleChange}
                  />
                </Form.Group>

                
                <Button
                  variant="primary"
                  type="submit"
                  className="w-100 py-2"
                  disabled={loading} 
                >
                  {loading ? "Creating..." : "Create Associate"}
                </Button>
              </Form>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      
      {showMessageModal && (
        <div className="modal d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className={`modal-content border-top border-4 ${messageModalContent.type === 'success' ? 'border-success' : messageModalContent.type === 'error' ? 'border-danger' : 'border-warning'}`}>
              <div className="modal-header d-flex justify-content-between align-items-center">
                <h5 className={`modal-title ${messageModalContent.type === 'success' ? 'text-success' : messageModalContent.type === 'error' ? 'text-danger' : 'text-warning'}`}>
                  {messageModalContent.title}
                </h5>
                <button type="button" className="btn-close" aria-label="Close" onClick={closeCustomMessageModal}></button>
              </div>
              <div className="modal-body text-secondary">
                <p>{messageModalContent.text}</p>
              </div>
              <div className="modal-footer justify-content-center">
                {messageModalContent.confirmAction ? (
                  <>
                    <Button
                      variant="secondary"
                      onClick={closeCustomMessageModal}
                    >
                      Cancel
                    </Button>
                    <Button
                      variant={messageModalContent.type === 'warning' ? 'warning' : 'primary'}
                      onClick={() => {
                        messageModalContent.confirmAction();
                        closeCustomMessageModal();
                      }}
                    >
                      Confirm
                    </Button>
                  </>
                ) : (
                  <Button
                    variant={messageModalContent.type === 'success' ? 'success' : messageModalContent.type === 'error' ? 'danger' : 'primary'}
                    onClick={closeCustomMessageModal}
                  >
                    OK
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </Container>
  );
}

export default CreateAssociate;
