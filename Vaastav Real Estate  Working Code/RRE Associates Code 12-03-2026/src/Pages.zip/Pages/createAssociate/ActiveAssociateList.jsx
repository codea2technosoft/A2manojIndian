import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { FaPlus } from "react-icons/fa";
import { Modal, Button, Form, Table, Pagination, Container, Row, Col } from "react-bootstrap";

const API_URL = process.env.REACT_APP_API_URL;

function ActiveAssociateList() {
  const [associates, setAssociates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null); 
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
 

 
  const [showMessageModal, setShowMessageModal] = useState(false);
  const [messageModalContent, setMessageModalContent] = useState({
    title: "",
    text: "",
    type: "",
    confirmAction: null,
  });

  
  const showCustomMessageModal = (title, text, type, confirmAction = null) => {
    setMessageModalContent({ title, text, type, confirmAction });
    setShowMessageModal(true);
  };

  const closeCustomMessageModal = () => {
    setShowMessageModal(false);
    setMessageModalContent({ title: "", text: "", type: "", confirmAction: null });
  };


  const getAuthToken = () => {
    return localStorage.getItem("token"); 
  };

  
  const fetchAssociates = async (page = 1) => {
    setLoading(true);
    setError(null); 
    try {
      const token = getAuthToken();
      if (!token) {
        showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
        throw new Error("Authentication token not found. Please log in.");
      }

      const response = await fetch(
        `${API_URL}/Associate-list-active?page=${page}&limit=10`, 
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (!response.ok) {
        if (response.status === 401) {
          showCustomMessageModal("Authorization Error", "Unauthorized: Please log in again.", "error");
          throw new Error("Unauthorized: Please log in again.");
        }
        const errorData = await response.json();
        showCustomMessageModal("Error", errorData.message || "Failed to fetch associates.", "error");
        throw new Error(errorData.message || "Failed to fetch associates.");
      }

      const data = await response.json();
      
      setAssociates(data.data || []);
      setTotalPages(data.data.totalPages || 1);
      setCurrentPage(page);
    } catch (err) {
      console.error("Fetch associates error:", err);
      
    } finally {
      setLoading(false);
    }
  };


  useEffect(() => {
    fetchAssociates(currentPage);
  }, [currentPage]);

 
  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  
  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: "80vh" }}>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  return (
    <Container className="mt-4">
      <h1 className="mb-4 text-center">All Associate List</h1>

      <div className="table-responsive">
        <Table striped bordered hover className="shadow-sm">
          <thead className="bg-primary text-white">
            <tr>
              <th>ID</th>
              <th>Username</th>
              <th>Email</th>
              <th>Mobile</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {associates.length > 0 ? (
              associates.map((associate) => (
                <tr key={associate.id}>
                  <td>{associate.id}</td>
                  <td>{associate.username}</td>
                  <td>{associate.email}</td>
                  <td>{associate.mobile}</td>
                  <td>
                    <span
                      className={`badge ${
                        associate.status === "active" ? "bg-success" : "bg-danger"
                      }`}
                    >
                      {associate.status}
                    </span>
                  </td>
                 
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="6" className="text-center">
                  No associates found.
                </td>
              </tr>
            )}
          </tbody>
        </Table>
      </div>

     
      <div className="d-flex justify-content-center mt-4">
        <Pagination>
          <Pagination.First onClick={() => handlePageChange(1)} disabled={currentPage === 1} />
          <Pagination.Prev
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
          />
          {[...Array(totalPages)].map((_, index) => (
            <Pagination.Item
              key={index + 1}
              active={index + 1 === currentPage}
              onClick={() => handlePageChange(index + 1)}
            >
              {index + 1}
            </Pagination.Item>
          ))}
          <Pagination.Next
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
          />
          <Pagination.Last
            onClick={() => handlePageChange(totalPages)}
            disabled={currentPage === totalPages}
          />
        </Pagination>
      </div>

      
      {showMessageModal && (
        <div className="modal d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className={`modal-content border-top border-4 ${messageModalContent.type === 'success' ? 'border-success' : messageModalContent.type === 'error' ? 'border-danger' : 'border-warning'}`}>
              <div className="modal-header d-flex justify-content-between align-items-center">
                <h5 className={`modal-title ${messageModalContent.type === 'success' ? 'text-success' : messageModalContent.type === 'error' ? 'text-danger' : 'text-warning'}`}>
                  {messageModalContent.title}
                </h5>
                <button type="button" className="btn-close" aria-label="Close" onClick={closeCustomMessageModal}></button>
              </div>
              <div className="modal-body text-secondary">
                <p>{messageModalContent.text}</p>
              </div>
              <div className="modal-footer justify-content-center">
                {messageModalContent.confirmAction ? (
                  <>
                    <Button
                      variant="secondary"
                      onClick={closeCustomMessageModal}
                    >
                      Cancel
                    </Button>
                    <Button
                      variant={messageModalContent.type === 'warning' ? 'warning' : 'primary'}
                      onClick={() => {
                        messageModalContent.confirmAction();
                        closeCustomMessageModal();
                      }}
                    >
                      Confirm
                    </Button>
                  </>
                ) : (
                  <Button
                    variant={messageModalContent.type === 'success' ? 'success' : messageModalContent.type === 'error' ? 'danger' : 'primary'}
                    onClick={closeCustomMessageModal}
                  >
                    OK
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </Container>
  );
}

export default ActiveAssociateList;
