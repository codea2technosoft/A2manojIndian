import React from "react";
import {
  FaUserCircle,
  FaUserCheck
} from "react-icons/fa";
import {
  MdSettings,
  MdAssignmentTurnedIn
} from "react-icons/md";
import {
  PiListNumbersFill
} from "react-icons/pi";
import {
  RiCloseCircleLine
} from "react-icons/ri";
import {
  HiMiniCubeTransparent
} from "react-icons/hi2";
import {
  Container,
  Row,
  Col,
  Card
} from "react-bootstrap";

// Icon mapping
const iconMap = {
  FaUserCircle: FaUserCircle,
  FaUserCheck: FaUserCheck,
  MdSettings: MdSettings,
  MdAssignmentTurnedIn: MdAssignmentTurnedIn,
  HiMiniCubeTransparent: HiMiniCubeTransparent,
  PiListNumbersFill: PiListNumbersFill,
  RiCloseCircleLine: RiCloseCircleLine,
};

const Dashboard = () => {
  const dashboardData = [
    { title: "Today Associates", value: 8, icon: "FaUserCircle", color: "primary" },
    { title: "Today Channels", value: 4, icon: "FaUserCheck", color: "info" },
    { title: "Today Users", value: 10, icon: "MdSettings", color: "success" },
    { title: "Today Projects", value: 2, icon: "MdAssignmentTurnedIn", color: "warning" },
    { title: "Today Blocks", value: 6, icon: "HiMiniCubeTransparent", color: "danger" },
    { title: "Today Plots", value: 20, icon: "PiListNumbersFill", color: "secondary" },

    { title: "Inactive Associates", value: 1, icon: "RiCloseCircleLine", color: "danger" },
    { title: "Inactive Channels", value: 2, icon: "RiCloseCircleLine", color: "danger" },
    { title: "Inactive Users", value: 0, icon: "RiCloseCircleLine", color: "danger" },
  ];

  return (
    <Container className="dashboard mt-5">
      <h2 className="mb-4 text-center text-primary">Simple Associate Dashboard</h2>
      <Row className="g-4">
        {dashboardData.map((item, index) => {
          const IconComponent = iconMap[item.icon];
          const cardColorClass = item.color ? `bg-${item.color}` : "bg-secondary";
          const textColorClass = "text-white";

          return (
            <Col key={index} xs={12} sm={6} md={4} lg={3}>
              <Card className={`h-100 shadow-sm border-0 rounded-3 ${cardColorClass} ${textColorClass}`}>
                <Card.Body className="d-flex flex-column align-items-center justify-content-center p-4">
                  {IconComponent && (
                    <div className="mb-3">
                      <IconComponent size={40} className={textColorClass} />
                    </div>
                  )}
                  <Card.Title className="text-center mb-2 fs-5 fw-bold">{item.title}</Card.Title>
                  <Card.Text className="text-center fs-3 fw-bolder">
                    {item.value}
                  </Card.Text>
                </Card.Body>
              </Card>
            </Col>
          );
        })}
      </Row>
    </Container>
  );
};

export default Dashboard;
