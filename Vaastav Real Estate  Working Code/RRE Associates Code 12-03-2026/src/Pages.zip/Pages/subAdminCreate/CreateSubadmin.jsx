import React, { useState } from "react";
import Swal from "sweetalert2"; 
import { Form, Button, Container, Row, Col, Card } from "react-bootstrap";


const API_URL = process.env.REACT_APP_API_URL;

function CreateSubadmin() {
  
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    status: "active", 
  });

 
  const [errors, setErrors] = useState({});

 
  const [loading, setLoading] = useState(false);

 
  const getAuthToken = () => {
    return localStorage.getItem("token"); 
  };

 
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
    
    if (errors[name]) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        [name]: null,
      }));
    }
  };

 
  const validateForm = () => {
    let newErrors = {};
    let isValid = true;

    
    if (!formData.email.trim()) {
      newErrors.email = "Email is required.";
      isValid = false;
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Email address is invalid.";
      isValid = false;
    }

   
    if (!formData.password.trim()) {
      newErrors.password = "Password is required.";
      isValid = false;
    } else if (formData.password.length < 6) {
      newErrors.password = "Password must be at least 6 characters long.";
      isValid = false;
    }

    
    if (!formData.status) {
      newErrors.status = "Status is required.";
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleSubmit = async (e) => {
    e.preventDefault(); 

    
    if (!validateForm()) {
      Swal.fire({
        icon: "error",
        title: "Validation Error",
        text: "Please correct the errors in the form.",
      });
      return; 
    }

    setLoading(true); 

    try {
      const token = getAuthToken();
      if (!token) {
        throw new Error("Authentication token not found. Please log in.");
      }

      const response = await fetch(`${API_URL}/sub-admin-create`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`, 
        },
        body: JSON.stringify(formData), 
      });

      if (!response.ok) {
       
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to create sub-admin.");
      }

      
      const result = await response.json();
      Swal.fire("Success", result.message || "Sub-admin created successfully!", "success");

      
      setFormData({
        email: "",
        password: "",
        status: "active",
      });
      setErrors({}); 

    } catch (err) {
      console.error("Error creating sub-admin:", err);
      Swal.fire("Error", err.message, "error");
    } finally {
      setLoading(false); 
    }
  };

  return (
    <Container className="mt-5">
      <Row className="justify-content-center">
        <Col md={8} lg={6}>
          <Card className="shadow-lg rounded-3">
            <Card.Header className="bg-primary text-white text-center py-3 rounded-top-3">
              <h2 className="mb-0">Create New Sub-admin</h2>
            </Card.Header>
            <Card.Body className="p-4">
              <Form onSubmit={handleSubmit}>
               
                <Form.Group className="mb-3" controlId="formEmail">
                  <Form.Label>Email address</Form.Label>
                  <Form.Control
                    type="email"
                    name="email"
                    placeholder="Enter email"
                    value={formData.email}
                    onChange={handleChange}
                    isInvalid={!!errors.email} 
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.email}
                  </Form.Control.Feedback>
                </Form.Group>

               
                <Form.Group className="mb-3" controlId="formPassword">
                  <Form.Label>Password</Form.Label>
                  <Form.Control
                    type="password"
                    name="password"
                    placeholder="Password"
                    value={formData.password}
                    onChange={handleChange}
                    isInvalid={!!errors.password}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.password}
                  </Form.Control.Feedback>
                </Form.Group>

               
                <Form.Group className="mb-4" controlId="formStatus">
                  <Form.Label>Status</Form.Label>
                  <Form.Select
                    name="status"
                    value={formData.status}
                    onChange={handleChange}
                    isInvalid={!!errors.status}
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </Form.Select>
                  <Form.Control.Feedback type="invalid">
                    {errors.status}
                  </Form.Control.Feedback>
                </Form.Group>

                
                <Button
                  variant="primary"
                  type="submit"
                  className="w-100 py-2"
                  disabled={loading} 
                >
                  {loading ? "Creating..." : "Create Sub-admin"}
                </Button>
              </Form>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
}

export default CreateSubadmin;