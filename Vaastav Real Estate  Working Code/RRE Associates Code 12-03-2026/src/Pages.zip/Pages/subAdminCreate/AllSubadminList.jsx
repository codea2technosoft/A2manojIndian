import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Swal from "sweetalert2";
import { Form, Button, Table, Pagination, Container, Row, Col } from "react-bootstrap";
import { FaPlus } from "react-icons/fa";


const API_URL = process.env.REACT_APP_API_URL;

function AllSubadminList() {

  const [subadmins, setSubadmins] = useState([]);
  
  const [loading, setLoading] = useState(true);
  
  const [error, setError] = useState(null);
  
  const [currentPage, setCurrentPage] = useState(1);

  const [totalPages, setTotalPages] = useState(1);
 
  const [searchEmail, setSearchEmail] = useState("");

  
  const getAuthToken = () => {
    return localStorage.getItem("token"); 
  };

  
  const fetchSubadmins = async (page = 1, email = "") => {
    setLoading(true); 
    setError(null); 

    try {
      const token = getAuthToken();
      if (!token) {
        throw new Error("Authentication token not found. Please log in.");
      }

    
      const response = await fetch(
        `${API_URL}/sub-admin-list?page=${page}&limit=10&email=${email}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`, 
          },
        }
      );

      if (!response.ok) {
        
        if (response.status === 401) {
          throw new Error("Unauthorized: Please log in again.");
        }
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to fetch sub-admins.");
      }

      const data = await response.json();
      
      setSubadmins(data.data || []);
      setTotalPages(data.data.totalPages || 1);
      setCurrentPage(page); 

    } catch (err) {
      console.error("Fetch sub-admins error:", err);
      setError(err.message); 
      Swal.fire("Error", err.message, "error"); 
    } finally {
      setLoading(false); 
    }
  };

 
  useEffect(() => {
    fetchSubadmins(currentPage, searchEmail);
  }, [currentPage, searchEmail]); 

 
  const handlePageChange = (pageNumber) => {
    if (pageNumber > 0 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
    }
  };


  const handleSearchChange = (e) => {
    setSearchEmail(e.target.value);
    setCurrentPage(1); 
  };


  const handleStatusUpdate = async (subadminId, currentStatus) => {
    
    Swal.fire({
      title: "Are you sure?",
      text: `Do you want to change the status to ${currentStatus === "active" ? "inactive" : "active"}?`,
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, change it!",
      cancelButtonText: "No, cancel!",
    }).then(async (result) => {
      if (result.isConfirmed) {
        setLoading(true); 
        setError(null); 

        try {
          const token = getAuthToken();
          if (!token) {
            throw new Error("Authentication token not found. Please log in.");
          }

          const newStatus = currentStatus === "active" ? "inactive" : "active";
          const response = await fetch(`${API_URL}/sub-admin-status-update`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({
              id: subadminId,
              status: newStatus,
            }),
          });

          if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || "Failed to update sub-admin status.");
          }

          Swal.fire("Success", "Sub-admin status updated successfully!", "success");
          fetchSubadmins(currentPage, searchEmail);

        } catch (err) {
          console.error("Status update error:", err);
          setError(err.message);
          Swal.fire("Error", err.message, "error");
        } finally {
          setLoading(false); 
        }
      }
    });
  };


  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: "80vh" }}>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }


  if (error) {
    return (
      <div className="alert alert-danger text-center m-5" role="alert">
        {error}
        <button className="btn btn-primary ms-3" onClick={() => fetchSubadmins()}>
          Retry
        </button>
      </div>
    );
  }

  return (
    <Container className="mt-4">
      <h1 className="mb-4 text-center">All Sub-admin List</h1>

      <Row className="mb-3 align-items-center">
        <Col md={6}>
          <Form.Group controlId="searchEmail">
            <Form.Control
              type="text"
              placeholder="Search by email..."
              value={searchEmail}
              onChange={handleSearchChange}
            />
          </Form.Group>
        </Col>
        <Col md={6} className="text-end">
          <Link to="/create-subadmin" className="btn btn-success d-inline-flex align-items-center">
            <FaPlus className="me-2" /> Create New Sub-admin
          </Link>
        </Col>
      </Row>

      <div className="table-responsive">
        <Table striped bordered hover className="shadow-sm">
          <thead className="bg-primary text-white">
            <tr>
              <th>ID</th>
              <th>Email</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {subadmins.length > 0 ? (
              subadmins.map((subadmin) => (
                <tr key={subadmin.id}>
                  <td>{subadmin.id}</td>
                  <td>{subadmin.email}</td>
                  <td>
                    <span
                      className={`badge ${
                        subadmin.status === "active" ? "bg-success" : "bg-danger"
                      }`}
                    >
                      {subadmin.status}
                    </span>
                  </td>
                  <td>
                    <Button
                      variant={subadmin.status === "active" ? "danger" : "success"}
                      size="sm"
                      onClick={() => handleStatusUpdate(subadmin.id, subadmin.status)}
                    >
                      {subadmin.status === "active" ? "Deactivate" : "Activate"}
                    </Button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="4" className="text-center">
                  No sub-admins found.
                </td>
              </tr>
            )}
          </tbody>
        </Table>
      </div>

      
      <div className="d-flex justify-content-center mt-4">
        <Pagination>
          <Pagination.First onClick={() => handlePageChange(1)} disabled={currentPage === 1} />
          <Pagination.Prev
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
          />
          {[...Array(totalPages)].map((_, index) => (
            <Pagination.Item
              key={index + 1}
              active={index + 1 === currentPage}
              onClick={() => handlePageChange(index + 1)}
            >
              {index + 1}
            </Pagination.Item>
          ))}
          <Pagination.Next
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
          />
          <Pagination.Last
            onClick={() => handlePageChange(totalPages)}
            disabled={currentPage === totalPages}
          />
        </Pagination>
      </div>
    </Container>
  );
}

export default AllSubadminList;