import React, { useState, useRef } from "react";
import Swal from "sweetalert2"; 
import { Form, Button, Container, Row, Col, Card } from "react-bootstrap"; 

const API_URL = process.env.REACT_APP_API_URL;

function CreateGallery() {
  
  const [formData, setFormData] = useState({
    image: null, 
    status: "active", 
  });

  
  const [errors, setErrors] = useState({});

 
  const [loading, setLoading] = useState(false);

 
  const imageInputRef = useRef(null);


  const getAuthToken = () => {
    return localStorage.getItem("token"); 
  };


  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (name === "image") {
      setFormData((prevData) => ({
        ...prevData,
        image: files[0], 
      }));
    } else {
      setFormData((prevData) => ({
        ...prevData,
        [name]: value,
      }));
    }
    
    if (errors[name]) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        [name]: null,
      }));
    }
  };

 
  const validateForm = () => {
    let newErrors = {};
    let isValid = true;

    
    if (!formData.image) {
      newErrors.image = "Gallery image is required.";
      isValid = false;
    }

    
    if (!formData.status) {
      newErrors.status = "Status is required.";
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  
  const handleSubmit = async (e) => {
    e.preventDefault(); 

   
    if (!validateForm()) {
      Swal.fire({
        icon: "error",
        title: "Validation Error",
        text: "Please correct the errors in the form.",
      });
      return; 
    }

    setLoading(true); 

    try {
      const token = getAuthToken();
      if (!token) {
        throw new Error("Authentication token not found. Please log in.");
      }

      const formDataToSend = new FormData();
      formDataToSend.append("image", formData.image);
      formDataToSend.append("status", formData.status);

      const response = await fetch(`${API_URL}/gallery-create`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`, 
         
        },
        body: formDataToSend, 
      });

      if (!response.ok) {
        
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to create gallery image.");
      }

      
      const result = await response.json();
      Swal.fire("Success", result.message || "Gallery image created successfully!", "success");

      
      setFormData({
        image: null,
        status: "active",
      });
      setErrors({}); 
      if (imageInputRef.current) {
        imageInputRef.current.value = ""; 
      }

    } catch (err) {
      console.error("Error creating gallery image:", err);
      Swal.fire("Error", err.message, "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container className="mt-5">
      <Row className="justify-content-center">
        <Col md={8} lg={6}>
          <Card className="shadow-lg rounded-3">
            <Card.Header className="bg-primary text-white text-center py-3 rounded-top-3">
              <h2 className="mb-0">Create New Gallery Image</h2>
            </Card.Header>
            <Card.Body className="p-4">
              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-3" controlId="formImage">
                  <Form.Label>Gallery Image</Form.Label>
                  <Form.Control
                    type="file"
                    name="image"
                    accept="image/*" 
                    onChange={handleChange}
                    isInvalid={!!errors.image} 
                    ref={imageInputRef}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.image}
                  </Form.Control.Feedback>
                </Form.Group>

                {/* Status Select */}
                <Form.Group className="mb-4" controlId="formStatus">
                  <Form.Label>Status</Form.Label>
                  <Form.Select
                    name="status"
                    value={formData.status}
                    onChange={handleChange}
                    isInvalid={!!errors.status}
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </Form.Select>
                  <Form.Control.Feedback type="invalid">
                    {errors.status}
                  </Form.Control.Feedback>
                </Form.Group>
                <Button
                  variant="primary"
                  type="submit"
                  className="w-100 py-2"
                  disabled={loading} 
                >
                  {loading ? "Creating..." : "Create Gallery Image"}
                </Button>
              </Form>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
}

export default CreateGallery;