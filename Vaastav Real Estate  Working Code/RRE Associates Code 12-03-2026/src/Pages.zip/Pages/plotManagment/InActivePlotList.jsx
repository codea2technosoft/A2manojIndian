import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { FaPlus } from "react-icons/fa";
import { Modal, Button, Form, Table, Pagination, Row, Col } from "react-bootstrap";

const API_URL = process.env.REACT_APP_API_URL;

function InActivePlotList() {
  const [plots, setPlots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [searchQuery, setSearchQuery] = useState(""); 
  const [showViewModal, setShowViewModal] = useState(false);
  const [selectedPlot, setSelectedPlot] = useState(null);
  const [showMessageModal, setShowMessageModal] = useState(false);
  const [messageModalContent, setMessageModalContent] = useState({
    title: "",
    text: "",
    type: "", 
    confirmAction: null, 
  });

 
  const showCustomMessageModal = (title, text, type, confirmAction = null) => {
    setMessageModalContent({ title, text, type, confirmAction });
    setShowMessageModal(true);
  };


  const closeCustomMessageModal = () => {
    setShowMessageModal(false);
    setMessageModalContent({ title: "", text: "", type: "", confirmAction: null });
  };

  const getAuthToken = () => {
    return localStorage.getItem("token");
  };

  const fetchActivePlots = async (page = 1, query = "") => {
    setLoading(true);
    setError(null);
    try {
      const token = getAuthToken();
      if (!token) {
        showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
        return;
      }

   
      const url = new URL(`${API_URL}/plot-list-inactive`);
      url.searchParams.append("page", page);
      url.searchParams.append("limit", 10); 
      if (query) {
        url.searchParams.append("plot_shop_villa_no", query); 
      }

      const response = await fetch(url.toString(), {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        if (response.status === 401) {
          showCustomMessageModal("Authorization Error", "Unauthorized: Please log in again.", "error");
        }
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to fetch active plots.");
      }

      const data = await response.json();
      setPlots(data.data || []);
      setTotalPages(data.totalPages || 1); 
      setCurrentPage(data.currentPage || page); 
    } catch (err) {
      console.error("Fetch active plots error:", err);
      setError(err.message);
     
      if (!showMessageModal) {
        showCustomMessageModal("Error", err.message || "An unexpected error occurred while fetching active plots.", "error");
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchActivePlots(currentPage, searchQuery);
  }, [currentPage, searchQuery]);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
    setCurrentPage(1); 
  };

  const handleViewPlot = async (plotId) => {
    setLoading(true);
    try {
      const token = getAuthToken();
      if (!token) {
        showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
        return;
      }

      const response = await fetch(`${API_URL}/plot-view`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ id: plotId }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to fetch plot details.");
      }

      const data = await response.json();
      setSelectedPlot(data.data);
      setShowViewModal(true);
    } catch (err) {
      console.error("View plot error:", err);
      setError(err.message);
      showCustomMessageModal("Error", err.message || "An unexpected error occurred while fetching plot details.", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleCloseViewModal = () => {
    setShowViewModal(false);
    setSelectedPlot(null);
  };

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: "80vh" }}>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="alert alert-danger text-center m-5" role="alert">
        {error}
        <button className="btn btn-primary ms-3" onClick={() => fetchActivePlots()}>
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="container mt-4 userlist">
      <h1 className="mb-4 text-center">Inactive Plot List</h1>

      <div className="d-flex justify-content-between align-items-center mb-3">
        <Col md={4}>
          <Form.Group controlId="searchPlot">
            <Form.Control
              type="text"
              placeholder="Search by plot/shop/villa no."
              value={searchQuery}
              onChange={handleSearchChange}
            />
          </Form.Group>
        </Col>
      </div>

      <div className="table-responsive">
        <Table striped bordered hover className="shadow-sm">
          <thead className="bg-primary text-white">
            <tr>
              <th>ID</th>
              <th>Project Name</th>
              <th>Block Name</th>
              <th>Property Type</th>
              <th>Plot/Shop/Villa No.</th>
              <th>Plot Size (sqft)</th>
              <th>Plot Rate</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {plots?.length > 0 ? (
              plots.map((plot) => (
                <tr key={plot.id}>
                  <td>{plot.id}</td>
                  <td>{plot.project_name}</td>
                  <td>{plot.block_name}</td>
                  <td>{plot.property_type}</td>
                  <td>{plot.plot_shop_villa_no}</td>
                  <td>{plot.plot_size}</td>
                  <td>{plot.plot_rate}</td>
                  <td>
                    <span className="badge bg-success"> 
                      {plot.status}
                    </span>
                  </td>
                  <td>
                    <Button
                      variant="info"
                      size="sm"
                      className="me-2"
                      onClick={() => handleViewPlot(plot.id)}
                    >
                      View
                    </Button>
                   
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="9" className="text-center">
                  No active plots found.
                </td>
              </tr>
            )}
          </tbody>
        </Table>
      </div>

      <div className="d-flex justify-content-center mt-4">
        <Pagination>
          <Pagination.First onClick={() => handlePageChange(1)} disabled={currentPage === 1} />
          <Pagination.Prev
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
          />
          {[...Array(totalPages)].map((_, index) => (
            <Pagination.Item
              key={index + 1}
              active={index + 1 === currentPage}
              onClick={() => handlePageChange(index + 1)}
            >
              {index + 1}
            </Pagination.Item>
          ))}
          <Pagination.Next
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
          />
          <Pagination.Last
            onClick={() => handlePageChange(totalPages)}
            disabled={currentPage === totalPages}
          />
        </Pagination>
      </div>

   
      <Modal show={showViewModal} onHide={handleCloseViewModal} centered>
        <Modal.Header closeButton>
          <Modal.Title>Plot Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedPlot && (
            <div>
              <p><strong>ID:</strong> {selectedPlot.id}</p>
              <p><strong>Project Name:</strong> {selectedPlot.project_name}</p>
              <p><strong>Block Name:</strong> {selectedPlot.block_name}</p>
              <p><strong>Property Type:</strong> {selectedPlot.property_type}</p>
              <p><strong>Plot/Shop/Villa No.:</strong> {selectedPlot.plot_shop_villa_no}</p>
              <p><strong>Plot Size:</strong> {selectedPlot.plot_size} sqft</p>
              <p><strong>Plot Sq. Yd.:</strong> {selectedPlot.plot_sqyd}</p>
              <p><strong>Plot Rate:</strong> {selectedPlot.plot_rate}</p>
              <p><strong>Registry Patta:</strong> {selectedPlot.resgistry_patta}</p>
              {selectedPlot.resgistry_patta === "yes" && (
                <p><strong>Registry Date:</strong> {selectedPlot.resgistry_date}</p>
              )}
              <p><strong>Plot Hold:</strong> {selectedPlot.plot_hold}</p>
              <p><strong>Plot Address:</strong> {selectedPlot.plot_address}</p>
              <p>
                <strong>Status:</strong>{" "}
                <span className="badge bg-success">
                  {selectedPlot.status}
                </span>
              </p>
            </div>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseViewModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>

    
      {showMessageModal && (
        <div className="modal d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className={`modal-content border-top border-4 ${messageModalContent.type === 'success' ? 'border-success' : messageModalContent.type === 'error' ? 'border-danger' : 'border-warning'}`}>
              <div className="modal-header d-flex justify-content-between align-items-center">
                <h5 className={`modal-title ${messageModalContent.type === 'success' ? 'text-success' : messageModalContent.type === 'error' ? 'text-danger' : 'text-warning'}`}>
                  {messageModalContent.title}
                </h5>
                <button type="button" className="btn-close" aria-label="Close" onClick={closeCustomMessageModal}></button>
              </div>
              <div className="modal-body text-secondary">
                <p>{messageModalContent.text}</p>
              </div>
              <div className="modal-footer justify-content-center">
                {messageModalContent.confirmAction ? (
                  <>
                    <Button
                      variant="secondary"
                      onClick={closeCustomMessageModal}
                    >
                      Cancel
                    </Button>
                    <Button
                      variant={messageModalContent.type === 'warning' ? 'warning' : 'primary'}
                      onClick={() => {
                        messageModalContent.confirmAction();
                        closeCustomMessageModal();
                      }}
                    >
                      Confirm
                    </Button>
                  </>
                ) : (
                  <Button
                    variant={messageModalContent.type === 'success' ? 'success' : messageModalContent.type === 'error' ? 'danger' : 'primary'}
                    onClick={closeCustomMessageModal}
                  >
                    OK
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default InActivePlotList;
