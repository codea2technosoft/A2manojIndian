import React, { useState, useEffect } from "react";
import { Form, Button, Container, Row, Col, Card, Modal } from "react-bootstrap";
const API_URL = process.env.REACT_APP_API_URL;

function CreatePlot() {
  const [formData, setFormData] = useState({
    project_id: "",
    project_name: "",
    block_id: "",
    block_name: "",
    property_type: "",
    plot_shop_villa_no: "",
    plot_size: "",
    plot_sqyd: "",
    plot_rate: "",
    resgistry_patta: "",
    resgistry_date: "",
    plot_hold: "",
    plot_address: "",
    status: "active",
  });

  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [projects, setProjects] = useState([]);
  const [blocks, setBlocks] = useState([]);
  const [selectedProjectCommissionData, setSelectedProjectCommissionData] = useState(null);

  const [showMessageModal, setShowMessageModal] = useState(false);
  const [messageModalContent, setMessageModalContent] = useState({
    title: "",
    text: "",
    type: "",
    confirmAction: null,
  });

  const showCustomMessageModal = (title, text, type, confirmAction = null) => {
    setMessageModalContent({ title, text, type, confirmAction });
    setShowMessageModal(true);
  };

  const closeCustomMessageModal = () => {
    setShowMessageModal(false);
    setMessageModalContent({ title: "", text: "", type: "", confirmAction: null });
  };

  const getAuthToken = () => {
    return localStorage.getItem("token");
  };

  useEffect(() => {
    const fetchProjectsList = async () => {
      setLoading(true);
      try {
        const token = getAuthToken();
        if (!token) {
          showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
          return;
        }

        const response = await fetch(`${API_URL}/project-list-block`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        });

        if (!response.ok) {
          const errorData = await response.json();
          showCustomMessageModal("Error", errorData.message || "Failed to fetch projects.", "error");
          return;
        }

        const data = await response.json();
        setProjects(data.data || []);
      } catch (err) {
        console.error("Fetch projects error:", err);
        showCustomMessageModal("Error", err.message || "An unexpected error occurred while fetching projects.", "error");
      } finally {
        setLoading(false);
      }
    };

    fetchProjectsList();
  }, []);

  useEffect(() => {
    const fetchBlocksList = async () => {
      if (formData.project_id) {
        setLoading(true);
        try {
          const token = getAuthToken();
          if (!token) {
            showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
            return;
          }

          const response = await fetch(`${API_URL}/block-list-plot`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({ project_id: formData.project_id }),
          });

          if (!response.ok) {
            const errorData = await response.json();
            showCustomMessageModal("Error", errorData.message || "Failed to fetch blocks.", "error");
            setBlocks([]);
            return;
          }

          const data = await response.json();
          setBlocks(data.data || []);
        } catch (err) {
          console.error("Fetch blocks error:", err);
          showCustomMessageModal("Error", err.message || "An unexpected error occurred while fetching blocks.", "error");
          setBlocks([]);
        } finally {
          setLoading(false);
        }
      } else {
        setBlocks([]);
        setFormData(prev => ({ ...prev, block_id: "", block_name: "" }));
      }
    };

    fetchBlocksList();
  }, [formData.project_id]);


  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prevData) => {
      const newData = { ...prevData, [name]: value };

      if (name === "project_id") {
        const selectedProjectObj = projects.find(proj => proj.id.toString() === value);
        newData.project_name = selectedProjectObj ? selectedProjectObj.name : "";
        newData.block_id = "";
        newData.block_name = "";
        setSelectedProjectCommissionData(selectedProjectObj || null);
      }
      else if (name === "block_id") {
        // Assuming the block object has a 'name' property for the block's name
        const selectedBlockObj = blocks.find(block => block.id.toString() === value);
        newData.block_name = selectedBlockObj ? selectedBlockObj.name : ""; // Changed from blockname to name
      }

      return newData;
    });

    if (errors[name]) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        [name]: null,
      }));
    }
  };


  const validateForm = () => {
    let newErrors = {};
    let isValid = true;

   
    const directRequiredFields = [
      "project_id", "block_id", "property_type", "plot_shop_villa_no",
      "plot_size", "plot_sqyd", "plot_rate", "resgistry_patta",
      "plot_hold", "plot_address", "status"
    ];

    directRequiredFields.forEach(field => {
      if (!formData[field] || (typeof formData[field] === 'string' && !formData[field].trim())) {
        newErrors[field] = `${field.replace(/_/g, ' ').replace(/\b\w/g, char => char.toUpperCase())} is required.`;
        isValid = false;
      }
    });

  
    if (formData.project_id && (!formData.project_name || !formData.project_name.trim())) {
      newErrors.project_id = newErrors.project_id || "Selected project name could not be determined.";
      isValid = false;
    }
    if (formData.block_id && (!formData.block_name || !formData.block_name.trim())) {
      newErrors.block_id = newErrors.block_id || "Selected block name could not be determined.";
      isValid = false;
    }

    const numberFields = ["plot_size", "plot_sqyd", "plot_rate"];
    numberFields.forEach(field => {
      if (formData[field] && (isNaN(formData[field]) || parseFloat(formData[field]) <= 0)) {
        newErrors[field] = `${field.replace(/_/g, ' ').replace(/\b\w/g, char => char.toUpperCase())} must be a positive number.`;
        isValid = false;
      }
    });


    if (formData.resgistry_patta === "yes" && !formData.resgistry_date) {
      newErrors.resgistry_date = "Registry Date is required when Registry Patta is 'Yes'.";
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      showCustomMessageModal("Validation Error", "Please correct the errors in the form.", "error");
      return;
    }
    setLoading(true);

    try {
      const token = getAuthToken();
      if (!token) {
        showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
        return;
      }

      const payload = {
        project_id: formData.project_id,
        project_name: formData.project_name,
        block_id: formData.block_id,
        block_name: formData.block_name,
        property_type: formData.property_type,
        plot_shop_villa_no: formData.plot_shop_villa_no,
        plot_size: parseFloat(formData.plot_size),
        plot_sqyd: parseFloat(formData.plot_sqyd),
        plot_rate: parseFloat(formData.plot_rate),
        resgistry_patta: formData.resgistry_patta,
        plot_hold: formData.plot_hold,
        plot_address: formData.plot_address,
        status: formData.status,
      };

      if (formData.resgistry_patta === "yes") {
        payload.resgistry_date = formData.resgistry_date;
      }

      const response = await fetch(`${API_URL}/plot-create`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const errorData = await response.json();
        showCustomMessageModal("Error", errorData.message || "Failed to create plot.", "error");
        return;
      }

      const result = await response.json();
      showCustomMessageModal("Success", result.message || "Plot created successfully!", "success");


      setFormData({
        project_id: "",
        project_name: "",
        block_id: "",
        block_name: "",
        property_type: "",
        plot_shop_villa_no: "",
        plot_size: "",
        plot_sqyd: "",
        plot_rate: "",
        resgistry_patta: "",
        resgistry_date: "",
        plot_hold: "",
        plot_address: "",
        status: "active",
      });
      setErrors({});
      setBlocks([]);
      setSelectedProjectCommissionData(null);

    } catch (err) {
      console.error("Error creating plot:", err);
      showCustomMessageModal("Error", err.message || "An unexpected error occurred.", "error");
    } finally {
      setLoading(false);
    }
  };

  const getCurrentCommission = () => {
    if (!selectedProjectCommissionData || !formData.property_type) return "N/A";

    switch (formData.property_type) {
      case "Resident":
        return `${selectedProjectCommissionData.resident_commission || 0}%`;
      case "Commercial":
        return `${selectedProjectCommissionData.commercial_commission || 0}%`;
      case "Corner Resident":
        return `${selectedProjectCommissionData.corner_resident_commission || 0}%`;
      case "Corner Commercial":
        return `${selectedProjectCommissionData.corner_commercial_commission || 0}%`;
      default:
        return "N/A";
    }
  };

  return (
    <Container className="mt-5">
      <Row className="justify-content-center">
        <Col md={10} lg={8}>
          <Card className="shadow-lg rounded-3">
            <Card.Header className="bg-primary text-white text-center py-3 rounded-top-3">
              <h2 className="mb-0">Create New Plot/Shop/Villa</h2>
            </Card.Header>
            <Card.Body className="p-4">
              <Form onSubmit={handleSubmit}>
                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formProjectId">
                      <Form.Label>Select Project <span className="text-danger">*</span></Form.Label>
                      <Form.Select
                        name="project_id"
                        value={formData.project_id}
                        onChange={handleChange}
                        isInvalid={!!errors.project_id}
                        disabled={loading || projects.length === 0}
                      >
                        <option value="">Select a Project</option>
                        {projects.map((project) => (
                          <option key={project.id} value={project.id}>
                            {project.name}
                          </option>
                        ))}
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.project_id}
                      </Form.Control.Feedback>
                      {loading && projects.length === 0 && (
                        <small className="text-muted">Loading projects...</small>
                      )}
                      {!loading && projects.length === 0 && (
                        <small className="text-danger">No projects available. Please create one first.</small>
                      )}
                    </Form.Group>
                  </Col>

                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formBlockId">
                      <Form.Label>Select Block <span className="text-danger">*</span></Form.Label>
                      <Form.Select
                        name="block_id"
                        value={formData.block_id}
                        onChange={handleChange}
                        isInvalid={!!errors.block_id}
                        disabled={!formData.project_id || loading || blocks.length === 0}
                      >
                        <option value="">Select a Block</option>
                        {blocks.map((block) => (
                          <option key={block.id} value={block.id}>
                            {block.name}
                          </option>
                        ))}
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.block_id}
                      </Form.Control.Feedback>
                      {formData.project_id && loading && blocks.length === 0 && (
                        <small className="text-muted">Loading blocks...</small>
                      )}
                      {formData.project_id && !loading && blocks.length === 0 && (
                        <small className="text-danger">No blocks available for this project. Please create one first.</small>
                      )}
                    </Form.Group>
                  </Col>
                </Row>

                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formPropertyType">
                      <Form.Label>Property Type <span className="text-danger">*</span></Form.Label>
                      <Form.Select
                        name="property_type"
                        value={formData.property_type}
                        onChange={handleChange}
                        isInvalid={!!errors.property_type}
                      >
                        <option value="">Select Property Type</option>
                        <option value="Resident">Resident</option>
                        <option value="Commercial">Commercial</option>
                        <option value="Corner Resident">Corner Resident</option>
                        <option value="Corner Commercial">Corner Commercial</option>
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.property_type}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>

                  <Col md={6}>
                    <Form.Group className="mb-3">
                      <Form.Label>Current Commission Rate</Form.Label>
                      <Form.Control
                        type="text"
                        value={getCurrentCommission()}
                        readOnly
                        disabled={!formData.property_type || !selectedProjectCommissionData}
                      />
                      <Form.Text className="text-muted">
                        This is the commission rate for the selected property type based on the chosen project.
                      </Form.Text>
                    </Form.Group>
                  </Col>
                </Row>

                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formPlotShopVillaNo">
                      <Form.Label>Plot/Shop/Villa No. <span className="text-danger">*</span></Form.Label>
                      <Form.Control
                        type="text"
                        name="plot_shop_villa_no"
                        placeholder="e.g., A-101, Shop-5, Villa-B2"
                        value={formData.plot_shop_villa_no}
                        onChange={handleChange}
                        isInvalid={!!errors.plot_shop_villa_no}
                      />
                      <Form.Control.Feedback type="invalid">
                        {errors.plot_shop_villa_no}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>


                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formPlotSize">
                      <Form.Label>Plot Size (sq ft) <span className="text-danger">*</span></Form.Label>
                      <Form.Control
                        type="number"
                        name="plot_size"
                        placeholder="e.g., 1200"
                        value={formData.plot_size}
                        onChange={handleChange}
                        isInvalid={!!errors.plot_size}
                        min="0"
                        step="0.01"
                      />
                      <Form.Control.Feedback type="invalid">
                        {errors.plot_size}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>

                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formPlotSqYd">
                      <Form.Label>Plot Sq. Yd. <span className="text-danger">*</span></Form.Label>
                      <Form.Control
                        type="number"
                        name="plot_sqyd"
                        placeholder="e.g., 133.33"
                        value={formData.plot_sqyd}
                        onChange={handleChange}
                        isInvalid={!!errors.plot_sqyd}
                        min="0"
                        step="0.01"
                      />
                      <Form.Control.Feedback type="invalid">
                        {errors.plot_sqyd}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>


                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formPlotRate">
                      <Form.Label>Plot Rate <span className="text-danger">*</span></Form.Label>
                      <Form.Control
                        type="number"
                        name="plot_rate"
                        placeholder="e.g., 5000"
                        value={formData.plot_rate}
                        onChange={handleChange}
                        isInvalid={!!errors.plot_rate}
                        min="0"
                        step="0.01"
                      />
                      <Form.Control.Feedback type="invalid">
                        {errors.plot_rate}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>

                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formResgistryPatta">
                      <Form.Label>Registry Patta <span className="text-danger">*</span></Form.Label>
                      <Form.Select
                        name="resgistry_patta"
                        value={formData.resgistry_patta}
                        onChange={handleChange}
                        isInvalid={!!errors.resgistry_patta}
                      >
                        <option value="">Select Option</option>
                        <option value="yes">Yes</option>
                        <option value="no">No</option>
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.resgistry_patta}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>


                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formResgistryDate">
                      <Form.Label>Registry Date</Form.Label>
                      <Form.Control
                        type="date"
                        name="resgistry_date"
                        value={formData.resgistry_date}
                        onChange={handleChange}
                        isInvalid={!!errors.resgistry_date}
                        disabled={formData.resgistry_patta !== "yes"}
                      />
                      <Form.Control.Feedback type="invalid">
                        {errors.resgistry_date}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>

                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formPlotHold">
                      <Form.Label>Plot Hold <span className="text-danger">*</span></Form.Label>
                      <Form.Select
                        name="plot_hold"
                        value={formData.plot_hold}
                        onChange={handleChange}
                        isInvalid={!!errors.plot_hold}
                      >
                        <option value="">Select Option</option>
                        <option value="yes">Yes</option>
                        <option value="no">No</option>
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.plot_hold}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>


                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="formStatus">
                      <Form.Label>Status <span className="text-danger">*</span></Form.Label>
                      <Form.Select
                        name="status"
                        value={formData.status}
                        onChange={handleChange}
                        isInvalid={!!errors.status}
                      >
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                      </Form.Select>
                      <Form.Control.Feedback type="invalid">
                        {errors.status}
                      </Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>


                <Form.Group className="mb-4" controlId="formPlotAddress">
                  <Form.Label>Plot Address <span className="text-danger">*</span></Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={3}
                    name="plot_address"
                    placeholder="Enter full plot address"
                    value={formData.plot_address}
                    onChange={handleChange}
                    isInvalid={!!errors.plot_address}
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.plot_address}
                  </Form.Control.Feedback>
                </Form.Group>


                <Button
                  variant="primary"
                  type="submit"
                  className="w-100 py-2"
                  disabled={loading}
                >
                  {loading ? "Creating..." : "Create Plot"}
                </Button>
              </Form>
            </Card.Body>
          </Card>
        </Col>
      </Row>


      {showMessageModal && (
        <div className="modal d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className={`modal-content border-top border-4 ${messageModalContent.type === 'success' ? 'border-success' : messageModalContent.type === 'error' ? 'border-danger' : 'border-warning'}`}>
              <div className="modal-header d-flex justify-content-between align-items-center">
                <h5 className={`modal-title ${messageModalContent.type === 'success' ? 'text-success' : messageModalContent.type === 'error' ? 'text-danger' : 'text-warning'}`}>
                  {messageModalContent.title}
                </h5>
                <button type="button" className="btn-close" aria-label="Close" onClick={closeCustomMessageModal}></button>
              </div>
              <div className="modal-body text-secondary">
                <p>{messageModalContent.text}</p>
              </div>
              <div className="modal-footer justify-content-center">
                {messageModalContent.confirmAction ? (
                  <>
                    <Button
                      variant="secondary"
                      onClick={closeCustomMessageModal}
                    >
                      Cancel
                    </Button>
                    <Button
                      variant={messageModalContent.type === 'warning' ? 'warning' : 'primary'}
                      onClick={() => {
                        messageModalContent.confirmAction();
                        closeCustomMessageModal();
                      }}
                    >
                      Confirm
                    </Button>
                  </>
                ) : (
                  <Button
                    variant={messageModalContent.type === 'success' ? 'success' : messageModalContent.type === 'error' ? 'danger' : 'primary'}
                    onClick={closeCustomMessageModal}
                  >
                    OK
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </Container>
  );
}

export default CreatePlot;
