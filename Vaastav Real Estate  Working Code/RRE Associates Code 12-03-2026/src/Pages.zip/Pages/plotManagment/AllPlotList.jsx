import React, { useEffect, useState, useRef } from "react";
import { Link } from "react-router-dom";
import { FaPlus } from "react-icons/fa";
import { Modal, Button, Form, Table, Pagination, Row, Col } from "react-bootstrap";
const API_URL = process.env.REACT_APP_API_URL;

function AllPlotList() {
  const [plots, setPlots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");
  const [showViewModal, setShowViewModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedPlot, setSelectedPlot] = useState(null);
  const [editFormData, setEditFormData] = useState({
    plot_id: "",
    project_id: "",
    project_name: "",
    block_id: "",
    block_name: "",
    property_type: "",
    plot_shop_villa_no: "",
    plot_size: "",
    plot_sqyd: "",
    plot_rate: "",
    resgistry_patta: "",
    resgistry_date: "",
    plot_hold: "",
    plot_address: "",
    status: "",
  });


  const [projectsForEdit, setProjectsForEdit] = useState([]);
  const [blocksForEdit, setBlocksForEdit] = useState([]);
  const [loadingDropdowns, setLoadingDropdowns] = useState(false); 
  const [showMessageModal, setShowMessageModal] = useState(false);
  const [messageModalContent, setMessageModalContent] = useState({
    title: "",
    text: "",
    type: "",
    confirmAction: null, 
  });

 
  const showCustomMessageModal = (title, text, type, confirmAction = null) => {
    setMessageModalContent({ title, text, type, confirmAction });
    setShowMessageModal(true);
  };

  
  const closeCustomMessageModal = () => {
    setShowMessageModal(false);
    setMessageModalContent({ title: "", text: "", type: "", confirmAction: null });
  };

  const getAuthToken = () => {
    return localStorage.getItem("token");
  };

  
  useEffect(() => {
    const fetchProjectsListForEdit = async () => {
      setLoadingDropdowns(true);
      try {
        const token = getAuthToken();
        if (!token) {
          showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
          setLoadingDropdowns(false);
          return;
        }

        const response = await fetch(`${API_URL}/project-list-block`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        });

        if (!response.ok) {
          const errorData = await response.json();
          showCustomMessageModal("Error", errorData.message || "Failed to fetch projects for dropdown.", "error");
          setLoadingDropdowns(false);
          return;
        }

        const data = await response.json();
        setProjectsForEdit(data.data || []);
      } catch (err) {
        console.error("Fetch projects for edit error:", err);
        showCustomMessageModal("Error", err.message || "An unexpected error occurred while fetching projects for edit.", "error");
      } finally {
        setLoadingDropdowns(false);
      }
    };

    fetchProjectsListForEdit();
  }, []);

  
  useEffect(() => {
    const fetchBlocksListForEdit = async () => {
      if (editFormData.project_id) {
        setLoadingDropdowns(true);
        try {
          const token = getAuthToken();
          if (!token) {
            showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
            setLoadingDropdowns(false);
            return;
          }

          const response = await fetch(`${API_URL}/block-list-plot`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({ project_id: editFormData.project_id }),
          });

          if (!response.ok) {
            const errorData = await response.json();
            showCustomMessageModal("Error", errorData.message || "Failed to fetch blocks for dropdown.", "error");
            setBlocksForEdit([]);
            setLoadingDropdowns(false);
            return;
          }

          const data = await response.json();
          setBlocksForEdit(data.data || []);
        } catch (err) {
          console.error("Fetch blocks for edit error:", err);
          showCustomMessageModal("Error", err.message || "An unexpected error occurred while fetching blocks for edit.", "error");
          setBlocksForEdit([]);
        } finally {
          setLoadingDropdowns(false);
        }
      } else {
        setBlocksForEdit([]);
      }
    };

    fetchBlocksListForEdit();
  }, [editFormData.project_id]); 


  const fetchPlots = async (page = 1, query = "") => {
    setLoading(true);
    setError(null);
    try {
      const token = getAuthToken();
      if (!token) {
        showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
        return;
      }

      const url = new URL(`${API_URL}/plot-list`);
      url.searchParams.append("page", page);
      url.searchParams.append("limit", 10);
      if (query) {
        url.searchParams.append("plot_shop_villa_no", query);
      }

      const response = await fetch(url.toString(), {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        if (response.status === 401) {
          showCustomMessageModal("Authorization Error", "Unauthorized: Please log in again.", "error");
        }
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to fetch plots.");
      }

      const data = await response.json();
      setPlots(data.data || []);
      setTotalPages(data.totalPages || 1);
      setCurrentPage(data.currentPage || page);
    } catch (err) {
      console.error("Fetch plots error:", err);
      setError(err.message);
      if (!showMessageModal) {
        showCustomMessageModal("Error", err.message || "An unexpected error occurred while fetching plots.", "error");
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPlots(currentPage, searchQuery);
  }, [currentPage, searchQuery]);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
    setCurrentPage(1);
  };

  const handleViewPlot = async (plotId) => {
    setLoading(true);
    try {
      const token = getAuthToken();
      if (!token) {
        showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
        return;
      }

      const response = await fetch(`${API_URL}/plot-view`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ id: plotId }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to fetch plot details.");
      }

      const data = await response.json();
      setSelectedPlot(data.data);
      setShowViewModal(true);
    } catch (err) {
      console.error("View plot error:", err);
      setError(err.message);
      showCustomMessageModal("Error", err.message || "An unexpected error occurred while fetching plot details.", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleEditPlot = async (plotId) => {
    setLoading(true);
    try {
      const token = getAuthToken();
      if (!token) {
        showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
        return;
      }

      const response = await fetch(`${API_URL}/plot-edit`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ id: plotId }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to fetch plot for editing.");
      }

      const data = await response.json();
      const plotData = data.data;
      setSelectedPlot(plotData);

      setEditFormData({
        plot_id: plotData.id || "",
        project_id: plotData.project_id || "",
        project_name: plotData.project_name || "",
        block_id: plotData.block_id || "",
        block_name: plotData.block_name || "",
        property_type: plotData.property_type || "",
        plot_shop_villa_no: plotData.plot_shop_villa_no || "",
        plot_size: plotData.plot_size || "",
        plot_sqyd: plotData.plot_sqyd || "",
        plot_rate: plotData.plot_rate || "",
        resgistry_patta: plotData.resgistry_patta || "",
        resgistry_date: plotData.resgistry_date || "",
        plot_hold: plotData.plot_hold || "",
        plot_address: plotData.plot_address || "",
        status: plotData.status || "active",
      });
      setShowEditModal(true);
    } catch (err) {
      console.error("Edit plot error:", err);
      setError(err.message);
      showCustomMessageModal("Error", err.message || "An unexpected error occurred while fetching plot for editing.", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleEditFormChange = (e) => {
    const { name, value } = e.target;

    setEditFormData((prevData) => {
      const newData = { ...prevData, [name]: value };

      if (name === "project_id") {
        const selectedProjectObj = projectsForEdit.find(proj => proj.id.toString() === value);
        newData.project_name = selectedProjectObj ? selectedProjectObj.name : "";
        newData.block_id = ""; 
        newData.block_name = ""; 
        setBlocksForEdit([]); 
      } else if (name === "block_id") {
        const selectedBlockObj = blocksForEdit.find(block => block.id.toString() === value);
        newData.block_name = selectedBlockObj ? selectedBlockObj.name : "";
      }
      return newData;
    });
  };

  const handleUpdatePlot = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const token = getAuthToken();
      if (!token) {
        showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
        return;
      }

      const payload = {
        plot_id: editFormData.plot_id,
        project_id: editFormData.project_id,
        project_name: editFormData.project_name, 
        block_id: editFormData.block_id,
        block_name: editFormData.block_name, 
        property_type: editFormData.property_type,
        plot_shop_villa_no: editFormData.plot_shop_villa_no,
        plot_size: parseFloat(editFormData.plot_size),
        plot_sqyd: parseFloat(editFormData.plot_sqyd),
        plot_rate: parseFloat(editFormData.plot_rate),
        resgistry_patta: editFormData.resgistry_patta,
        plot_hold: editFormData.plot_hold,
        plot_address: editFormData.plot_address,
        status: editFormData.status,
      };

      if (editFormData.resgistry_patta === "yes") {
        payload.resgistry_date = editFormData.resgistry_date;
      }

      const response = await fetch(`${API_URL}/plot-update`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to update plot.");
      }

      showCustomMessageModal("Success", "Plot updated successfully!", "success");
      setShowEditModal(false);
      fetchPlots(currentPage, searchQuery);
    } catch (err) {
      console.error("Update plot error:", err);
      setError(err.message);
      showCustomMessageModal("Error", err.message || "An unexpected error occurred while updating plot.", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleStatusUpdate = async (plotId, currentStatus) => {
    const newStatus = currentStatus === "active" ? "inactive" : "active";
    showCustomMessageModal(
      "Confirm Status Change",
      `Do you want to change the status to ${newStatus}?`,
      "warning",
      async () => {
        setLoading(true);
        try {
          const token = getAuthToken();
          if (!token) {
            showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
            return;
          }

          const response = await fetch(`${API_URL}/plot-status-update`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({ id: plotId, status: newStatus }),
          });

          if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || "Failed to update plot status.");
          }

          showCustomMessageModal("Success", "Plot status updated successfully!", "success");
          fetchPlots(currentPage, searchQuery);
        } catch (err) {
          console.error("Status update error:", err);
          setError(err.message);
          showCustomMessageModal("Error", err.message || "An unexpected error occurred while updating plot status.", "error");
        } finally {
          setLoading(false);
        }
      }
    );
  };

  const handleDeletePlot = async (plotId) => {
    showCustomMessageModal(
      "Confirm Deletion",
      "Are you sure you want to delete this plot? This action cannot be undone.",
      "warning",
      async () => {
        setLoading(true);
        try {
          const token = getAuthToken();
          if (!token) {
            showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
            return;
          }

          const response = await fetch(`${API_URL}/plot-delete`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({ id: plotId }),
          });

          if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || "Failed to delete plot.");
          }

          showCustomMessageModal("Success", "Plot deleted successfully!", "success");
          fetchPlots(currentPage, searchQuery);
        } catch (err) {
          console.error("Delete plot error:", err);
          setError(err.message);
          showCustomMessageModal("Error", err.message || "An unexpected error occurred while deleting plot.", "error");
        } finally {
          setLoading(false);
        }
      }
    );
  };

  const handleCloseViewModal = () => {
    setShowViewModal(false);
    setSelectedPlot(null);
  };

  const handleCloseEditModal = () => {
    setShowEditModal(false);
    setSelectedPlot(null);
    setEditFormData({
      plot_id: "",
      project_id: "",
      project_name: "",
      block_id: "",
      block_name: "",
      property_type: "",
      plot_shop_villa_no: "",
      plot_size: "",
      plot_sqyd: "",
      plot_rate: "",
      resgistry_patta: "",
      resgistry_date: "",
      plot_hold: "",
      plot_address: "",
      status: "",
    });
    setBlocksForEdit([]); 
  };

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: "80vh" }}>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="alert alert-danger text-center m-5" role="alert">
        {error}
        <button className="btn btn-primary ms-3" onClick={() => fetchPlots()}>
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="container mt-4 userlist">
      <h1 className="mb-4 text-center">All Plot List</h1>

      <div className="d-flex justify-content-between align-items-center mb-3">
        <Col md={4}>
          <Form.Group controlId="searchPlot">
            <Form.Control
              type="text"
              placeholder="Search by plot/shop/villa no."
              value={searchQuery}
              onChange={handleSearchChange}
            />
          </Form.Group>
        </Col>
        <Link to="/create-plot" className="btn btn-success d-flex align-items-center">
          <FaPlus className="me-2" /> Add New Plot
        </Link>
      </div>

      <div className="table-responsive">
        <Table striped bordered hover className="shadow-sm">
          <thead className="bg-primary text-white">
            <tr>
              <th>ID</th>
              <th>Project Name</th>
              <th>Block Name</th>
              <th>Property Type</th>
              <th>Plot/Shop/Villa No.</th>
              <th>Plot Size (sqft)</th>
              <th>Plot Rate</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {plots?.length > 0 ? (
              plots.map((plot) => (
                <tr key={plot.id}>
                  <td>{plot.id}</td>
                  <td>{plot.project_name}</td>
                  <td>{plot.block_name}</td>
                  <td>{plot.property_type}</td>
                  <td>{plot.plot_shop_villa_no}</td>
                  <td>{plot.plot_size}</td>
                  <td>{plot.plot_rate}</td>
                  <td>
                    <span
                      className={`badge ${
                        plot.status === "active" ? "bg-success" : "bg-danger"
                      }`}
                    >
                      {plot.status}
                    </span>
                  </td>
                  <td>
                    <Button
                      variant="info"
                      size="sm"
                      className="me-2"
                      onClick={() => handleViewPlot(plot.id)}
                    >
                      View
                    </Button>
                    <Button
                      variant="warning"
                      size="sm"
                      className="me-2"
                      onClick={() => handleEditPlot(plot.id)}
                    >
                      Edit
                    </Button>
                    <Button
                      variant={plot.status === "active" ? "danger" : "success"}
                      size="sm"
                      className="me-2"
                      onClick={() => handleStatusUpdate(plot.id, plot.status)}
                    >
                      {plot.status === "active" ? "Deactivate" : "Activate"}
                    </Button>
                    <Button
                      variant="danger"
                      size="sm"
                      onClick={() => handleDeletePlot(plot.id)}
                    >
                      Delete
                    </Button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="9" className="text-center">
                  No plots found.
                </td>
              </tr>
            )}
          </tbody>
        </Table>
      </div>

      <div className="d-flex justify-content-center mt-4">
        <Pagination>
          <Pagination.First onClick={() => handlePageChange(1)} disabled={currentPage === 1} />
          <Pagination.Prev
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
          />
          {[...Array(totalPages)].map((_, index) => (
            <Pagination.Item
              key={index + 1}
              active={index + 1 === currentPage}
              onClick={() => handlePageChange(index + 1)}
            >
              {index + 1}
            </Pagination.Item>
          ))}
          <Pagination.Next
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
          />
          <Pagination.Last
            onClick={() => handlePageChange(totalPages)}
            disabled={currentPage === totalPages}
          />
        </Pagination>
      </div>

      {/* View Plot Modal */}
      <Modal show={showViewModal} onHide={handleCloseViewModal} centered>
        <Modal.Header closeButton>
          <Modal.Title>Plot Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedPlot && (
            <div>
              <p><strong>ID:</strong> {selectedPlot.id}</p>
              <p><strong>Project Name:</strong> {selectedPlot.project_name}</p>
              <p><strong>Block Name:</strong> {selectedPlot.block_name}</p>
              <p><strong>Property Type:</strong> {selectedPlot.property_type}</p>
              <p><strong>Plot/Shop/Villa No.:</strong> {selectedPlot.plot_shop_villa_no}</p>
              <p><strong>Plot Size:</strong> {selectedPlot.plot_size} sqft</p>
              <p><strong>Plot Sq. Yd.:</strong> {selectedPlot.plot_sqyd}</p>
              <p><strong>Plot Rate:</strong> {selectedPlot.plot_rate}</p>
              <p><strong>Registry Patta:</strong> {selectedPlot.resgistry_patta}</p>
              {selectedPlot.resgistry_patta === "yes" && (
                <p><strong>Registry Date:</strong> {selectedPlot.resgistry_date}</p>
              )}
              <p><strong>Plot Hold:</strong> {selectedPlot.plot_hold}</p>
              <p><strong>Plot Address:</strong> {selectedPlot.plot_address}</p>
              <p>
                <strong>Status:</strong>{" "}
                <span
                  className={`badge ${
                    selectedPlot.status === "active" ? "bg-success" : "bg-danger"
                  }`}
                >
                  {selectedPlot.status}
                </span>
              </p>
            </div>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseViewModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Edit Plot Modal */}
      <Modal show={showEditModal} onHide={handleCloseEditModal} centered>
        <Modal.Header closeButton>
          <Modal.Title>Edit Plot</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleUpdatePlot}>
            <Form.Group className="mb-3" controlId="editProjectId">
              <Form.Label>Project Name</Form.Label>
              <Form.Select
                name="project_id"
                value={editFormData.project_id}
                onChange={handleEditFormChange}
                disabled={loadingDropdowns || projectsForEdit.length === 0}
                required
              >
                <option value="">Select a Project</option>
                {projectsForEdit.map((project) => (
                  <option key={project.id} value={project.id}>
                    {project.name}
                  </option>
                ))}
              </Form.Select>
              {loadingDropdowns && projectsForEdit.length === 0 && (
                <small className="text-muted">Loading projects...</small>
              )}
              {!loadingDropdowns && projectsForEdit.length === 0 && (
                <small className="text-danger">No projects available.</small>
              )}
            </Form.Group>

            <Form.Group className="mb-3" controlId="editBlockId">
              <Form.Label>Block Name</Form.Label>
              <Form.Select
                name="block_id"
                value={editFormData.block_id}
                onChange={handleEditFormChange}
                disabled={!editFormData.project_id || loadingDropdowns || blocksForEdit.length === 0}
                required
              >
                <option value="">Select a Block</option>
                {blocksForEdit.map((block) => (
                  <option key={block.id} value={block.id}>
                    {block.name}
                  </option>
                ))}
              </Form.Select>
              {editFormData.project_id && loadingDropdowns && blocksForEdit.length === 0 && (
                <small className="text-muted">Loading blocks...</small>
              )}
              {editFormData.project_id && !loadingDropdowns && blocksForEdit.length === 0 && (
                <small className="text-danger">No blocks available for this project.</small>
              )}
            </Form.Group>

          
            <Form.Group className="mb-3" controlId="displayProjectName">
              <Form.Label>Selected Project Name</Form.Label>
              <Form.Control
                type="text"
                name="project_name"
                value={editFormData.project_name}
                readOnly
                disabled
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="displayBlockName">
              <Form.Label>Selected Block Name</Form.Label>
              <Form.Control
                type="text"
                name="block_name"
                value={editFormData.block_name}
                readOnly
                disabled
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="editPropertyType">
              <Form.Label>Property Type</Form.Label>
              <Form.Select
                name="property_type"
                value={editFormData.property_type}
                onChange={handleEditFormChange}
                required
              >
                <option value="">Select Property Type</option>
                <option value="Resident">Resident</option>
                <option value="Commercial">Commercial</option>
                <option value="Corner Resident">Corner Resident</option>
                <option value="Corner Commercial">Corner Commercial</option>
              </Form.Select>
            </Form.Group>
            <Form.Group className="mb-3" controlId="editPlotShopVillaNo">
              <Form.Label>Plot/Shop/Villa No.</Form.Label>
              <Form.Control
                type="text"
                name="plot_shop_villa_no"
                value={editFormData.plot_shop_villa_no}
                onChange={handleEditFormChange}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="editPlotSize">
              <Form.Label>Plot Size (sqft)</Form.Label>
              <Form.Control
                type="number"
                name="plot_size"
                value={editFormData.plot_size}
                onChange={handleEditFormChange}
                required
                min="0"
                step="0.01"
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="editPlotSqYd">
              <Form.Label>Plot Sq. Yd.</Form.Label>
              <Form.Control
                type="number"
                name="plot_sqyd"
                value={editFormData.plot_sqyd}
                onChange={handleEditFormChange}
                required
                min="0"
                step="0.01"
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="editPlotRate">
              <Form.Label>Plot Rate</Form.Label>
              <Form.Control
                type="number"
                name="plot_rate"
                value={editFormData.plot_rate}
                onChange={handleEditFormChange}
                required
                min="0"
                step="0.01"
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="editResgistryPatta">
              <Form.Label>Registry Patta</Form.Label>
              <Form.Select
                name="resgistry_patta"
                value={editFormData.resgistry_patta}
                onChange={handleEditFormChange}
                required
              >
                <option value="">Select Option</option>
                <option value="yes">Yes</option>
                <option value="no">No</option>
              </Form.Select>
            </Form.Group>
            <Form.Group className="mb-3" controlId="editResgistryDate">
              <Form.Label>Registry Date</Form.Label>
              <Form.Control
                type="date"
                name="resgistry_date"
                value={editFormData.resgistry_date}
                onChange={handleEditFormChange}
                disabled={editFormData.resgistry_patta !== "yes"}
                required={editFormData.resgistry_patta === "yes"}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="editPlotHold">
              <Form.Label>Plot Hold</Form.Label>
              <Form.Select
                name="plot_hold"
                value={editFormData.plot_hold}
                onChange={handleEditFormChange}
                required
              >
                <option value="">Select Option</option>
                <option value="yes">Yes</option>
                <option value="no">No</option>
              </Form.Select>
            </Form.Group>
            <Form.Group className="mb-3" controlId="editPlotAddress">
              <Form.Label>Plot Address</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                name="plot_address"
                value={editFormData.plot_address}
                onChange={handleEditFormChange}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="editStatus">
              <Form.Label>Status</Form.Label>
              <Form.Select
                name="status"
                value={editFormData.status}
                onChange={handleEditFormChange}
                required
              >
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
              </Form.Select>
            </Form.Group>
            <Button variant="primary" type="submit" className="w-100" disabled={loading}>
              {loading ? "Updating..." : "Update Plot"}
            </Button>
          </Form>
        </Modal.Body>
      </Modal>

   
      {showMessageModal && (
        <div className="modal d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className={`modal-content border-top border-4 ${messageModalContent.type === 'success' ? 'border-success' : messageModalContent.type === 'error' ? 'border-danger' : 'border-warning'}`}>
              <div className="modal-header d-flex justify-content-between align-items-center">
                <h5 className={`modal-title ${messageModalContent.type === 'success' ? 'text-success' : messageModalContent.type === 'error' ? 'text-danger' : 'text-warning'}`}>
                  {messageModalContent.title}
                </h5>
                <button type="button" className="btn-close" aria-label="Close" onClick={closeCustomMessageModal}></button>
              </div>
              <div className="modal-body text-secondary">
                <p>{messageModalContent.text}</p>
              </div>
              <div className="modal-footer justify-content-center">
                {messageModalContent.confirmAction ? (
                  <>
                    <Button
                      variant="secondary"
                      onClick={closeCustomMessageModal}
                    >
                      Cancel
                    </Button>
                    <Button
                      variant={messageModalContent.type === 'warning' ? 'warning' : 'primary'}
                      onClick={() => {
                        messageModalContent.confirmAction();
                        closeCustomMessageModal();
                      }}
                    >
                      Confirm
                    </Button>
                  </>
                ) : (
                  <Button
                    variant={messageModalContent.type === 'success' ? 'success' : messageModalContent.type === 'error' ? 'danger' : 'primary'}
                    onClick={closeCustomMessageModal}
                  >
                    OK
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default AllPlotList;
