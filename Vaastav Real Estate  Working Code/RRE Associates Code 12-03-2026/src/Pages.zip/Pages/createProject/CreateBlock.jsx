import React, { useState, useEffect, useRef } from "react";
import { Form, Button, Container, Row, Col, Card, Modal } from "react-bootstrap";
import Swal from "sweetalert2"; 

const API_URL = process.env.REACT_APP_API_URL;

function CreateBlock() {
 
  const [formData, setFormData] = useState({
    projectId: "", 
    projectName: "", 
    blockName: "",
    status: "active", 
    image: null, 
  });

  
  const [errors, setErrors] = useState({});
 
  const [loading, setLoading] = useState(false);
  
  const [projects, setProjects] = useState([]);

  
  const imageInputRef = useRef(null);

  
  const [showMessageModal, setShowMessageModal] = useState(false);
  const [messageModalContent, setMessageModalContent] = useState({
    title: "",
    text: "",
    type: "",
    confirmAction: null,
  });

 
  const showCustomMessageModal = (title, text, type, confirmAction = null) => {
    setMessageModalContent({ title, text, type, confirmAction });
    setShowMessageModal(true);
  };

  const closeCustomMessageModal = () => {
    setShowMessageModal(false);
    setMessageModalContent({ title: "", text: "", type: "", confirmAction: null });
  };


  const getAuthToken = () => {
    return localStorage.getItem("token"); 
  };

  
  useEffect(() => {
    const fetchProjectsList = async () => {
      setLoading(true);
      try {
        const token = getAuthToken();
        if (!token) {
          showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
          return;
        }

        const response = await fetch(`${API_URL}/project-list-block`, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        });

        if (!response.ok) {
          const errorData = await response.json();
          showCustomMessageModal("Error", errorData.message || "Failed to fetch projects.", "error");
          return;
        }

        const data = await response.json();
        setProjects(data.data || []); 
      } catch (err) {
        console.error("Fetch projects error:", err);
        showCustomMessageModal("Error", err.message || "An unexpected error occurred while fetching projects.", "error");
      } finally {
        setLoading(false);
      }
    };

    fetchProjectsList();
  }, []); 

 
  const handleChange = (e) => {
    const { name, value, files } = e.target;

    if (name === "image") {
      setFormData((prevData) => ({
        ...prevData,
        image: files[0], 
      }));
    } else if (name === "projectId") {
      
      const selectedProject = projects.find(proj => proj.id.toString() === value);
      setFormData((prevData) => ({
        ...prevData,
        projectId: value,
        projectName: selectedProject ? selectedProject.name : "", 
      }));
    } else {
      setFormData((prevData) => ({
        ...prevData,
        [name]: value,
      }));
    }
    
    if (errors[name]) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        [name]: null,
      }));
    }
  };

 
  const validateForm = () => {
    let newErrors = {};
    let isValid = true;

    
    if (!formData.projectId) {
      newErrors.projectId = "Project is required.";
      isValid = false;
    }

   
    if (!formData.name.trim()) {
      newErrors.name = "Block Name is required.";
      isValid = false;
    }

    
    if (!formData.image) {
      newErrors.image = "Block image is required.";
      isValid = false;
    }

    
    if (!formData.status) {
      newErrors.status = "Status is required.";
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  
  const handleSubmit = async (e) => {
    e.preventDefault(); 

   
    if (!validateForm()) {
      showCustomMessageModal("Validation Error", "Please correct the errors in the form.", "error");
      return; 
    }

    setLoading(true);

    try {
      const token = getAuthToken();
      if (!token) {
        showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
        return;
      }

      
      const formDataToSend = new FormData();
      formDataToSend.append("project_id", formData.projectId);
      formDataToSend.append("project_name", formData.projectName); 
      formDataToSend.append("name", formData.name);
      formDataToSend.append("status", formData.status);
      if (formData.image) {
        formDataToSend.append("image", formData.image);
      }

      const response = await fetch(`${API_URL}/block-create`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
         
        },
        body: formDataToSend, 
      });

      if (!response.ok) {
        const errorData = await response.json();
        showCustomMessageModal("Error", errorData.message || "Failed to create block.", "error");
        return;
      }

      
      const result = await response.json();
      showCustomMessageModal("Success", result.message || "Block created successfully!", "success");

      
      setFormData({
        projectId: "",
        projectName: "",
        name: "",
        status: "active",
        image: null,
      });
      setErrors({}); 
      if (imageInputRef.current) {
        imageInputRef.current.value = ""; 
      }

    } catch (err) {
      console.error("Error creating block:", err);
      showCustomMessageModal("Error", err.message || "An unexpected error occurred.", "error");
    } finally {
      setLoading(false); 
    }
  };

  return (
    <Container className="mt-5">
      <Row className="justify-content-center">
        <Col md={8} lg={6}>
          <Card className="shadow-lg rounded-3">
            <Card.Header className="bg-primary text-white text-center py-3 rounded-top-3">
              <h2 className="mb-0">Create New Block</h2>
            </Card.Header>
            <Card.Body className="p-4">
              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-3" controlId="formProjectId">
                  <Form.Label>Select Project <span className="text-danger">*</span></Form.Label>
                  <Form.Select
                    name="projectId"
                    value={formData.projectId}
                    onChange={handleChange}
                    isInvalid={!!errors.projectId}
                    disabled={loading || projects.length === 0}
                  >
                    <option value="">Select a Project</option>
                    {projects.map((project) => (
                      <option key={project.id} value={project.id}>
                        {project.name}
                      </option>
                    ))}
                  </Form.Select>
                  <Form.Control.Feedback type="invalid">
                    {errors.projectId}
                  </Form.Control.Feedback>
                  {loading && projects.length === 0 && (
                    <small className="text-muted">Loading projects...</small>
                  )}
                  {!loading && projects.length === 0 && (
                    <small className="text-danger">No projects available. Please create one first.</small>
                  )}
                </Form.Group>

               
                <Form.Group className="mb-3" controlId="formBlockName">
                  <Form.Label>Block Name <span className="text-danger">*</span></Form.Label>
                  <Form.Control
                    type="text"
                    name="name"
                    placeholder="Enter block name"
                    value={formData.name}
                    onChange={handleChange}
                    isInvalid={!!errors.name}
                    required
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.name}
                  </Form.Control.Feedback>
                </Form.Group>

               
                <Form.Group className="mb-3" controlId="formStatus">
                  <Form.Label>Status <span className="text-danger">*</span></Form.Label>
                  <Form.Select
                    name="status"
                    value={formData.status}
                    onChange={handleChange}
                    isInvalid={!!errors.status}
                    required
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </Form.Select>
                  <Form.Control.Feedback type="invalid">
                    {errors.status}
                  </Form.Control.Feedback>
                </Form.Group>

               
                <Form.Group className="mb-4" controlId="formImage">
                  <Form.Label>Block Image <span className="text-danger">*</span></Form.Label>
                  <Form.Control
                    type="file"
                    name="image"
                    accept="image/*" 
                    onChange={handleChange}
                    isInvalid={!!errors.image} 
                    ref={imageInputRef} 
                    required
                  />
                  <Form.Control.Feedback type="invalid">
                    {errors.image}
                  </Form.Control.Feedback>
                </Form.Group>

              
                <Button
                  variant="primary"
                  type="submit"
                  className="w-100 py-2"
                  disabled={loading} 
                >
                  {loading ? "Creating..." : "Create Block"}
                </Button>
              </Form>
            </Card.Body>
          </Card>
        </Col>
      </Row>

     
      {showMessageModal && (
        <div className="modal d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className={`modal-content border-top border-4 ${messageModalContent.type === 'success' ? 'border-success' : messageModalContent.type === 'error' ? 'border-danger' : 'border-warning'}`}>
              <div className="modal-header d-flex justify-content-between align-items-center">
                <h5 className={`modal-title ${messageModalContent.type === 'success' ? 'text-success' : messageModalContent.type === 'error' ? 'text-danger' : 'text-warning'}`}>
                  {messageModalContent.title}
                </h5>
                <button type="button" className="btn-close" aria-label="Close" onClick={closeCustomMessageModal}></button>
              </div>
              <div className="modal-body text-secondary">
                <p>{messageModalContent.text}</p>
              </div>
              <div className="modal-footer justify-content-center">
                {messageModalContent.confirmAction ? (
                  <>
                    <Button
                      variant="secondary"
                      onClick={closeCustomMessageModal}
                    >
                      Cancel
                    </Button>
                    <Button
                      variant={messageModalContent.type === 'warning' ? 'warning' : 'primary'}
                      onClick={() => {
                        messageModalContent.confirmAction();
                        closeCustomMessageModal();
                      }}
                    >
                      Confirm
                    </Button>
                  </>
                ) : (
                  <Button
                    variant={messageModalContent.type === 'success' ? 'success' : messageModalContent.type === 'error' ? 'danger' : 'primary'}
                    onClick={closeCustomMessageModal}
                  >
                    OK
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </Container>
  );
}

export default CreateBlock;
