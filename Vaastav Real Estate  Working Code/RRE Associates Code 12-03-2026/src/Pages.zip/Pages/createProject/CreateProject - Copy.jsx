import React, { useState, useEffect } from "react";
import { Form, Button, Container, Row, Col, Card, Modal } from "react-bootstrap";
import { CKEditor } from '@ckeditor/ckeditor5-react';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
const API_URL = process.env.REACT_APP_API_URL;
function CreateProject() {
  const [name, setName] = useState("");
  const [residentCommission, setResidentCommission] = useState("");
  const [commercialCommission, setCommercialCommission] = useState("");
  const [cornerResidentCommission, setCornerResidentCommission] = useState("");
  const [cornerCommercialCommission, setCornerCommercialCommission] = useState("");
  const [projectSize, setProjectSize] = useState("");
  const [status, setStatus] = useState("active");
  const [image, setImage] = useState(null);
  const [reraRegistrationNo, setReraRegistrationNo] = useState("");
  const [location, setLocation] = useState("");
  const [projectType, setProjectType] = useState("");
  const [description, setDescription] = useState(""); 
  const [legality, setLegality] = useState("");

  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [modalMessage, setModalMessage] = useState("");
  const [modalType, setModalType] = useState("success");

  
  const showCustomModal = (message, type) => {
    setModalMessage(message);
    setModalType(type);
    setShowModal(true);
  };

  const closeCustomModal = () => {
    setShowModal(false);
    setModalMessage("");
    setModalType("success");
  };

  const validateForm = () => {
    const newErrors = {};
    if (!name.trim()) newErrors.name = "Project name is required.";
    if (!residentCommission || isNaN(residentCommission) || parseFloat(residentCommission) <= 0) {
      newErrors.residentCommission = "Resident commission must be a positive number.";
    }
    if (!commercialCommission || isNaN(commercialCommission) || parseFloat(commercialCommission) <= 0) {
      newErrors.commercialCommission = "Commercial commission must be a positive number.";
    }

    if (!cornerResidentCommission || isNaN(cornerResidentCommission) || parseFloat(cornerResidentCommission) <= 0) {
      newErrors.cornerResidentCommission = "Corner resident commission must be a positive number.";
    }
    if (!cornerCommercialCommission || isNaN(cornerCommercialCommission) || parseFloat(cornerCommercialCommission) <= 0) {
      newErrors.cornerCommercialCommission = "Corner commercial commission must be a positive number.";
    }
    if (!projectSize || isNaN(projectSize) || parseFloat(projectSize) <= 0) {
      newErrors.projectSize = "Project size must be a positive number.";
    }
    if (!image) newErrors.image = "Project image is required.";

   
    if (!reraRegistrationNo.trim()) newErrors.reraRegistrationNo = "RERA Registration No. is required.";
    if (!location.trim()) newErrors.location = "Location is required.";
    if (!projectType.trim()) newErrors.projectType = "Project Type is required.";
    if (!description.trim()) newErrors.description = "Description is required.";
    if (!legality.trim()) newErrors.legality = "Legality details are required.";


    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrors({}); 

    if (!validateForm()) {
      showCustomModal("Please correct the errors in the form.", "error");
      return;
    }

    setIsLoading(true);

    const formData = new FormData();
    formData.append("name", name);
    formData.append("resident_commission", residentCommission);
    formData.append("commercial_commission", commercialCommission);
    formData.append("corner_resident_commission", cornerResidentCommission);
    formData.append("corner_commercial_commission", cornerCommercialCommission);
    formData.append("project_size", projectSize);
    formData.append("status", status);
    if (image) {
      formData.append("image", image);
    }
   
    formData.append("rera_registration_no", reraRegistrationNo);
    formData.append("location", location);
    formData.append("project_type", projectType);
    formData.append("description", description);
    formData.append("legality", legality);


    const authToken = localStorage.getItem("token");

    if (!authToken) {
      showCustomModal("Authentication token not found. Please log in.", "error");
      setIsLoading(false);
      return;
    }

    try {
      const response = await fetch(`${API_URL}/project-create`, { 
        method: "POST",
        headers: {
          Authorization: `Bearer ${authToken}`,
         
        },
        body: formData,
      });

      if (response.ok) {
        const result = await response.json();
        showCustomModal(result.message || "Project created successfully!", "success");
       
        setName("");
        setResidentCommission("");
        setCommercialCommission("");
        setCornerResidentCommission("");
        setCornerCommercialCommission("");
        setProjectSize("");
        setStatus("active");
        setImage(null);
        setReraRegistrationNo("");
        setLocation("");
        setProjectType("");
        setDescription("");
        setLegality("");
        document.getElementById("image-upload").value = ""; 
      } else {
        const errorData = await response.json();
        const errorMessage = errorData.message || "Failed to create project.";
        showCustomModal(`Error: ${errorMessage}`, "error");
      }
    } catch (error) {
      showCustomModal(`An unexpected error occurred: ${error.message}`, "error");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Container className="mt-5">
      <Row className="justify-content-center">
        <Col md={10} lg={8}>
          <Card className="shadow-lg rounded-3">
            <Card.Header className="bg-primary text-white text-center py-3 rounded-top-3">
              <h2 className="mb-0">Create New Project</h2>
            </Card.Header>
            <Card.Body className="p-4">
              <Form onSubmit={handleSubmit}>
                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="name">
                      <Form.Label>Project Name <span className="text-danger">*</span></Form.Label>
                      <Form.Control
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g., Grand Residency"
                        isInvalid={!!errors.name}
                      />
                      <Form.Control.Feedback type="invalid">{errors.name}</Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="resident_commission">
                      <Form.Label>Resident Commission (%) <span className="text-danger">*</span></Form.Label>
                      <Form.Control
                        type="number"
                        value={residentCommission}
                        onChange={(e) => setResidentCommission(e.target.value)}
                        placeholder="e.g., 20"
                        step="0.01"
                        min="0"
                        isInvalid={!!errors.residentCommission}
                      />
                      <Form.Control.Feedback type="invalid">{errors.residentCommission}</Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>

                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="commercial_commission">
                      <Form.Label>Commercial Commission (%) <span className="text-danger">*</span></Form.Label>
                      <Form.Control
                        type="number"
                        value={commercialCommission}
                        onChange={(e) => setCommercialCommission(e.target.value)}
                        placeholder="e.g., 10"
                        step="0.01"
                        min="0"
                        isInvalid={!!errors.commercialCommission}
                      />
                      <Form.Control.Feedback type="invalid">{errors.commercialCommission}</Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="corner_resident_commission">
                      <Form.Label>Corner Resident Commission (%) <span className="text-danger">*</span></Form.Label>
                      <Form.Control
                        type="number"
                        value={cornerResidentCommission}
                        onChange={(e) => setCornerResidentCommission(e.target.value)}
                        placeholder="e.g., 25"
                        step="0.01"
                        min="0"
                        isInvalid={!!errors.cornerResidentCommission}
                      />
                      <Form.Control.Feedback type="invalid">{errors.cornerResidentCommission}</Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>

                <Row>
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="corner_commercial_commission">
                      <Form.Label>Corner Commercial Commission (%) <span className="text-danger">*</span></Form.Label>
                      <Form.Control
                        type="number"
                        value={cornerCommercialCommission}
                        onChange={(e) => setCornerCommercialCommission(e.target.value)}
                        placeholder="e.g., 15"
                        step="0.01"
                        min="0"
                        isInvalid={!!errors.cornerCommercialCommission}
                      />
                      <Form.Control.Feedback type="invalid">{errors.cornerCommercialCommission}</Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="project_size">
                      <Form.Label>Project Size (sq ft) <span className="text-danger">*</span></Form.Label>
                      <Form.Control
                        type="number"
                        value={projectSize}
                        onChange={(e) => setProjectSize(e.target.value)}
                        placeholder="e.g., 10000"
                        step="1"
                        min="0"
                        isInvalid={!!errors.projectSize}
                      />
                      <Form.Control.Feedback type="invalid">{errors.projectSize}</Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>

                <Row>
                 
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="rera_registration_no">
                      <Form.Label>RERA Registration No. <span className="text-danger">*</span></Form.Label>
                      <Form.Control
                        type="text"
                        value={reraRegistrationNo}
                        onChange={(e) => setReraRegistrationNo(e.target.value)}
                        placeholder="Enter RERA registration number"
                        isInvalid={!!errors.reraRegistrationNo}
                      />
                      <Form.Control.Feedback type="invalid">{errors.reraRegistrationNo}</Form.Control.Feedback>
                    </Form.Group>
                  </Col>

                 
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="location">
                      <Form.Label>Location <span className="text-danger">*</span></Form.Label>
                      <Form.Control
                        type="text"
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        placeholder="Enter project location"
                        isInvalid={!!errors.location}
                      />
                      <Form.Control.Feedback type="invalid">{errors.location}</Form.Control.Feedback>
                    </Form.Group>
                  </Col>
                </Row>

                <Row>
                 
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="project_type">
                      <Form.Label>Project Type <span className="text-danger">*</span></Form.Label>
                      <Form.Control
                        type="text"
                        value={projectType}
                        onChange={(e) => setProjectType(e.target.value)}
                        placeholder="e.g., Residential, Commercial"
                        isInvalid={!!errors.projectType}
                      />
                      <Form.Control.Feedback type="invalid">{errors.projectType}</Form.Control.Feedback>
                    </Form.Group>
                  </Col>

                  
                  <Col md={6}>
                    <Form.Group className="mb-3" controlId="status">
                      <Form.Label>Status <span className="text-danger">*</span></Form.Label>
                      <Form.Select
                        value={status}
                        onChange={(e) => setStatus(e.target.value)}
                      >
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                      </Form.Select>
                    </Form.Group>
                  </Col>
                </Row>

               
                <Form.Group className="mb-3" controlId="description">
                  <Form.Label>Description <span className="text-danger">*</span></Form.Label>
                  <CKEditor
                    editor={ClassicEditor} 
                    data={description}
                    onChange={(event, editor) => {
                      const data = editor.getData();
                      setDescription(data);
                      if (errors.description) {
                        setErrors(prev => ({ ...prev, description: null }));
                      }
                    }}
                    config={{
                      toolbar: [
                        'heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', 'blockQuote', '|',
                        'undo', 'redo'
                      ],
                      licenseKey: 'eyJhbGciOiJFUzI1NiJ9.eyJleHAiOjE3NTQ0MzgzOTksImp0aSI6Ijk4MGNlZTU4LTA0ZTUtNDVkMi1iZmI4LWZmZTNjNjMwNjA4MCIsInVzYWdlRW5kcG9pbnQiOiJodHRwczovL3Byb3h5LWV2ZW50LmNrZWRpdG9yLmNvbSIsImRpc3RyaWJ1dGlvbkNoYW5uZWwiOlsiY2xvdWQiLCJkcnVwYWwiLCJzaCJdLCJ3aGl0ZUxhYmVsIjp0cnVlLCJsaWNlbnNlVHlwZSI6InRyaWFsIiwiZmVhdHVyZXMiOlsiKiJdLCJ2YyI6IjVmZjc5NDUxIn0.0ckOvFDI8r8h1g0YVW4Vlx4PmiF2bYkIaAqdSYuM_8RC8Wl3cO4jIfkMAd57z6Fo_6JPmlmDfLjafu4EnnByzQ',
                    }}
                  />
                  {errors.description && <div className="text-danger mt-1" style={{ fontSize: '0.875em' }}>{errors.description}</div>}
                </Form.Group>

               
                <Form.Group className="mb-3" controlId="legality">
                  <Form.Label>Legality <span className="text-danger">*</span></Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={3}
                    value={legality}
                    onChange={(e) => setLegality(e.target.value)}
                    placeholder="Enter legality details"
                    isInvalid={!!errors.legality}
                  />
                  <Form.Control.Feedback type="invalid">{errors.legality}</Form.Control.Feedback>
                </Form.Group>

                <Form.Group className="mb-3" controlId="image-upload">
                  <Form.Label>Project Image <span className="text-danger">*</span></Form.Label>
                  <Form.Control
                    type="file"
                    accept="image/*"
                    onChange={(e) => setImage(e.target.files[0])}
                    isInvalid={!!errors.image}
                  />
                  <Form.Control.Feedback type="invalid">{errors.image}</Form.Control.Feedback>
                </Form.Group>

                <Button
                  type="submit"
                  variant="primary"
                  className="w-100 py-2 mt-4 d-flex justify-content-center align-items-center"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                      Loading...
                    </>
                  ) : (
                    <div className="fs-5">Create Project</div>
                  )}
                </Button>
              </Form>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      
      <Modal show={showModal} onHide={closeCustomModal} centered>
        <Modal.Header closeButton>
          <Modal.Title className={modalType === 'success' ? 'text-success' : 'text-danger'}>
            {modalType === 'success' ? 'Success!' : 'Error!'}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>{modalMessage}</p>
        </Modal.Body>
        <Modal.Footer className="justify-content-center">
          <Button
            variant={modalType === 'success' ? 'success' : 'danger'}
            onClick={closeCustomModal}
          >
            OK
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
}

export default CreateProject;
