import React, { useEffect, useState, useRef } from "react";
import { Link } from "react-router-dom";
import { FaPlus } from "react-icons/fa";
import { Modal, Button, Form, Table, Pagination, Row, Col } from "react-bootstrap";

import { CKEditor } from '@ckeditor/ckeditor5-react';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';

const API_URL = process.env.REACT_APP_API_URL;

function AllProjectList() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [searchName, setSearchName] = useState("");
  const [showViewModal, setShowViewModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);
  const [selectedimagePath, setSelectedimagePath] = useState(null);
  const [editFormData, setEditFormData] = useState({
    name: "",
    resident_commission: "",
    commercial_commission: "",
    corner_resident_commission: "",
    corner_commercial_commission: "",
    project_size: "",
    status: "",
    project_id: "",
    newImages: [],
    displayCurrentImage: null,
    rera_registration_no: "",
    location: "",
    project_type: "",
    description: "",
    legality: "",
  });
  const newImageInputRef = useRef(null);

  const [showMessageModal, setShowMessageModal] = useState(false);
  const [messageModalContent, setMessageModalContent] = useState({
    title: "",
    text: "",
    type: "",
    confirmAction: null,
  });

  const showCustomMessageModal = (title, text, type, confirmAction = null) => {
    setMessageModalContent({ title, text, type, confirmAction });
    setShowMessageModal(true);
  };

  const closeCustomMessageModal = () => {
    setShowMessageModal(false);
    setMessageModalContent({ title: "", text: "", type: "", confirmAction: null });
  };

  const getAuthToken = () => {
    return localStorage.getItem("token");
  };

  const fetchProjects = async (page = 1, name = "") => {
    setLoading(true);
    setError(null);
    try {
      const token = getAuthToken();
      if (!token) {
        showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
        throw new Error("Authentication token not found. Please log in.");
      }

      const response = await fetch(
        `${API_URL}/project-list?page=${page}&limit=10&name=${name}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (!response.ok) {
        if (response.status === 401) {
          showCustomMessageModal("Authorization Error", "Unauthorized: Please log in again.", "error");
          throw new Error("Unauthorized: Please log in again.");
        }
        const errorData = await response.json();
        showCustomMessageModal("Error", errorData.message || "Failed to fetch projects.", "error");
        throw new Error(errorData.message || "Failed to fetch projects.");
      }

      const data = await response.json();
      setProjects(data.data || []);
      setSelectedimagePath(data.imagePath);
      setTotalPages(data.data.totalPages || 1);
      setCurrentPage(page);
    } catch (err) {
      console.error("Fetch projects error:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProjects(currentPage, searchName);
  }, [currentPage, searchName]);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const handleSearchChange = (e) => {
    setSearchName(e.target.value);
    setCurrentPage(1);
  };

  const handleViewProject = async (projectId) => {
    setLoading(true);
    setError(null);
    try {
      const token = getAuthToken();
      if (!token) {
        showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
        throw new Error("Authentication token not found. Please log in.");
      }

      const response = await fetch(`${API_URL}/project-view`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ id: projectId }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        showCustomMessageModal("Error", errorData.message || "Failed to fetch project details.", "error");
        throw new Error(errorData.message || "Failed to fetch project details.");
      }

      const data = await response.json();
      setSelectedProject(data.data);
      setShowViewModal(true);
    } catch (err) {
      console.error("View project error:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleEditProject = async (projectId) => {
    setLoading(true);
    setError(null);
    try {
      const token = getAuthToken();
      if (!token) {
        showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
        throw new Error("Authentication token not found. Please log in.");
      }

      const response = await fetch(`${API_URL}/project-edit`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ id: projectId }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        showCustomMessageModal("Error", errorData.message || "Failed to fetch project for editing.", "error");
        throw new Error(errorData.message || "Failed to fetch project for editing.");
      }

      const data = await response.json();
      const projectData = data.data;
      setSelectedProject(projectData);
      const imagesArray = projectData.images ? JSON.parse(projectData.images) : [];
      setEditFormData({
        name: projectData.name || "",
        resident_commission: projectData.resident_commission || "",
        commercial_commission: projectData.commercial_commission || "",
        corner_resident_commission: projectData.corner_resident_commission || "",
        corner_commercial_commission: projectData.corner_commercial_commission || "",
        project_size: projectData.project_size || "",
        status: projectData.status || "inactive",
        project_id: projectData.id || "",
        newImages: [],
        images: imagesArray,
        displayCurrentImage: imagesArray.length > 0 ? imagesArray[0] : null,
        rera_registration_no: projectData.rera_registration_no || "",
        location: projectData.location || "",
        project_type: projectData.project_type || "",
        description: projectData.description || "",
        legality: projectData.legality || "",
        imagePath: data.imagePath || ""
      });
      setShowEditModal(true);
    } catch (err) {
      console.error("Edit project error:", err);
    } finally {
      setLoading(false);
    }
  };


  const handleEditFormChange = (e) => {
    const { name, value } = e.target;
    setEditFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };


  const handleNewImageChange = (e) => {
    const files = Array.from(e.target.files);
    setEditFormData((prevData) => ({
      ...prevData,
      newImages: files,
    }));
  };


  const removeNewImage = (indexToRemove) => {
    setEditFormData(prevData => {
      const updatedNewImages = prevData.newImages.filter((_, index) => index !== indexToRemove);

      if (newImageInputRef.current && updatedNewImages.length === 0) {
        newImageInputRef.current.value = "";
      }
      return { ...prevData, newImages: updatedNewImages };
    });
  };


  const handleDeleteCurrentImage = async (projectId) => {

    alert(projectId);

    showCustomMessageModal(
      "Confirm Image Deletion",
      "Are you sure you want to delete the current project image? This action cannot be undone.",
      "warning",
      async () => {
        setLoading(true);
        try {
          const token = getAuthToken();
          if (!token) {
            showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
            throw new Error("Authentication token not found. Please log in.");
          }

          const response = await fetch(`${API_URL}/project-image-delete`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({ id: projectId }),
          });

          if (!response.ok) {
            const errorData = await response.json();
            showCustomMessageModal("Error", errorData.message || "Failed to delete image.", "error");
            throw new Error(errorData.message || "Failed to delete image.");
          }

          showCustomMessageModal("Success", "Project image deleted successfully!", "success");
          setEditFormData(prevData => ({ ...prevData, displayCurrentImage: null }));
          fetchProjects(currentPage, searchName);
        } catch (err) {
          console.error("Delete image error:", err);
        } finally {
          setLoading(false);
        }
      }
    );
  };



  const handleDescriptionChange = (event, editor) => {
    const data = editor.getData();
    setEditFormData((prevData) => ({
      ...prevData,
      description: data,
    }));
  };

  const handleUpdateProject = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const token = getAuthToken();
      if (!token) {
        showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
        throw new Error("Authentication token not found. Please log in.");
      }

      const formData = new FormData();
      formData.append("name", editFormData.name);
      formData.append("resident_commission", editFormData.resident_commission);
      formData.append("commercial_commission", editFormData.commercial_commission);
      formData.append("corner_resident_commission", editFormData.corner_resident_commission);
      formData.append("corner_commercial_commission", editFormData.corner_commercial_commission);
      formData.append("project_size", editFormData.project_size);
      formData.append("status", editFormData.status);
      formData.append("project_id", editFormData.project_id);

      editFormData.newImages.forEach((imageFile) => {
        formData.append("image", imageFile);
      });

      formData.append("rera_registration_no", editFormData.rera_registration_no);
      formData.append("location", editFormData.location);
      formData.append("project_type", editFormData.project_type);
      formData.append("description", editFormData.description);
      formData.append("legality", editFormData.legality);

      const response = await fetch(`${API_URL}/project-update`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        showCustomMessageModal("Error", errorData.message || "Failed to update project.", "error");
        throw new Error(errorData.message || "Failed to update project.");
      }

      showCustomMessageModal("Success", "Project updated successfully!", "success");
      setShowEditModal(false);
      fetchProjects(currentPage, searchName);
    }
    catch (err) {
      console.error("Update project error:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusUpdate = async (projectId, currentStatus) => {
    const newStatus = currentStatus === "active" ? "inactive" : "active";
    showCustomMessageModal(
      "Confirm Status Change",
      `Do you want to change the status to ${newStatus}?`,
      "warning",
      async () => {
        setLoading(true);
        setError(null);
        try {
          const token = getAuthToken();
          if (!token) {
            showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
            throw new Error("Authentication token not found. Please log in.");
          }

          const response = await fetch(`${API_URL}/project-status-update`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({
              status: newStatus,
              project_id: projectId,
            }),
          });

          if (!response.ok) {
            const errorData = await response.json();
            showCustomMessageModal("Error", errorData.message || "Failed to update project status.", "error");
            throw new Error(errorData.message || "Failed to update project status.");
          }

          showCustomMessageModal("Success", "Project status updated successfully!", "success");
          fetchProjects(currentPage, searchName);
        } catch (err) {
          console.error("Status update error:", err);
        } finally {
          setLoading(false);
        }
      }
    );
  };

  const handleDeleteProject = async (projectId) => {
    showCustomMessageModal(
      "Confirm Deletion",
      "Are you sure you want to delete this project? This action cannot be undone.",
      "warning",
      async () => {
        setLoading(true);
        setError(null);
        try {
          const token = getAuthToken();
          if (!token) {
            showCustomMessageModal("Authentication Error", "Authentication token not found. Please log in.", "error");
            throw new Error("Authentication token not found. Please log in.");
          }

          const response = await fetch(`${API_URL}/project-delete`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
            body: JSON.stringify({ id: projectId }),
          });

          if (!response.ok) {
            const errorData = await response.json();
            showCustomMessageModal("Error", errorData.message || "Failed to delete project.", "error");
            throw new Error(errorData.message || "Failed to delete project.");
          }

          showCustomMessageModal("Success", "Project deleted successfully!", "success");
          fetchProjects(currentPage, searchName);
        } catch (err) {
          console.error("Delete project error:", err);
        } finally {
          setLoading(false);
        }
      }
    );
  };

  const handleCloseViewModal = () => {
    setShowViewModal(false);
    setSelectedProject(null);
  };

  const handleCloseEditModal = () => {
    setShowEditModal(false);
    setSelectedProject(null);
    setEditFormData({
      name: "",
      resident_commission: "",
      commercial_commission: "",
      corner_resident_commission: "",
      corner_commercial_commission: "",
      project_size: "",
      status: "",
      project_id: "",
      newImages: [],
      displayCurrentImage: null,
      rera_registration_no: "",
      location: "",
      project_type: "",
      description: "",
      legality: "",
    });
    if (newImageInputRef.current) {
      newImageInputRef.current.value = "";
    }
  };

  if (loading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: "80vh" }}>
        <div className="spinner-border text-primary" role="status">
          <span className="sr-only">Loading...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4 userlist">
      <h1 className="mb-4 text-center">All Project List</h1>

      <div className="d-flex justify-content-between align-items-center mb-3">
        <div className="col-md-4">
          <Form.Group controlId="searchName">
            <Form.Control
              type="text"
              placeholder="Search by project name..."
              value={searchName}
              onChange={handleSearchChange}
            />
          </Form.Group>
        </div>
        <Link to="/create-project" className="btn btn-success d-flex align-items-center">
          <FaPlus className="me-2" /> Add New Project
        </Link>
      </div>

      <div className="table-responsive">
        <Table striped bordered hover className="shadow-sm">
          <thead className="bg-primary text-white">
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Resident Commission</th>
              <th>Commercial Commission</th>
              <th>Corner Resident Commission</th>
              <th>Corner Commercial Commission</th>
              <th>Project Size</th>
              <th>Image</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {projects?.length > 0 ? (
              projects.map((project) => {
                const imageUrls = JSON.parse(project.images || "[]");
                return (
                  <tr key={project.id}>
                    <td>{project.id}</td>
                    <td>{project.name}</td>
                    <td>{project.resident_commission}%</td>
                    <td>{project.commercial_commission}%</td>
                    <td>{project.corner_resident_commission}%</td>
                    <td>{project.corner_commercial_commission}%</td>
                    <td>{project.project_size} sqft</td>
                    <td>
                      <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
                        {imageUrls.length > 0 ? (
                          imageUrls.map((image, index) => (
                            <img
                              key={index}
                              src={`${selectedimagePath}${image}`}
                              alt={`Project ${project.id} image ${index + 1}`}
                              style={{
                                width: '50px',
                                height: '50px',
                                objectFit: 'cover',
                                borderRadius: '4px'
                              }}
                            />
                          ))
                        ) : (
                          <span>No images</span>
                        )}
                      </div>
                    </td>
                    <td>
                      <span
                        className={`badge ${project.status === "active" ? "bg-success" : "bg-danger"
                          }`}
                      >
                        {project.status}
                      </span>
                    </td>
                    <td>
                      <Button
                        variant="info"
                        size="sm"
                        className="me-2"
                        onClick={() => handleViewProject(project.id)}
                      >
                        View
                      </Button>
                      <Button
                        variant="warning"
                        size="sm"
                        className="me-2"
                        onClick={() => handleEditProject(project.id)}
                      >
                        Edit
                      </Button>
                      <Button
                        variant={project.status === "active" ? "danger" : "success"}
                        size="sm"
                        className="me-2"
                        onClick={() => handleStatusUpdate(project.id, project.status)}
                      >
                        {project.status === "active" ? "Deactivate" : "Activate"}
                      </Button>
                      <Button
                        variant="danger"
                        size="sm"
                        onClick={() => handleDeleteProject(project.id)}
                      >
                        Delete
                      </Button>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan="11" className="text-center">
                  No projects found.
                </td>
              </tr>
            )}
          </tbody>
        </Table>
      </div>

      <div className="d-flex justify-content-center mt-4">
        <Pagination>
          <Pagination.First onClick={() => handlePageChange(1)} disabled={currentPage === 1} />
          <Pagination.Prev
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
          />
          {[...Array(totalPages)].map((_, index) => (
            <Pagination.Item
              key={index + 1}
              active={index + 1 === currentPage}
              onClick={() => handlePageChange(index + 1)}
            >
              {index + 1}
            </Pagination.Item>
          ))}
          <Pagination.Next
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
          />
          <Pagination.Last
            onClick={() => handlePageChange(totalPages)}
            disabled={currentPage === totalPages}
          />
        </Pagination>
      </div>

      {/* View Project Modal */}
      <Modal show={showViewModal} onHide={handleCloseViewModal} centered size="lg">
        <Modal.Header closeButton>
          <Modal.Title>Project Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedProject && (
            <Row>
              <Col md={6}>
                <p><strong>ID:</strong> {selectedProject.id}</p>
                <p><strong>Name:</strong> {selectedProject.name}</p>
                <p><strong>Resident Commission:</strong> {selectedProject.resident_commission}%</p>
                <p><strong>Commercial Commission:</strong> {selectedProject.commercial_commission}%</p>
                <p><strong>Corner Resident Commission:</strong> {selectedProject.corner_resident_commission}%</p>
                <p><strong>Corner Commercial Commission:</strong> {selectedProject.corner_commercial_commission}%</p>
                <p><strong>Project Size:</strong> {selectedProject.project_size} sqft</p>
                <p>
                  <strong>Status:</strong>{" "}
                  <span
                    className={`badge ${selectedProject.status === "active" ? "bg-success" : "bg-danger"
                      }`}
                  >
                    {selectedProject.status}
                  </span>
                </p>
              </Col>
              <Col md={6}>
                {/* New fields in View Modal */}
                <p><strong>RERA Registration No.:</strong> {selectedProject.rera_registration_no}</p>
                <p><strong>Location:</strong> {selectedProject.location}</p>
                <p><strong>Project Type:</strong> {selectedProject.project_type}</p>
                <p><strong>Legality:</strong> {selectedProject.legality}</p>
                {/* Display images in View Modal */}
                {selectedProject.image && (
                  <div className="mb-3">
                    <strong>Image:</strong>
                    <br />

                    {Array.isArray(selectedProject.image) ? (
                      <div className="d-flex flex-wrap gap-2">
                        {selectedProject.image.map((imgUrl, idx) => (
                          <img
                            key={idx}
                            src={`${selectedimagePath}${imgUrl}`}
                            alt={`${selectedProject.name} ${idx}`}
                            className="img-fluid rounded mt-2"
                            style={{ maxWidth: "100px", maxHeight: "100px", objectFit: "cover" }}
                            onError={(e) => { e.target.onerror = null; e.target.src = "https://placehold.co/100x50/cccccc/333333?text=No+Image"; }}
                          />
                        ))}
                      </div>
                    ) : (
                      <img
                        src={`${selectedimagePath}${selectedProject.image}`}
                        alt={selectedProject.name}
                        className="img-fluid rounded mt-2"
                        style={{ maxWidth: "200px" }}
                        onError={(e) => { e.target.onerror = null; e.target.src = "https://placehold.co/200x100/cccccc/333333?text=No+Image"; }}
                      />
                    )}
                  </div>
                )}
              </Col>
              <Col xs={12}>
                <hr />
                <p><strong>Description:</strong></p>
                <div dangerouslySetInnerHTML={{ __html: selectedProject.description }} />
              </Col>
            </Row>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseViewModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Edit Project Modal */}
      <Modal show={showEditModal} onHide={handleCloseEditModal} centered size="lg">
        <Modal.Header closeButton>
          <Modal.Title>Edit Project</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleUpdateProject}>
            <Row>
              <Col md={6}>
                <Form.Group className="mb-3" controlId="editProjectName">
                  <Form.Label>Project Name</Form.Label>
                  <Form.Control
                    type="text"
                    name="name"
                    value={editFormData.name}
                    onChange={handleEditFormChange}
                    required
                  />
                </Form.Group>
              </Col>
              <Col md={6}>
                <Form.Group className="mb-3" controlId="editResidentCommission">
                  <Form.Label>Resident Commission (%)</Form.Label>
                  <Form.Control
                    type="number"
                    name="resident_commission"
                    value={editFormData.resident_commission}
                    onChange={handleEditFormChange}
                    required
                  />
                </Form.Group>
              </Col>
            </Row>

            <Row>
              <Col md={6}>
                <Form.Group className="mb-3" controlId="editCommercialCommission">
                  <Form.Label>Commercial Commission (%)</Form.Label>
                  <Form.Control
                    type="number"
                    name="commercial_commission"
                    value={editFormData.commercial_commission}
                    onChange={handleEditFormChange}
                    required
                  />
                </Form.Group>
              </Col>
              <Col md={6}>
                <Form.Group className="mb-3" controlId="editCornerResidentCommission">
                  <Form.Label>Corner Resident Commission (%)</Form.Label>
                  <Form.Control
                    type="number"
                    name="corner_resident_commission"
                    value={editFormData.corner_resident_commission}
                    onChange={handleEditFormChange}
                    required
                  />
                </Form.Group>
              </Col>
            </Row>

            <Row>
              <Col md={6}>
                <Form.Group className="mb-3" controlId="editCornerCommercialCommission">
                  <Form.Label>Corner Commercial Commission (%)</Form.Label>
                  <Form.Control
                    type="number"
                    name="corner_commercial_commission"
                    value={editFormData.corner_commercial_commission}
                    onChange={handleEditFormChange}
                    required
                  />
                </Form.Group>
              </Col>
              <Col md={6}>
                <Form.Group className="mb-3" controlId="editProjectSize">
                  <Form.Label>Project Size (sqft)</Form.Label>
                  <Form.Control
                    type="number"
                    name="project_size"
                    value={editFormData.project_size}
                    onChange={handleEditFormChange}
                    required
                  />
                </Form.Group>
              </Col>
            </Row>

            <Row>
              <Col md={6}>
                <Form.Group className="mb-3" controlId="editReraRegistrationNo">
                  <Form.Label>RERA Registration No.</Form.Label>
                  <Form.Control
                    type="text"
                    name="rera_registration_no"
                    value={editFormData.rera_registration_no}
                    onChange={handleEditFormChange}
                    required
                  />
                </Form.Group>
              </Col>
              <Col md={6}>
                <Form.Group className="mb-3" controlId="editLocation">
                  <Form.Label>Location</Form.Label>
                  <Form.Control
                    type="text"
                    name="location"
                    value={editFormData.location}
                    onChange={handleEditFormChange}
                    required
                  />
                </Form.Group>
              </Col>
            </Row>

            <Row>
              <Col md={6}>
                <Form.Group className="mb-3" controlId="editProjectType">
                  <Form.Label>Project Type</Form.Label>
                  <Form.Control
                    type="text"
                    name="project_type"
                    value={editFormData.project_type}
                    onChange={handleEditFormChange}
                    required
                  />
                </Form.Group>
              </Col>
              <Col md={6}>
                <Form.Group className="mb-3" controlId="editStatus">
                  <Form.Label>Status</Form.Label>
                  <Form.Select
                    name="status"
                    value={editFormData.status}
                    onChange={handleEditFormChange}
                    required
                  >
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </Form.Select>
                </Form.Group>
              </Col>
            </Row>

            <Form.Group className="mb-3" controlId="editDescription">
              <Form.Label>Description</Form.Label>
              <CKEditor
                editor={ClassicEditor}
                data={editFormData.description}
                onChange={handleDescriptionChange}
                config={{
                  toolbar: [
                    'heading', '|', 'bold', 'italic', 'link', 'bulletedList', 'numberedList', 'blockQuote', '|',
                    'undo', 'redo'
                  ],
                  licenseKey: 'eyJhbGciOiJFUzI1NiJ9.eyJleHAiOjE3NTQ0MzgzOTksImp0aSI6Ijk4MGNlZTU4LTA0ZTUtNDVkMi1iZmI4LWZmZTNjNjMwNjA4MCIsInVzYWdlRW5kcG9pbnQiOiJodHRwczovL3Byb3h5LWV2ZW50LmNrZWRpdG9yLmNvbSIsImRpc3RyaWJ1dGlvbkNoYW5uZWwiOlsiY2xvdWQiLCJkcnVwYWwiLCJzaCJdLCJ3aGl0ZUxhYmVsIjp0cnVlLCJsaWNlbnNlVHlwZSI6InRyaWFsIiwiZmVhdHVyZXMiOlsiKiJdLCJ2YyI6IjVmZjc5NDUxIn0.0ckOvFDI8r8h1g0YVW4Vlx4PmiF2bYkIaAqdSYuM_8RC8Wl3cO4jIfkMAd57z6Fo_6JPmlmDfLjafu4EnnByzQ',
                }}
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="editLegality">
              <Form.Label>Legality</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                name="legality"
                value={editFormData.legality}
                onChange={handleEditFormChange}
                required
              />
            </Form.Group>


            <Form.Group className="mb-3" controlId="editImage">
              <Form.Label>Project Images</Form.Label>

              
              {editFormData.images && editFormData.images.length > 0 && (
                <div className="mt-2 mb-3">
                  <small className="text-muted">Current Images:</small>
                  <div className="d-flex flex-wrap gap-2 mt-2">
                    {editFormData.images.map((image, index) => (
                      <div key={index} className="position-relative">
                        <img
                          src={`${selectedimagePath}${image}`}
                          className="img-thumbnail"
                          style={{ width: "100px", height: "100px", objectFit: "cover" }}
                          onError={(e) => {
                            e.target.onerror = null;
                            e.target.src = "https://placehold.co/100x100/cccccc/333333?text=No+Image";
                          }}
                          alt={`Project Image ${index + 1}`}
                        />
                        <Button
                          variant="danger"
                          size="sm"
                          className="position-absolute top-0 end-0 translate-middle badge rounded-pill bg-danger"
                          onClick={() => handleDeleteCurrentImage(editFormData.project_id)}
                          style={{ cursor: "pointer" }}
                        >
                          X
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

             
              <Form.Control
                type="file"
                name="newImage"
                accept="image/*"
                multiple
                onChange={handleNewImageChange}
                ref={newImageInputRef}
              />

              
              {editFormData.newImages.length > 0 && (
                <div className="mt-2 d-flex flex-wrap gap-2">
                  <small className="text-muted w-100">New Images to Upload:</small>
                  {editFormData.newImages.map((file, index) => (
                    <div key={index} className="position-relative">
                      <img
                        src={URL.createObjectURL(file)}
                        alt={`New Preview ${index + 1}`}
                        className="img-thumbnail"
                        style={{ width: "100px", height: "100px", objectFit: "cover" }}
                      />
                      <Button
                        variant="danger"
                        size="sm"
                        className="position-absolute top-0 end-0 translate-middle badge rounded-pill bg-danger"
                        onClick={() => removeNewImage(index)}
                        style={{ cursor: "pointer" }}
                      >
                        X
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </Form.Group>

            <Button variant="primary" type="submit" className="w-100" disabled={loading}>
              {loading ? "Updating..." : "Update Project"}
            </Button>
          </Form>
        </Modal.Body>
      </Modal>


      {/* Custom Message Modal */}
      {showMessageModal && (
        <div className="modal d-block" tabIndex="-1" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}>
          <div className="modal-dialog modal-dialog-centered">
            <div className={`modal-content border-top border-4 ${messageModalContent.type === 'success' ? 'border-success' : messageModalContent.type === 'error' ? 'border-danger' : 'border-warning'}`}>
              <div className="modal-header d-flex justify-content-between align-items-center">
                <h5 className={`modal-title ${messageModalContent.type === 'success' ? 'text-success' : messageModalContent.type === 'error' ? 'text-danger' : 'text-warning'}`}>
                  {messageModalContent.title}
                </h5>
                <button type="button" className="btn-close" aria-label="Close" onClick={closeCustomMessageModal}></button>
              </div>
              <div className="modal-body text-secondary">
                <p>{messageModalContent.text}</p>
              </div>
              <div className="modal-footer justify-content-center">
                {messageModalContent.confirmAction ? (
                  <>
                    <Button
                      variant="secondary"
                      onClick={closeCustomMessageModal}
                    >
                      Cancel
                    </Button>
                    <Button
                      variant={messageModalContent.type === 'warning' ? 'warning' : 'primary'}
                      onClick={() => {
                        messageModalContent.confirmAction();
                        closeCustomMessageModal();
                      }}
                    >
                      Confirm
                    </Button>
                  </>
                ) : (
                  <Button
                    variant={messageModalContent.type === 'success' ? 'success' : messageModalContent.type === 'error' ? 'danger' : 'primary'}
                    onClick={closeCustomMessageModal}
                  >
                    OK
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default AllProjectList;
